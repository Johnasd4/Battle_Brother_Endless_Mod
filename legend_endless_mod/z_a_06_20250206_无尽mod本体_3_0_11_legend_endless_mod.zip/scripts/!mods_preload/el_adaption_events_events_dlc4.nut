local gt = getroottable();

::mods_registerMod("el_adaption_events_events_dlc4", 1, "el_adaption_events_events_dlc4");
::mods_queue(null, "el_player_npc", function ()
{

    ::mods_hookExactClass("events/events/dlc4/kings_guard_2_event", function(o){

        function create()
        {
            this.m.ID = "event.kings_guard_2";
            this.m.Title = "Along the road...";
            this.m.Cooldown = 9999999.0 * this.World.getTime().SecondsPerDay;
            this.m.Screens.push({
                ID = "A",
                Text = "[img]gfx/ui/events/event_82.png[/img]{You find %guard% stretching about with surprising limberness, and looks nothing at all like the freezing, frigid figure you found abandoned in the ice by those barbarians. Spotting you, the mercenary nods and comes over with a quiet voice.%SPEECH_ON%I\'m glad you trusted in me, captain. Perhaps you did it out of the kindness of your heart, but I need to show you something.%SPEECH_OFF%He flashes an emblem you have heard referenced many times, but have never seen: it carries the sigil of the King\'s Guard and its pristineness is such that there is no way it could have been a farce. The mercenary smiles at you.%SPEECH_ON%I think I am in good health and ready to serve you as I did my liege.%SPEECH_OFF%The kings of these lands have long since fallen, replaced by squabbling lords and nobles. If this mercenary can fight for you as well as for the kings, then the %companyname% has brighter days ahead surely.}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "I\'m glad we found you on that fateful day.",
                        function getResult( _event )
                        {
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                    this.Characters.push(_event.m.Dude.getImagePath());
                    local bg = this.new("scripts/skills/backgrounds/kings_guard_background");
                    bg.m.IsNew = false;
                    local oldPerkTree = _event.m.Dude.getBackground().m.CustomPerkTree;
                    _event.m.Dude.getSkills().removeByID("background.cripple");
                    _event.m.Dude.getSkills().add(bg);
                    _event.m.Dude.getBackground().m.RawDescription = "You found %name% frozen half to death in the north. With your help, the former King\'s Guard regained strength and now fights for you.";
                    _event.m.Dude.getBackground().buildDescription(true);
                    this.Const.EL_Player.EL_PerkTree.EL_AddRandomPerkTreeToPlayer(_event.m.Dude, 50);
                    _event.m.Dude.resetPerks();
                    _event.m.Dude.improveMood(1.0, "Is his former self again");

                    if (_event.m.Dude.getMoodState() >= this.Const.MoodState.Neutral)
                    {
                        this.List.push({
                            id = 10,
                            icon = this.Const.MoodStateIcon[_event.m.Dude.getMoodState()],
                            text = _event.m.Dude.getName() + this.Const.MoodStateEvent[_event.m.Dude.getMoodState()]
                        });
                    }

                    _event.m.Dude.getBaseProperties().MeleeSkill += 12;
                    _event.m.Dude.getBaseProperties().MeleeDefense += 7;
                    _event.m.Dude.getBaseProperties().RangedDefense += 7;
                    _event.m.Dude.getBaseProperties().Hitpoints += 15;
                    _event.m.Dude.getBaseProperties().Stamina += 10;
                    _event.m.Dude.getBaseProperties().Initiative += 10;
                    _event.m.Dude.getSkills().update();
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/melee_defense.png",
                        text = _event.m.Dude.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+7[/color] Melee Defense"
                    });
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/ranged_defense.png",
                        text = _event.m.Dude.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+7[/color] Ranged Defense"
                    });
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/melee_skill.png",
                        text = _event.m.Dude.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+12[/color] Melee Skill"
                    });
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/fatigue.png",
                        text = _event.m.Dude.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+10[/color] Max Fatigue"
                    });
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/initiative.png",
                        text = _event.m.Dude.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+10[/color] Initiative"
                    });
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/health.png",
                        text = _event.m.Dude.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+15[/color] Hitpoints"
                    });
                }

            });
        }





    });

    ::mods_hookExactClass("events/events/dlc4/wild_dog_sounds_event", function(o){

        o.create = function()
        {
            //this.logInfo("wild_dog_sounds_event create");

            this.m.ID = "event.wild_dog_sounds";
            this.m.Title = "Along the way...";
            this.m.Cooldown = 90.0 * this.World.getTime().SecondsPerDay;
            this.m.Screens.push({
                ID = "A",
                Text = "[img]gfx/ui/events/event_33.png[/img]{As the company camps, %randombrother% stops stropping a blade and looks up.%SPEECH_ON%Y\'all hear that?%SPEECH_OFF%You do. Wild dogs are yipping and howling. You shrug and say it\'s nothing, but in that moment there\'s a yelp and the yips turn into snarling and you hear the distinct sound of animalistic struggle. The snarls turn to whines. Something is losing the fight. %randombrother% turns to you.%SPEECH_ON%Sounds close, should we check it out? I don\'t wanna sleep with that around.%SPEECH_OFF%}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "Just ignore it.",
                        function getResult( _event )
                        {
                            return this.Math.rand(1, 100) <= 50 ? "B" : "C";
                        }

                    }
                ],
                function start( _event )
                {
                    if (_event.m.Hunter != null)
                    {
                        this.Options.push({
                            Text = "You\'re a hunter, %hunter%, go take a look.",
                            function getResult( _event )
                            {
                                return "D";
                            }

                        });
                    }

                    if (_event.m.Wildman != null)
                    {
                        this.Options.push({
                            Text = "You came from the wilds, %wildman%, go take a look.",
                            function getResult( _event )
                            {
                                return "E";
                            }

                        });
                    }

                    if (_event.m.Expendable != null)
                    {
                        this.Options.push({
                            Text = "Looks like a job for the new guy. Go take a look, %recruit%!",
                            function getResult( _event )
                            {
                                return this.Math.rand(1, 100) <= 40 ? "F" : "G";
                            }

                        });
                    }
                }

            });
            this.m.Screens.push({
                ID = "B",
                Text = "[img]gfx/ui/events/event_33.png[/img]{You tell the company to ignore the sounds. That\'s a hard task to oblige as the cries of the wild dogs only grow louder and louder until, just like that, they stop. Your mercenaries stand still as though making any noise could bring the hell of whatever horror it is that\'s out there. Nothing comes to pass, but a number of the company have a hard time sleeping through the night.}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "Grow a pair, you gits.",
                        function getResult( _event )
                        {
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                    local brothers = this.World.getPlayerRoster().getAll();

                    foreach( bro in brothers )
                    {
                        if (bro.getBackground().getID() == "background.hunter" || bro.getBackground().getID() == "background.poacher" || bro.getBackground().getID() == "background.beast_slayer" || bro.getBackground().getID() == "background.legend_commander_ranger")
                        {
                            continue;
                        }

                        if (bro.getBackground().getID() == "background.wildman" || bro.getBackground().getID() == "background.barbarian" || bro.getBackground().getID() == "background.wildwoman" || bro.getBackground().getID() == "background.legend_berserker" || bro.getBackground().getID() == "background.legend_commander_berserker")
                        {
                            continue;
                        }

                        if (this.Math.rand(1, 100) <= 25)
                        {
                            bro.worsenMood(0.5, "Didn\'t get a good night\'s sleep");
                            local effect = this.new("scripts/skills/effects_world/exhausted_effect");
                            bro.getSkills().add(effect);
                            this.List.push({
                                id = 10,
                                icon = effect.getIcon(),
                                text = bro.getName() + " is exhausted"
                            });
                        }
                    }
                }

            });
            this.m.Screens.push({
                ID = "C",
                Text = "[img]gfx/ui/events/event_33.png[/img]{You tell the company to plug their ears if it bothers them so much. As the cries of the wild dogs grow louder the company turn to impromptu ear candling to keep the sounds at bay. Eventually, the sense deprived sellswords are awkwardly walking around like animatronics. You look to join the muted, plugging a waxball into your ear, but before you can get the second ear a loud crash sends inventory flowing and a tent billows as it collapses. You drain your ear and bark orders to the mercenaries who are scattered all over the camp.}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "To arms, you deaf fools!",
                        function getResult( _event )
                        {
                            local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
                            properties.CombatID = "Event";
                            properties.Music = this.Const.Music.BeastsTracks;
                            properties.Entities = [];
                            properties.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;
                            local party = this.new("scripts/entity/world/party");
                            local dif = this.Math.rand(80, 100);
                            party.EL_setTroopsResourse(party.EL_getTroopsResourse() * dif * 0.01);
                            party.EL_setFaction(this.World.FactionManager.getFactionOfType(this.Const.FactionType.Beasts).getID());
                            party.EL_tempPartyInit();
                            properties.Parties.push(party);
                            this.Const.World.Common.addUnitsToCombat(party, this.Const.World.Spawn.Unhold, dif, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Beasts).getID());
                            foreach(troop in party.getTroops()) {
                                properties.Entities.push(troop);
                            }

                            this.World.State.startScriptedCombat(properties, false, false, true);
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                }

            });
            this.m.Screens.push({
                ID = "D",
                Text = "[img]gfx/ui/events/event_14.png[/img]{It does appear the mercenaries will not be assuaged by telling them to grow a pair. %hunter% elects to go seek out the noise, sure it\'s nothing more than the wild dogs squabbling over primacy over the pack. You agree, the archer venturing into the dark all alone. Just as soon as the outline is gone the canines cease their crying and you hear a growl that seems as though it came from a much higher ground. The whole camp is dead silent, daring not to even move.\n\n An hour later and the hunter walks into camp, nobody having heard the archer come in. The hunter is camouflaged in mud slaked with twigs and leaves. %hunter%\'s grafted stems into a hood, worn like some arboreal abbess. With hushed tones, the sellswords ask what it was. With a shrug the reply comes.%SPEECH_ON%Well. I seen about a dozen dead dogs. Some ripped apart. Found a few in the pit of very large footprints and they\'d not found the print but had been stomped there, you know. And I saw something move along in the shadows between the tree tops and it went the other way and I did not follow. I found a deer dead on its feet leaning against a tree. Heart faltered by whatever it saw, I suppose. I harvested everything I could.%SPEECH_OFF%The hunter turns and slings forward a rack of meat strung to a paneling of wood and leaves.%SPEECH_ON%Anyone hungry?%SPEECH_OFF%} ",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "Hell of a haul, I suppose.",
                        function getResult( _event )
                        {
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                    this.Characters.push(_event.m.Hunter.getImagePath());
                    local item = this.new("scripts/items/supplies/cured_venison_item");
                    local item = this.new("scripts/items/supplies/cured_venison_item");
                    this.World.Assets.getStash().add(item);
                    this.List.push({
                        id = 10,
                        icon = "ui/items/" + item.getIcon(),
                        text = "You gain " + item.getName()
                    });
                    _event.m.Hunter.getBaseProperties().Bravery += 1;
                    _event.m.Hunter.getSkills().update();
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/bravery.png",
                        text = _event.m.Hunter.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+1[/color] Resolve"
                    });
                    local brothers = this.World.getPlayerRoster().getAll();

                    foreach( bro in brothers )
                    {
                        if (bro.getBackground().getID() == "background.hunter" || bro.getBackground().getID() == "background.poacher" || bro.getBackground().getID() == "background.beast_slayer")
                        {
                            continue;
                        }

                        if (bro.getBackground().getID() == "background.wildman" || bro.getBackground().getID() == "background.wildwoman" || bro.getBackground().getID() == "background.barbarian")
                        {
                            continue;
                        }

                        if (this.Math.rand(1, 100) <= 15)
                        {
                            bro.worsenMood(0.5, "Concerned that there\'s something big out there");
                        }
                    }
                }

            });
            this.m.Screens.push({
                ID = "E",
                Text = "[img]gfx/ui/events/event_33.png[/img]{Fear comes over the camp, but you fetch %wildman% to your side. The wildman snorts and runs his hand along his nose as though you\'ve inconvenienced whatever inexplicable notion he has of his own time. He raises an eyebrow as you suggest, to the best of your pantomiming abilities, that he go and seek out the noise. With little further suggestion, the man grunts and takes off into the woods.\n\n You swear he\'s a good hundred meters off but you can still hear him barreling through the bushes making all the goddam noise in the world. The wild dogs quit their baying and in their place you hear a loud growl and the hoots of a smaller one. They bandy back and forth and you notice you can feel the ground tremoring beneath your feet. The vibrations falter and fade and the screaming halts altogether. Just as you begin to worry, the wildman walks back into camp. He sits beside the campfire, yawns, turns over, and falls asleep. It is as though he\'d never left at all.}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "Problem good as solved, I guess.",
                        function getResult( _event )
                        {
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                    this.Characters.push(_event.m.Wildman.getImagePath());
                    _event.m.Wildman.improveMood(1.0, "Had a good night\'s sleep");

                    if (_event.m.Wildman.getMoodState() >= this.Const.MoodState.Neutral)
                    {
                        this.List.push({
                            id = 10,
                            icon = this.Const.MoodStateIcon[_event.m.Wildman.getMoodState()],
                            text = _event.m.Wildman.getName() + this.Const.MoodStateEvent[_event.m.Wildman.getMoodState()]
                        });
                    }
                }

            });
            this.m.Screens.push({
                ID = "F",
                Text = "[img]gfx/ui/events/event_33.png[/img]{You look about the company. A young %recruit% looks back. Looking down, as though to look within themself, and then hurriedly gets to their feet.%SPEECH_ON%Say no more, captain. I will find out what this disturbance is.%SPEECH_OFF%The fresh recruit gathers their things and then stands at the edge of the camp\'s light, a very dark forest looking back at them. The mercenary stares down again and clenches and unclenches their hands.%SPEECH_ON%Alright. Alright.%SPEECH_OFF%He looks up.%SPEECH_ON%Let\'s do this.%SPEECH_OFF%The recruit is never seen again.}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "Perhaps sending a greenhorn wasn\'t the best idea.",
                        function getResult( _event )
                        {
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                    this.Characters.push(_event.m.Expendable.getImagePath());
                    local dead = _event.m.Expendable;
                    this.World.Statistics.addFallen(dead, "Went missing");
                    this.List.push({
                        id = 13,
                        icon = "ui/icons/kills.png",
                        text = _event.m.Expendable.getName() + " went missing"
                    });
                    _event.m.Expendable.getItems().transferToStash(this.World.Assets.getStash());
                    _event.m.Expendable.getSkills().onDeath(this.Const.FatalityType.None);
                    this.World.getPlayerRoster().remove(_event.m.Expendable);
                }

            });
            this.m.Screens.push({
                ID = "G",
                Text = "[img]gfx/ui/events/event_33.png[/img]{You look about the company. A young %recruit% looks back. They look down, as though to look within themself, and then hurriedly gets to their feet.%SPEECH_ON%Say no more, captain. I will find out what this disturbance is.%SPEECH_OFF%The fresh recruit gathers their things and then stands at the edge of the camp\'s light, a very dark forest looking back at them. The mercenary stares down again and clenches and unclenches their hands. %recruit% huffs and then steps forth, immediately slipping into the shadows. Hours pass. Finally, %recruit% returns. Their clothes are in tatters. Weapons are gone.  Spitting forth story after story. Magic rings, volcanoes, giant eagles, absolute nonsense. Whatever %recruit% saw, it\'s clear the blubbering sellsword needs to clear their head with some well earned beauty sleep. Which the\'ll get since all that awful noise has ceased.}",
                Image = "",
                List = [],
                Characters = [],
                Options = [
                    {
                        Text = "Get your sleep, kid.",
                        function getResult( _event )
                        {
                            return 0;
                        }

                    }
                ],
                function start( _event )
                {
                    this.Characters.push(_event.m.Expendable.getImagePath());
                    _event.m.Expendable.addXP(200, false);
                    _event.m.Expendable.updateLevel();
                    this.List.push({
                        id = 16,
                        icon = "ui/icons/xp_received.png",
                        text = _event.m.Expendable.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+200[/color] Experience"
                    });
                    _event.m.Expendable.improveMood(3.0, "Had an excellent adventure");

                    if (_event.m.Expendable.getMoodState() >= this.Const.MoodState.Neutral)
                    {
                        this.List.push({
                            id = 10,
                            icon = this.Const.MoodStateIcon[_event.m.Expendable.getMoodState()],
                            text = _event.m.Expendable.getName() + this.Const.MoodStateEvent[_event.m.Expendable.getMoodState()]
                        });
                    }

                    local items = _event.m.Expendable.getItems();

                    if (items.getItemAtSlot(this.Const.ItemSlot.Mainhand) != null && items.getItemAtSlot(this.Const.ItemSlot.Mainhand).isItemType(this.Const.Items.ItemType.Weapon) && !items.getItemAtSlot(this.Const.ItemSlot.Mainhand).isItemType(this.Const.Items.ItemType.Legendary) && !items.getItemAtSlot(this.Const.ItemSlot.Mainhand).isItemType(this.Const.Items.ItemType.Named))
                    {
                        this.List.push({
                            id = 10,
                            icon = "ui/items/" + items.getItemAtSlot(this.Const.ItemSlot.Mainhand).getIcon(),
                            text = "You lose " + this.Const.Strings.getArticle(items.getItemAtSlot(this.Const.ItemSlot.Mainhand).getName()) + items.getItemAtSlot(this.Const.ItemSlot.Mainhand).getName()
                        });
                        items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
                    }

                    if (items.getItemAtSlot(this.Const.ItemSlot.Head) != null)
                    {
                        items.getItemAtSlot(this.Const.ItemSlot.Head).setCondition(this.Math.max(1, items.getItemAtSlot(this.Const.ItemSlot.Head).getConditionMax() * this.Math.rand(10, 40) * 0.01));
                    }

                    if (items.getItemAtSlot(this.Const.ItemSlot.Body) != null)
                    {
                        items.getItemAtSlot(this.Const.ItemSlot.Body).setArmor(this.Math.max(1, items.getItemAtSlot(this.Const.ItemSlot.Body).getRepairMax() * this.Math.rand(10, 40) * 0.01));
                    }
                }

            });
        }






    });
});
