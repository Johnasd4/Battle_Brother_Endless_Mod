this.el_temp_weaken_effect <- this.inherit("scripts/skills/skill", {
	m = {
		Count = 1
	},
	function create()
	{
		this.m.ID = "el_rarity_effects.temp_weaken";
		this.m.Name = "临时弱化";
		this.m.Description = "This character was weakened in a short period of time.";
		this.m.Icon = "ui/perks/ptr_from_all_sides.png";
		this.m.IconMini = "ptr_from_all_sides_effect_mini";
		this.m.Overlay = "ptr_from_all_sides_effect";
		this.m.Type = this.Const.SkillType.StatusEffect;
		this.m.IsActive = false;
		this.m.IsStacking = false;
		this.m.IsRemovedAfterBattle = true;
	}

	function getName()
	{
		return this.m.Name + " (x" + this.m.Count + ")";
	}

	function getTooltip()
	{
		return [
			{
				id = 1,
				type = "title",
				text = this.getName()
			},
			{
				id = 2,
				type = "description",
				text = this.getDescription()
			},
			{
				id = 10,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]-" + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenBravery * this.m.Count + "[/color] Bravery"
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/ranged_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]-" + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenInitiative * this.m.Count + "[/color] Initiative"
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]-" + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenMeleeSkill * this.m.Count + "[/color] Melee Skill"
			},
			{
				id = 13,
				type = "text",
				icon = "ui/icons/ranged_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]-" + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenRangedSkill * this.m.Count + "%[/color] Ranged Skill"
			},
			{
				id = 14,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]-" + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenMeleeDefense * this.m.Count + "[/color] Melee Defense"
			},
			{
				id = 15,
				type = "text",
				icon = "ui/icons/ranged_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]-" + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenRangedDefense * this.m.Count + "%[/color] Ranged Defense"
			},
			{
				id = 16,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]Received an additional " + this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenDamageReceivedTotalMult * this.m.Count * 100 + "% damage[/color]"
			}
		];
	}

	function onRefresh()
	{
		this.m.Count += 0.5;
		//this.spawnIcon("ptr_from_all_sides_effect", this.getContainer().getActor().getTile());
	}

	function onUpdate( _properties )
	{
		_properties.Bravery -= this.Math.floor(this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenBravery * this.m.Count);
		_properties.Initiative -= this.Math.floor(this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenInitiative * this.m.Count);
		_properties.MeleeSkill -= this.Math.floor(this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenMeleeSkill * this.m.Count);
		_properties.RangedSkill -= this.Math.floor(this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenRangedSkill * this.m.Count);
		_properties.MeleeDefense -= this.Math.floor(this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenMeleeDefense * this.m.Count);
		_properties.RangedDefense -= this.Math.floor(this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenRangedDefense * this.m.Count);
		_properties.DamageReceivedTotalMult *= (this.Const.EL_Rarity_Entry.Factor.EL_FightAndWin.TempWeakenDamageReceivedTotalMult * this.m.Count + 1);
		//this.logInfo("target properties impress by temp weaken:" + this.m.Count);
	}

	function onTurnEnd()
	{
		this.removeSelf();
	}

	function onNewRound()
	{
		this.removeSelf();
	}
});

