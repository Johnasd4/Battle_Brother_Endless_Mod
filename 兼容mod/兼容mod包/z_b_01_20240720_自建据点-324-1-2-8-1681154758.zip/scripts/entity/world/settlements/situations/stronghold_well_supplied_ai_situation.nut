this.stronghold_well_supplied_ai_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	//buff when AI caravans arrive at stronghold
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.stronghold_well_supplied_ai";
		this.m.Name = "供应充足";
		this.m.Description = "这个地方最近有最新的商品供应，商店现在将有更多的商品出售.";
		this.m.Icon = "ui/settlement_status/settlement_effect_03.png";
		this.m.Rumors = [
			"与%settlement%的贸易正在蓬勃发展，我的朋友！道路安全和库存充足，希望它保持这种状态...",
			"%settlement%的表哥一直在吹嘘他们那里有多好。市场摊位的存货充足,不像这个烂地方。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{

	}

	function onUpdate( _modifiers )
	{
		//number might need tweaking
		_modifiers.RarityMult *= 1.05;
	}

});

