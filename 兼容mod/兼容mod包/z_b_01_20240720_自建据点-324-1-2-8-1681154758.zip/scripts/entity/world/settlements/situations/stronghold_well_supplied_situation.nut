this.stronghold_well_supplied_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	//had to use a very hacky way to select player base, as otherwise deserialisation errors (or custom addSituation function)
	m = {
		Home = null
	},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.stronghold_well_supplied";
		this.m.Name = this.defineName();
		this.m.Description = ""
		this.m.Icon = "ui/settlement_status/settlement_effect_03.png";
		this.m.Rumors = [
			"与%settlement%的贸易正在蓬勃发展，我的朋友！道路安全和库存充足，希望它保持这种状态...",
			"%settlement%的表哥一直在吹嘘他们那里有多好。市场摊位的存货充足,不像这个烂地方。"
		];
		this.m.IsStacking = false;
		
	}
	function defineName()
	{
		local company_name = this.World.Assets.getName();
		local final_name = "";
		if (company_name.slice(company_name.len()-1, company_name.len()) == "s")
		{
			company_name = company_name.slice(0, company_name.len()-1);
		}
		final_name += company_name + "的恩惠";
		return final_name;
	}
	function isValid()
	{
		return true;
	}

	//should be dynamic and check the properties
	function defineDescription(_town)
	{
		local description = "没有贵族收税，你的商品可以买出很好的价格。 ";
		local mults = this.Stronghold.WellSupplied[_town.getSize()-1]
		return description
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onUpdate( _modifiers )
	{ 
		local playerBase = this.World.State.getCurrentTown();
		if (playerBase == null) return
		this.defineDescription(playerBase);
		local mults = this.Stronghold.WellSupplied[playerBase.getSize()-1]
		_modifiers.RarityMult = mults.Rarity;
		_modifiers.BuyPriceMult = mults.BuyPrice;
		_modifiers.SellPriceMult = mults.SellPrice;
	}

});

