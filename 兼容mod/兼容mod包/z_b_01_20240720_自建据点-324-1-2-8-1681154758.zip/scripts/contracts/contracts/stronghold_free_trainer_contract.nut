this.stronghold_free_trainer_contract <- this.inherit("scripts/contracts/contract", {
	//unlock turbo training
	//fight camp in the snow, 1 barb king champ and 2 chosen, select up to 3 of your guys to fight (works with less)
	//sets flag in base on success
	// the more contracts I write, the uglier they get
	m = {
		Reward = 0,
		Title = "寻找传奇教练",
		LastCombatTime = 0.0,
		Destination = null,
		Chosen = [],
		ChosenOptions = []
	},
	function create()
	{
		this.m.DifficultyMult = 1.0;
		this.m.Flags = this.new("scripts/tools/tag_collection");
		this.m.TempFlags = this.new("scripts/tools/tag_collection");
		this.createStates();
		this.createScreens();
		this.m.Type = "contract.stronghold_free_trainer_contract";
		this.m.Name = "寻找传奇教练";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 1500.0;
	}

	function onImportIntro()
	{
		#this.importSettlementIntro();
	}

	function start()
	{
		this.contract.start();
	}

	function getBanner()
	{
		return "ui/banners/factions/banner_08s"
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"寻找战争之地"
				];
				this.Contract.setScreen("Task");
			}

			function end()
			{
				this.World.Contracts.setActiveContract(this.Contract);
				this.Contract.setScreen("Overview_Building");
			}

		});

		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination)
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnEnterCallback(this.onDestinationAttacked.bindenv(this));
				}
			}


			function update()
			{
				if (this.Flags.get("IsVictory"))
				{
					this.Contract.setScreen("IsVictory");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsFailure"))
				{
					this.Contract.setScreen("IsFailure");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "ChosenTrainer")
				{
					this.Flags.set("IsVictory", true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "ChosenTrainer")
				{
					this.Flags.set("IsFailure", true);
				}
			}

			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
					this.Contract.setScreen("EnteringTheCamp");
					this.World.Contracts.showActiveContract();
			}

			function end()
			{
				this.Contract.m.Destination.getSprite("selection").Visible = false;
				this.Contract.m.Destination.setOnEnterCallback(null);
			}

		});

		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"Return to " + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{

					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();

				}
			}

		});
	}

	function createScreens()
	{
		this.m.Screens.push({
			ID = "Task",
			Title = this.m.Title,
			Text = "从北方野蛮人逃脱的奴隶谈到了战争之地，战士们在这里提高技能，最终成为被选中的精英野蛮战士。据说，一位传奇教练教他们的技能。这个人将是我们基地的巨大财富。去找他！",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "别无选择",
					function getResult()
					{

						return "Overview_Building";
					}

				},
				{
					Text = "我现在不想开始这个任务。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
			}

		});

		this.m.Screens.push({
			ID = "Overview_Building",
			Title = this.m.Title,
			Text = "在冰冻的北方寻找战争之地",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "是.",
					function getResult()
					{
						local disallowedTerrain = [];
						local camp;
						local distanceToOthers = 15;

						for( local i = 0; i < this.Const.World.TerrainType.COUNT; i = ++i )
						{
							if (i == this.Const.World.TerrainType.SnowyForest)
							{
							}
							else
							{
								disallowedTerrain.push(i);
							}
						}

						local tile = this.Contract.getTileToSpawnLocation(this.Contract.m.Home.getTile(), 20, 300, disallowedTerrain);

						if (tile != null)
						{
							camp = this.World.spawnLocation("scripts/entity/world/locations/legendary/stronghold_trainer_location", tile.Coords);
						}

						if (camp != null)
						{
							tile.TacticalType = this.Const.World.TerrainTacticalType.SnowyForest;
							camp.onSpawned();
							camp.getSprite("selection").Visible = true;
							camp.setDiscovered(true);
							camp.setAttackable(true);
							this.World.uncoverFogOfWar(camp.getTile().Pos, 500.0);
							this.Contract.m.Destination = this.WeakTableRef(camp)
							this.Contract.setState("Running");
							return 0;
						}
						else
						{
							this.Contract.removeThisContract()
							this.logInfo("Could not find location to spawn Fields of War!")
							return 0
						}
					}

				},
				{
					Text = "不.",
					function getResult()
					{
						this.Contract.removeThisContract()
						return 0;
					}

				}
			],
			ShowObjectives = true,
			ShowPayment = true,
			ShowEmployer = true,
			ShowDifficulty = false,
			function start()
			{
				this.Contract.m.IsNegotiated = true;
			}
		});

		this.m.Screens.push({
			ID = "EnteringTheCamp",
			Title = "当你走近...",
			Text = "[img]gfx/ui/events/event_08.png[/img]{从远处，你已经可以听到金属碰撞的砰砰声和恶毒的笑声。你走近树林中的一片空地，那里有大量的野蛮战士在练习中相互厮杀。空气中弥漫着血和蜂蜜酒的味道。当你走到中间时，警惕的北方人退到一边。在中心，你会发现一个巨大的帐篷，由一群凶猛的战士守卫着。你进去的时候，你的人在外面等着。\n 一位伟大的野蛮人国王，自称战争之王，向你问好。与他相伴的是一位老剑士，这一定是找寻的传奇教练。你要求教练跟随你，但他拒绝了。 %SPEECH_ON%这些人知道生命的真谛：掌握武术，成为传说中的勇士。让我看看你有什么能力配得上我的技能！%SPEECH_OFF%  这是一场勇士之战。}" ,
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们接受挑战。",
					function getResult()
					{
						this.Contract.updateChosen()
						this.Contract.m.Screens.push({
							ID = "ChooseChampions",
							Title = "做好准备",
							Text = "[img]gfx/ui/events/event_07.png[/img]{选择你的勇士}",
							Image = "",
							List = [],
							Options = this.Contract.champtionOptions()
							function start()
							{
							}
						});
						return "ChooseChampions"
					}
				},
				{
				Text = "我们会多练习，改天再来。",
					function getResult()
					{
						return 0;
					}
				}

			]
		});


		this.m.Screens.push({
			ID = "StartFight",
			Title = "做好准备。",
			Text = "[img]gfx/ui/events/event_139.png[/img]{北方人在场地中围成一个圈，你的勇士们走了进去。国王从帐篷里出来带着他挑选的两位战士一起也进入圈中。}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "你们是我的骄傲，勇士们！",
					function getResult()
					{
						local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						properties.CombatID = "ChosenTrainer";
						properties.Music = this.Const.Music.ArenaTracks;
						properties.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Arena;
						properties.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Arena;
						local party = this.new("scripts/entity/world/party");
						party.EL_setFaction(this.Const.Faction.Enemy);
                        party.EL_tempPartyInit();
						//Stop copying troops.
						party.EL_setTroopsResourse(0);
						properties.Parties.push(party);
						this.Const.World.Common.addTroop(party, {
							Type = this.Const.World.Spawn.Troops.BarbarianChosen
						}, false, 0, 1);
						this.Const.World.Common.addTroop(party, {
							Type = this.Const.World.Spawn.Troops.BarbarianChampion
						}, false, 0, 1);
						this.Const.World.Common.addTroop(party, {
							Type = this.Const.World.Spawn.Troops.BarbarianChampion
						}, false, 0, 1);
						foreach(troop in party.getTroops()) {
							properties.Entities.push(troop);
						}
						foreach (bro in this.Contract.m.Chosen)
						{
							properties.Players.push(bro)
						}
						properties.IsUsingSetPlayers = true;
						properties.IsFleeingProhibited = true;
						properties.IsWithoutAmbience = true;
						properties.IsFogOfWarVisible = false;
						for( local i = 0; i < properties.Entities.len(); i = ++i )
						{
							properties.Entities[i].Faction <- this.Const.Faction.Enemy
						}
						properties.BeforeDeploymentCallback = function ()
						{
							local size = this.Tactical.getMapSize();

							for( local x = 0; x < size.X; x = ++x )
							{
								for( local y = 0; y < size.Y; y = ++y )
								{
									local tile = this.Tactical.getTileSquare(x, y);
									tile.Level = this.Math.min(1, tile.Level);
									tile.clear()
									tile.removeObject()
								}
							}
						};
						this.World.State.startScriptedCombat(properties, false, false, false);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});

		this.m.Screens.push({
			ID = "IsVictory",
			Title = "战后...",
			Text = "[img]gfx/ui/events/event_50.png[/img]你的勇士们砍倒了国王和他们的战士。当你收拾他们的装备时，那些曾经吵闹的人群没有出来反对。老剑师对你们的表现印象深刻。%SPEECH_ON%因此，南方人中还剩下一些真正的勇士。很好，我会跟随你。%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "该回家了。",
					function getResult()
					{
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
			}
		});

		this.m.Screens.push({
			ID = "IsFailure",
			Title = "战后...",
			Text = "[img]gfx/ui/events/event_135.png[/img]{在北方人雷鸣般的欢呼声中，你的战士被国王和他所选择的战士砍倒了。老剑士冷笑道：他就知道会这样。你离开战争之地，却一事无成？除了失去一些你最好的勇士。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "真是一场灾难。",
					function getResult()
					{
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
			}
		});

		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来的时候...",
			Text = "[img]gfx/ui/events/event_53.png[/img]{老剑师很欣赏你的基地。他同意在这里教导的新兵，尽管他的服务不便宜。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "好极了.",
					function getResult()
					{
						this.Stronghold.getPlayerFaction().m.Flags.set("Teacher", true);
						this.Stronghold.getPlayerFaction().clearContracts()
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/events/event_134.png",
					text = "现在，你可以为新队友们进行特殊训练了。"
				});

			}
		});
	}



	function onPrepareVariables( _vars )
	{
	}

	function onHomeSet()
	{
	}

	function onClear()
	{

		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
			}
			this.World.FactionManager.getFaction(this.getFaction()).setActive(true);
			this.m.Home.getSprite("selection").Visible = false;
		}

	}

	function onIsValid()
	{
		return true;
	}

	function removeThisContract()
	{
		this.World.Contracts.removeContract(this);
		this.Stronghold.getPlayerFaction().updateQuests();
		this.World.State.getTownScreen().updateContracts();
	}

	function champtionOptions()
	{
		local options = [];
		foreach (bro in this.m.ChosenOptions)
		{
			options.push({
					Text = "你是我们的勇士之一, " + bro.getName() + " 。",
					function getResult()
					{
						{
							return "addChosen"
						}
					}

				});
		}
		return options;
	}
	function updateChosen()
	{
		local roster = this.World.getPlayerRoster().getAll();
		local options = []
		roster.sort(function ( _a, _b )
		{
			if (_a.getXP() > _b.getXP())
			{
				return -1;
			}
			else if (_a.getXP() < _b.getXP())
			{
				return 1;
			}

			return 0;
		});

		local numslots = this.Math.min(10, roster.len())
		for (local x = 0; x < numslots; x++)
		{
			options.push(roster[x])
		}
		this.m.ChosenOptions = options
	}
	function addToCombat( _list, _entityType, _champion = false, _name = "" )
	{
		local c = clone _entityType;

		if (c.Variant != 0 && _champion)
		{
			c.Variant = 1;
			c.Name <- _name;
		}
		else
		{
			c.Variant = 0;
		}

		_list.push(c);
	}

	function processInput( _option )
	{
		//hack into this function for dynamic bro selection
		if (this.m.ActiveScreen == null)
		{
			return false;
		}

		if (_option >= this.m.ActiveScreen.Options.len())
		{
			return true;
		}

		local result = this.m.ActiveScreen.Options[_option].getResult();
		if (result == "addChosen")
		{
			local has_unit = false
			foreach (bro in this.m.Chosen)
			{
				if (bro.getName() == this.m.ChosenOptions[_option].getName())
				{
					has_unit= true
				}
			}
			if (!has_unit)
			{
				this.m.Chosen.push(this.m.ChosenOptions[_option])
				this.m.ChosenOptions.remove(_option)
				this.m.ActiveScreen.Options.remove(_option)
				this.World.Contracts.showActiveContract();

			}
			if(this.m.Chosen.len() == 3 || this.m.Chosen.len() == this.World.getPlayerRoster().getAll().len())
			{
				this.setScreen(this.getScreen("StartFight"));
			}
			return true;
		}

		if (typeof result != "string" && result <= 0)
		{
			if (this.isActive())
			{
				this.setScreen(null);
			}

			return false;
		}

		this.setScreen(this.getScreen(result));
		return true;
	}
	function cancel()
	{
		this.onCancel();
	}

	function onSerialize( _out )
	{
		_out.writeI32(0);

		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}
		this.contract.onSerialize(_out);
	}


	function onDeserialize( _in )
	{
		_in.readI32();
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);


	}

});

