this.stronghold_find_waterskin_recipe_contract <- this.inherit("scripts/contracts/contract", {
	//unlock the waterskin buyable item
	//spawns a custom camp in the desert
	//success sets flag in stronghold to allow the special action
	m = {
		Reward = 0,
		Destination = null,
		Title = "寻找神秘水的配方"
	},
	function create()
	{
		this.m.DifficultyMult = 1.0;
		this.m.Flags = this.new("scripts/tools/tag_collection");
		this.m.TempFlags = this.new("scripts/tools/tag_collection");
		this.createStates();
		this.createScreens();
		this.m.Type = "contract.stronghold_find_waterskin_recipe_contract";
		this.m.Name = "寻找神秘配方";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 1500.0;
	}

	function onImportIntro()
	{
		#this.importSettlementIntro();
	}

	function start()
	{
		this.contract.start();
	}

	function getBanner()
	{
		return "ui/banners/factions/banner_05s"
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"找到沙漠中的位置."
				];
				this.Contract.setScreen("Task");
			}

			function end()
			{
				this.World.Contracts.setActiveContract(this.Contract);
				this.Contract.setScreen("Overview_Building");
			}

		});

		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination)
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnEnterCallback(this.onDestinationAttacked.bindenv(this));
				}
				else
				{
					local disallowedTerrain = [];
					local camp;
					local distanceToOthers = 15;

					for( local i = 0; i < this.Const.World.TerrainType.COUNT; i = ++i )
					{
						if (i == this.Const.World.TerrainType.Desert)
						{
						}
						else
						{
							disallowedTerrain.push(i);
						}
					}

					local tile = this.Contract.getTileToSpawnLocation(this.Contract.m.Home.getTile(), 20, 300, disallowedTerrain);

					if (tile != null)
					{
						camp = this.World.spawnLocation("scripts/entity/world/locations/legendary/stronghold_waterskin_location", tile.Coords);
					}

					if (camp != null)
					{
						tile.TacticalType = this.Const.World.TerrainTacticalType.Desert;
						camp.onSpawned();
						camp.getSprite("selection").Visible = true;
						camp.setDiscovered(true);
						camp.setAttackable(true);
						camp.setOnEnterCallback(this.onDestinationAttacked.bindenv(this));
						this.World.uncoverFogOfWar(camp.getTile().Pos, 500.0);
						this.Contract.m.Destination = this.WeakTableRef(camp)
					}
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					this.Contract.setScreen("SearchingTheCamp");
					this.World.Contracts.showActiveContract();
					this.Contract.setState("Return");
				}
			}
			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
				this.Contract.setScreen("EnteringTheCamp");
				this.World.Contracts.showActiveContract();
			}

		});

		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.m.Screens.push({
			ID = "Task",
			Title = this.m.Title,
			Text = "根据传说，沙漠中的一个古老墓地保存着永葆青春的秘方。开始寻找配方!",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "别无选择",
					function getResult()
					{

						return "Overview_Building";
					}

				},
				{
					Text = "我现在不想开始这个任务.",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
			}

		});

		this.m.Screens.push({
			ID = "Overview_Building",
			Title = this.m.Title,
			Text = "你要开始这个任务吗?",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "是的.",
					function getResult()
					{
						this.Contract.setState("Running");
						return 0;
					}

				},
				{
					Text = "不要.",
					function getResult()
					{
						this.Contract.removeThisContract()
						return 0;
					}

				}
			],
			ShowObjectives = true,
			ShowPayment = true,
			ShowEmployer = true,
			ShowDifficulty = false,
			function start()
			{
				this.Contract.m.IsNegotiated = true;
			}
		});

		this.m.Screens.push({
			ID = "SearchingTheCamp",
			Title = "战斗之后...",
			Text = "[img]gfx/ui/events/event_161.png[/img]{击败守军后，你搜索遗体。你发现了一张古老的羊皮纸上写着无法辨认的文字。你还发现了一个瓶子，里面装满了奇怪的液体。液体就像水，但是通过玻璃很难分辨出它的真实性质。你怀疑这是传说中的愈合圣水。你懒洋洋地戳着附近骨骼的胸腔——这些骨骼被挑得干干净净，而且已经有一段时间了。要么烧瓶对他们没有任何好处，要么是他们在解开丝线后得到的.}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候回去了.",
					function getResult()
					{
						local item = this.new("scripts/items/special/fountain_of_youth_item");
						this.World.Assets.getStash().makeEmptySlots(1);
						this.World.Assets.getStash().add(item);
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/items/consumables/youth_01.png",
					text = "你会得到一个水囊和一张羊皮纸."
				});
			}
		});
		this.m.Screens.push({
			ID = "EnteringTheCamp",
			Title = "当你走近时",
			Text = "[img]gfx/ui/events/event_167.png[/img]{你发现了一个沙漠营地的遗迹。它被一块腌制过的人骨地毯所包围。中心的一些骷髅开始移动，一小队没有肉的亡灵聚集在一起——其中三名成员服饰非常很好，似乎远远高于其他人的地位。当你想知道这个可怜的群体是如何生存这么长时间的时候，地面开始隆隆作响，大群巨大的伊芙利特开始出现.}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "武装出击!",
					function getResult()
					{
						this.World.State.getLastLocation().setFaction(this.World.FactionManager.getFactionOfType(this.Const.FactionType.Beasts).getID());
						this.World.Contracts.showCombatDialog();
					}
				},
				{
				Text = "快跑 傻孩子",
					function getResult()
					{
						return 0;
					}
				}

			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "返回之后...",
			Text = "[img]gfx/ui/events/event_15.png[/img]{历史学家设法翻译了羊皮纸。它描述了创造愈合圣水的过程。非常昂贵-炼金术士公会相信他们会设法制造它.}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "好极了.",
					function getResult()
					{
						this.Stronghold.getPlayerFaction().m.Flags.set("Waterskin", true);
						this.Stronghold.getPlayerFaction().clearContracts()
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/items/consumables/youth_01.png",
					text = "你得到了一个药剂的配方"
				});

			}
		});
	}



	function onPrepareVariables( _vars )
	{
	}

	function onHomeSet()
	{
	}

	function onClear()
	{

		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.die()
			}
			this.World.FactionManager.getFaction(this.getFaction()).setActive(true);
			this.m.Home.getSprite("selection").Visible = false;

		}

	}

	function cancel()
	{
		this.onCancel();
	}
	function removeThisContract()
	{
		this.World.Contracts.removeContract(this);
		this.Stronghold.getPlayerFaction().updateQuests();
		this.World.State.getTownScreen().updateContracts();
	}

	function onSerialize( _out )
	{
		_out.writeI32(0);

		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}


		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		_in.readI32();
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}
		this.contract.onDeserialize(_in);

	}

});

