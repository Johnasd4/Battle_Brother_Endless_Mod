this.stronghold_free_mercenaries_contract <- this.inherit("scripts/contracts/contract", {
	//unlock hiring mercenaries
	//fight noble patrol going between two settlements
	//get hired mercenaries on success + flag in base to hire more in the future
	m = {
		Reward = 0,
		Target = null,
		Title = "解放雇佣兵",
		LastCombatTime = 0.0,
		Destination = null,
		Enemy_Faction = null
	},
	function create()
	{
		this.m.DifficultyMult = 1.0;
		this.m.Flags = this.new("scripts/tools/tag_collection");
		this.m.TempFlags = this.new("scripts/tools/tag_collection");
		this.createStates();
		this.createScreens();
		this.m.Type = "contract.stronghold_free_mercenaries_contract";
		this.m.Name = "解放雇佣兵";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 1500.0;
	}

	function onImportIntro()
	{
		#this.importSettlementIntro();
	}

	function start()
	{
		this.contract.start();
	}

	function getBanner()
	{
		return "ui/banners/factions/banner_09s"
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"拦截贵族军队",
					"不能让他们逃跑"
				];
				this.Contract.setScreen("Task");
			}

			function end()
			{
				this.World.Contracts.setActiveContract(this.Contract);
				this.Contract.setScreen("Overview_Building");
			}

		});

		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Target)
				{
					this.Contract.m.Target.getSprite("selection").Visible = true;
					this.Contract.m.Target.setVisibleInFogOfWar(true);
					this.Contract.m.Target.setOnCombatWithPlayerCallback(this.onTargetAttacked.bindenv(this));
					this.Contract.m.Enemy_Faction = this.Contract.m.Target.getFaction()
				}
				else
				{

					local playerBase = this.Contract.m.Home;
					local noble_factions = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
					local selected_faction = null;
					local selected_start_settlement = null;
					local selected_end_settlememt = null;
					local total_dist = 0;

					foreach (faction in noble_factions)
					{
						local settlements = faction.getSettlements()
						if (settlements.len() < 2)
						{
							continue;
						}
						local start_settlement = null
						local end_settlement = null
						local longestDistanceBetweenSettlements = 0
						local distFurthestFromBase = 0
						foreach (settlement in settlements)
						{
							if (!settlement.isIsolated() && settlement.getTile().getDistanceTo(playerBase.getTile()) > distFurthestFromBase)
							{
								start_settlement = settlement
								distFurthestFromBase = settlement.getTile().getDistanceTo(playerBase.getTile())
							}
						}
						if (start_settlement == null) continue
						foreach (settlement in settlements)
						{
							if (settlement != start_settlement && settlement.isMilitary() && settlement.isConnectedToByRoads(start_settlement) && settlement.getTile().getDistanceTo(start_settlement.getTile()) > longestDistanceBetweenSettlements)
							{
								end_settlement = settlement
								longestDistanceBetweenSettlements = settlement.getTile().getDistanceTo(start_settlement.getTile())
							}
						}
						if (end_settlement == null) continue
						if (selected_faction == null || longestDistanceBetweenSettlements > total_dist)
						{
							selected_faction = faction;
							total_dist = longestDistanceBetweenSettlements;
							selected_start_settlement = start_settlement
							selected_end_settlememt = end_settlement
						}
					}
					if (selected_end_settlememt == null || selected_start_settlement == null)
					{
						local settlements = this.World.EntityManager.getSettlements()
						local start_settlement = null
						local end_settlement = null
						local longestDistanceBetweenSettlements = 0
						local distFurthestFromBase = 0
						foreach (settlement in settlements)
						{
							if (!settlement.isIsolated() && settlement.m.Culture != this.Const.World.Culture.Southern && settlement.getTile().getDistanceTo(playerBase.getTile()) > distFurthestFromBase)
							{
								start_settlement = settlement
								distFurthestFromBase = settlement.getTile().getDistanceTo(playerBase.getTile())
							}
						}
						if (start_settlement != null)
						{
							foreach (settlement in settlements)
							{
								if (settlement != start_settlement && settlement.isAlliedWith( start_settlement ) && settlement.isMilitary() && settlement.isConnectedToByRoads(start_settlement)
									&& settlement.getTile().getDistanceTo(start_settlement.getTile()) > longestDistanceBetweenSettlements)
								{
									end_settlement = settlement
									longestDistanceBetweenSettlements = settlement.getTile().getDistanceTo(start_settlement.getTile())
								}
							}
						}
						if (end_settlement != null)
						{
							selected_faction = start_settlement.getFactionOfType(this.Const.FactionType.NobleHouse);
							total_dist = longestDistanceBetweenSettlements;
							selected_start_settlement = start_settlement
							selected_end_settlememt = end_settlement
						}
					}
					//failsafe
					if (selected_end_settlememt == null || selected_start_settlement == null)
					{
						this.logInfo("COULD NOT FIND EITHER START OR END SETTLEMENT")
						this.Contract.setState("Return");
					}

					local party = selected_faction.stronghold_spawnEntity(selected_start_settlement.getTile(), "Noble Army", false, this.Const.World.Spawn.Noble, 800);
					this.Const.World.Common.addTroop(party, {
							Type = this.Const.World.Spawn.Troops.Executioner
						}, true, 100);
					party.setDescription("一支由贵族士兵组成的军队，护送着囚犯。");
					party.setFootprintType(this.Const.World.FootprintsType.Nobles);
					party.setAttackableByAI(false);
					party.setVisibleInFogOfWar(true);
					party.setImportant(true);
					party.setDiscovered(true);
					party.setMovementSpeed(100);
					local c = party.getController();
					c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
					c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
					local move = this.new("scripts/ai/world/orders/move_order");
					move.setDestination(selected_end_settlememt.getTile());
					move.setRoadsOnly(true);
					local despawn = this.new("scripts/ai/world/orders/despawn_order");
					c.addOrder(move);
					c.addOrder(despawn);
					this.Contract.m.Flags.set("Survivors", 0);

					this.Contract.m.Target = this.WeakTableRef(party);
					this.Contract.m.Enemy_Faction = party.getFaction();
					this.Contract.m.Destination = this.WeakTableRef(selected_end_settlememt);

					this.Contract.m.Target.getSprite("selection").Visible = true;
					this.Contract.m.Target.setOnCombatWithPlayerCallback(this.onTargetAttacked.bindenv(this));
					this.Contract.m.Target.setVisibleInFogOfWar(true);
					this.Contract.m.BulletpointsObjectives = [
					"拦截贵族军队",
					"不要让他们到达" + selected_end_settlememt.getName() + " ."
					];

				}


			}


			function update()
			{
				if (this.Contract.m.Target == null || this.Contract.m.Target.isNull())
				{
					this.Contract.setScreen("TalkingToTheSurvivors");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isEntityAt(this.Contract.m.Target, this.Contract.m.Destination))
				{
					this.Contract.setScreen("Failure1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Target))
				{
					this.onTargetAttacked(this.Contract.m.Target, false);
				}
			}

			function onTargetAttacked( _dest, _isPlayerAttacking )
			{
				if (this.Time.getVirtualTimeF() >= this.Contract.m.LastCombatTime + 5.0)
				{
					this.World.FactionManager.getFaction(this.Contract.m.Enemy_Faction).setIsTemporaryEnemy(true);
					this.Contract.m.LastCombatTime = this.Time.getVirtualTimeF();
					this.World.Contracts.showCombatDialog(_isPlayerAttacking);
				}
			}

			function onActorRetreated( _actor, _combatID )
			{
				if (!_actor.isNonCombatant() && _actor.getFaction() == this.World.FactionManager.getFaction(this.Contract.m.Enemy_Faction).getID())
				{
					this.Contract.m.Flags.set("Survivors", this.Flags.get("Survivors") + 1);
				}
			}


		});

		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"Return to " + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					if (this.Contract.m.Flags.get("Survivors") > 3)
					{
						this.Contract.setScreen("Failure2");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.setScreen("Success1");
						this.World.Contracts.showActiveContract();
					}
				}
			}

		});
	}

	function createScreens()
	{
		this.m.Screens.push({
			ID = "Task",
			Title = this.m.Title,
			Text = "一伙雇佣兵正被运送到一座要塞，等待处决。我们必须帮助他们！",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "别无选择",
					function getResult()
					{

						return "Overview_Building";
					}

				},
				{
					Text = "我现在不想开始这个任务。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
			}

		});

		this.m.Screens.push({
			ID = "Overview_Building",
			Title = this.m.Title,
			Text = "在囚犯到达目的地之前拦截护送他们的队伍。并且不要让太多人逃跑！",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "是.",
					function getResult()
					{
						this.Contract.setState("Running");
						return 0;
					}

				},
				{
					Text = "不.",
					function getResult()
					{
						this.Contract.removeThisContract()
						return 0;
					}

				}
			],
			ShowObjectives = true,
			ShowPayment = true,
			ShowEmployer = true,
			ShowDifficulty = false,
			function start()
			{
				this.Contract.m.IsNegotiated = true;
			}
		});

		this.m.Screens.push({
			ID = "TalkingToTheSurvivors",
			Title = "战后...",
			Text = "[img]gfx/ui/events/event_53.png[/img]{击败贵族军队后，你将雇佣兵从枷锁中释放出来。他们开始搜查俘虏的身体，剥去他们能携带的任何东西——一部分是出于怨恨，一部分是出于迫切需要。当他们做完一切后表明已经准备好跟随你返回基地。}"
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候把孩子们带回家了。",
					function getResult()
					{
						this.Contract.spawnMercenaries();
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
			}
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来的时候...",
			Text = "[img]gfx/ui/events/event_53.png[/img]{雇佣兵获释后欣喜若狂。问他们是否能在你的基地安顿下来，你欣然同意：你需要强大的武装力量。他们会在本周余下的时间里跟随你，并在任何战斗中帮助你。}"
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "你们可以跟着我(合同结束)。",
					function getResult()
					{
						this.Stronghold.getPlayerFaction().m.Flags.set("Mercenaries", true);
						this.Stronghold.getPlayerFaction().clearContracts()
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				},
				{
					Text = "你们应该休息一下(重复合同)。",
					function getResult()
					{
						foreach ( unit in this.Stronghold.getPlayerFaction().m.Units){
							if (unit.getFlags().get("Stronghold_Mercenaries")){
								unit.fadeOutAndDie()
							}
						}
						this.Contract.m.Home.m.Flags.set("Mercenaries", true);
						this.Stronghold.getPlayerFaction().clearContracts()
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/events/event_134.png",
					text = "你现在可以招募雇佣兵了"
				});

			}
		});

		this.m.Screens.push({
			ID = "Failure1",
			Title = "你回来的时候...",
			Text = "[img]gfx/ui/events/event_95.png[/img]{你没能及时解救雇佣兵。他们将被抛弃，任由命运选择。你的选择！}"
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "太糟糕了",
					function getResult()
					{
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
			}
		});

		this.m.Screens.push({
			ID = "Failure2",
			Title = "你回来的时候...",
			Text = "[img]gfx/ui/events/event_53.png[/img]{雇佣军获释后欣喜若狂。他们问他们是否能在你的基地安顿下来，你欣然同意：你需要强大的武装力量。然而，你的城主告诉你，你的行为被发现了。有太多的逃跑士兵活着讲述他们的故事，贵族们宣布你为他们的敌人。}"
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "该死的!",
					function getResult()
					{
						this.Contract.m.Home.m.Flags.set("Mercenaries", true);
						this.World.FactionManager.getFaction(this.Contract.m.Enemy_Faction).addPlayerRelationEx( -50, "Murdered their men to free condemned criminals")
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/events/event_134.png",
					text = "你现在可以招募雇佣兵了"
				});

			}
		});
	}



	function onPrepareVariables( _vars )
	{
	}

	function onHomeSet()
	{
	}

	function onClear()
	{

		if (this.m.IsActive)
		{
			if (this.m.Target != null && !this.m.Target.isNull())
			{
				this.m.Target.getSprite("selection").Visible = false;
				this.m.Target.setOnCombatWithPlayerCallback(null);
			}
			this.World.FactionManager.getFaction(this.getFaction()).setActive(true);
			this.m.Home.getSprite("selection").Visible = false;

		}

	}

	function cancel()
	{
		this.onCancel();
	}
	function removeThisContract()
	{
		this.World.Contracts.removeContract(this);
		this.Stronghold.getPlayerFaction().updateQuests();
		this.World.State.getTownScreen().updateContracts();
	}
	function spawnMercenaries()
	{
		local playerBase =  this.getHome()
		local playerFaction = this.Stronghold.getPlayerFaction()
		local mercenary_size = 200
		mercenary_size += playerBase.countAttachedLocations( "attached_location.militia_trainingcamp" ) * this.Stronghold.Locations["Militia_Trainingcamp"].MercenaryStrengthIncrease

		local party = playerFaction.spawnEntity(this.World.State.getPlayer().getTile(), "Freed mercenaries", true, this.Const.World.Spawn.Mercenaries, mercenary_size);
		party.getSprite("body").setBrush("figure_mercenary_01");
		party.setDescription("一群雇佣兵跟着你。");
		party.setFootprintType(this.Const.World.FootprintsType.CityState);
		party.setMovementSpeed(200)
		party.getFlags().set("Stronghold_Mercenaries", true);
		local c = party.getController();
		c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false)
		c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false)
		local follow = this.new("scripts/ai/world/orders/stronghold_follow_order");
		follow.setDuration(7);
		c.addOrder(follow);
	}

	function onSerialize( _out )
	{
		_out.writeU8(this.m.Enemy_Faction);
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}
		if (this.m.Target != null && !this.m.Target.isNull())
		{
			_out.writeU32(this.m.Target.getID());
		}
		else
		{
			_out.writeU32(0);
		}



		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.m.Enemy_Faction = _in.readU8()

		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}
		local target = _in.readU32();

		if (target != 0)
		{
			this.m.Target = this.WeakTableRef(this.World.getEntityByID(target));
		}


		this.contract.onDeserialize(_in);

	}

});

