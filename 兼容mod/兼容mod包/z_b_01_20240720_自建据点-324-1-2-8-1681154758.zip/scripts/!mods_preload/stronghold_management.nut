local gt = this.getroottable();

gt.Stronghold.setupMainManagementOptions <- function()
{
	gt.Stronghold.Main_Management_Options <-
	[
		{
			Text = function(){
				return format("升级你的%s", this.getHome().getSizeName())
			}
			ID = "Upgrade",
			isValid = function(_contract){
				return _contract.isMainBase() && _contract.getHome().getSize() < this.Stronghold.MAX_BASE_SIZE && !_contract.getHome().isUpgrading()
			},
			onChosen = function(){
				if (this.World.Contracts.getActiveContract() != null)
				{
					this.m.Screens.push
					({
						ID = "Upgrade_Contract_Active",
						Title = "未满足要求",
						Text = "你不能在执行合同时升级你的基地!",
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好吧.")]
					})
					return "Upgrade_Contract_Active";
				}
				if (this.World.Retinue.getInventoryUpgrades() < this.getHome().getSize() + 1)
				{
					local current = this.Const.Strings.InventoryHeader[this.World.Retinue.getInventoryUpgrades()]
					local next = this.Const.Strings.InventoryHeader[this.World.Retinue.getInventoryUpgrades() + 1]
					this.m.Screens.push
					({
						ID = "Upgrade_Contract_Active",
						Title = "未满足要求",
						Text = format("在你能升级%s前! 你需要提升你的%s到%s。", this.getHome().getSizeName(), current, next),
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好吧.")]
					})
					return "Upgrade_Contract_Active";
				}
				local advantages = this.Stronghold.UnlockAdvantages[this.getHome().getSize()]
				this.setCost(this.Stronghold.PriceMult * this.Stronghold.BuyPrices[this.getHome().getSize()])
				local text =  "把你的" + this.getHome().getSizeName() + "升级为" + this.getHome().getSizeName(true) + "。新增以下功能: \n" + advantages +"\n 升级费用是" + this.getCost() + "克朗。\n升级时，您将无法访问大多数管理选项. \n\n小心：最近的贵族或敌人会试图摧毁你的基地。捍卫它吧！"
				this.addOverviewScreen(
					format("升级你的%s", this.getHome().getSizeName()),
					text
				)
				this.addEnoughScreen(
					"正在升级", 
					format("你开始把你的%s升级为%s", this.getHome().getSizeName(), this.getHome().getSizeName(true)),
					this.onUpgradeBought
				)
				return "Overview_Building"
			}
		},
		{
			Text = function(){
				return format("修建建筑", this.getHome().getSizeName())
			},
			ID = "Building",
			isValid = function(_contract){
				local current_buildings = 0;
				local free_building_slots = _contract.getHome().getSize() + 4
				foreach (building in _contract.getHome().m.Buildings){
					if (building != null){
						current_buildings++
					}
				}
				return current_buildings < free_building_slots && !_contract.getHome().isUpgrading()
			},
			onChosen = function(){
				//market and management are by default
				local current_buildings = -2;
				local total_building_slots = this.getHome().getSize() + 2
				foreach (building in this.getHome().m.Buildings){
					if (building != null){
						current_buildings++
					}
				}
				local text = format("可以在%s内修建一个新建筑。下面列表是您可选的建筑.", this.getHome().getSizeName())
				text += format("\n当前%s内有%i个建筑(总共%i个建筑位置)。", this.getHome().getSizeName(), current_buildings,total_building_slots )
				if (this.getHome().getSize() < 3) text += format("\n升级%s以解锁更多位置.", this.getHome().getSizeName())
				this.m.Screens.push
				({
					ID = "Building_Choice",
					Title = "选择一个建筑",
					Text = text,
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getBuildingOptions()
				})
				return "Building_Choice"
			}
		},
		{

			Text = function(){
				return format("拆除建筑", this.getHome().getSizeName())
			}
			ID = "Building_Remove",
			isValid = function(_contract){
				local current_buildings = 0;
				local free_building_slots = _contract.getHome().getSize() + 4
				foreach (building in _contract.getHome().m.Buildings){
					if (building != null){
						current_buildings++
					}	
				}
				return current_buildings >= free_building_slots && !_contract.getHome().isUpgrading()
			},
			onChosen = function(){
				this.m.Screens.push
				({
					ID = "Building_Remove_Choice",
					Title = "选择一个建筑",
					Text = "您可以选择拆除一个建筑。为其他建筑留出空间。",
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getBuildingRemoveOptions()
				})
				return "Building_Remove_Choice"	
			}
		},
		{
			Text = function(){
				return format("修建场所", this.getHome().getSizeName())
			},
			ID = "Location",
			isValid = function(_contract){
				local current_locations = 0;
				foreach (location in _contract.getHome().m.AttachedLocations){
					if (location != null && location.m.ID != "attached_location.harbor"){
						current_locations++
					}
				}
				return _contract.isMainBase() && current_locations < _contract.getHome().m.AttachedLocationsMax && !_contract.getHome().isUpgrading()
			},
			onChosen = function(){
				local current_buildings = 0;
				local total_building_slots = this.getHome().m.AttachedLocationsMax 
				foreach (location in this.getHome().m.AttachedLocations){
					if (location != null && location.m.ID != "attached_location.harbor"){
						current_buildings++
					}
				}
				local text = format("可以在%s附近新建一个场所。新场所可以提供各种好处。\n\n注意：场所建好后无法拆除，请先考虑好选择哪个！！", this.getHome().getSizeName())
				text += format("\n当前%s外有%i个场所(总共有%i个场所位置)。", this.getHome().getSizeName(),  current_buildings,total_building_slots)
				if (this.getHome().getSize() < 3) text += format("\n升级%s以解锁更多位置.", this.getHome().getSizeName())

				this.m.Screens.push
				({
					ID = "Location_Choice",
					Title = "选择一个场所",
					Text = text,
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getLocationOptions()
				})
				return "Location_Choice"
			}
		},
		{
			Text = function(){
				return "修建道路"
			},
			ID = "Road",
			isValid = function(_contract){
				return _contract.isMainBase() && _contract.getHome().m.Size > 1 && !_contract.getHome().isUpgrading()
			},
			onChosen = function(){
				this.m.Screens.push
				({
					ID = "Road_Choice",
					Title = "选择目的地",
					Text = "你可以修建一条通往另一个据点的道路。如果其他派系喜欢你，将允许货物和巡逻队互相流动。 \n希望你的路通向哪里?",
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getRoadOptions()
				})
				return "Road_Choice"
			}
		},
		{
			Text = function(){
				return "购买圣水"
				},
			ID = "Waterskin",
			isValid = function(_contract){
				return _contract.isMainBase() && _contract.getHome().isMaxLevel()
			},
			onChosen = function(){
				if (!this.Stronghold.getPlayerFaction().m.Flags.get("Waterskin"))
				{
					this.m.Screens.push
					({
						ID = "Waterskin",
						Title = "未满足要求",
						Text = "你问那些博学的人，能否为你制造一个神话般的愈合圣水。不幸的是，配方已经遗失。也许你能找回它（需要完成对应合同）。",
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好的.")]
					})
					return "Waterskin";
				}
				else
				{
					this.setCost(20 * this.Stronghold.PriceMult)
					this.addOverviewScreen(
						"购买愈合圣水",
						format("你选择购买一瓶愈合圣水。将花费%i克朗。", this.getCost())
					)
					this.addEnoughScreen(
						"购买愈合圣水",
						"你购买了一瓶愈合圣水.",
						this.onWaterSkinBought
					)
					
					this.m.Screens.push
					({
						ID = "Enough",
						Title = this.m.Title,
						Text = "你购买了一个愈合圣水.",
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [
							{
								Text = "好的.",
								function getResult(_option)
								{
									this.World.Assets.getStash().makeEmptySlots(1);
									this.World.Assets.addMoney(-this.Contract.getCost());
									local item = this.new("scripts/items/special/fountain_of_youth_item");
									this.World.Assets.getStash().add(item);
									this.Contract.removeThisContract()
									return 0;
								}

							}
						],
						function start()
						{
							this.List.push({
								id = 10,
								icon = "ui/items/consumables/youth_01.png",
								text = "你失去" +this.Contract.getCost() + "克朗."
							});
						}
					})
					return "Overview_Building"
				}
			}
		},
		{
			Text = function(){
				return "招募雇佣兵"
				},
			ID = "Mercenaries",
			isValid = function(_contract){
				return _contract.isMainBase() && _contract.getHome().isMaxLevel()
			},
			onChosen = function(){
				local has_mercs = false
				foreach ( unit in this.Stronghold.getPlayerFaction().m.Units){
					if (unit.getFlags().get("Stronghold_Mercenaries")){
						has_mercs = true
					}
				}
				if (!this.Stronghold.getPlayerFaction().m.Flags.get("Mercenaries"))
				{
					this.m.Screens.push
					({
						ID = "Mercs_Not_Freed",
						Title = "未满足要求",
						Text = "没有雇佣兵可供招募（需要完成对应合同）.",
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好的.")]
					})
					return "Mercs_Not_Freed";
				}
				else if (has_mercs)
				{
					this.m.Screens.push
					({
						ID = "Mercs_Already_Hired",
						Title = "未满足要求",
						Text = "你不能同时招募两队雇佣兵.",
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好的.")]
					})
					return "Mercs_Already_Hired";
				}
				else
				{
					this.setCost(20 * this.Stronghold.PriceMult)
					this.addOverviewScreen(
						"Hire mercenaries",
						format("你可以招募一队当地雇佣兵跟随你行动. 他们要求在一周的时间里得到%i克朗薪水.", this.getCost())
					)
					this.addEnoughScreen(
						"招募雇佣兵",
						"你招募了一队雇佣军。",
						this.onMercenariesHired
					)
					return "Overview_Building"
				}
			}
		},
		{
			Text = function(){
				return "新兵特训"
				},
			ID = "Teacher",
			isValid = function(_contract){
				return _contract.isMainBase() && _contract.getHome().isMaxLevel()
			},
			onChosen = function(){
				this.setCost(10 * this.Stronghold.PriceMult);
				if (!this.Stronghold.getPlayerFaction().m.Flags.get("Teacher"))
				{
					this.m.Screens.push
					({
						ID = "Teacher_Not_Freed",
						Title = "未满足要求",
						Text = "除了训练厅的服务外，这里没有人能提供训练（需要完成对应合同）.",
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好的.")]
					})
					return "Teacher_Not_Freed";
				}
				else {
					local text = format("这位传奇剑师每天都在磨练自己的技能。他可以给你的一个队友上一堂强化课程——但需要支付%i克朗。选择一个队友接受剑师的集中训练。", this.getCost())
					text += "\n\n[b]接下来10场战斗中可以获得1.5倍经验。[/b]"
					text += "\n[i]被选中的队友将失去所有训练厅的增益。[/i]"
				    this.m.Screens.push
					({
						ID = "Teacher_Choice",
						Title = "新兵特训",
						Text = text,
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = this.getTrainerOptions()
					})	
					return "Teacher_Choice"
				}	
			}
		},
		{
			Text = function(){
				return "派系送礼"
				},
			ID = "Gift",
			isValid = function(_contract){
				return _contract.isMainBase() && _contract.getHome().isMaxLevel()
			},
			onChosen = function(){
				local isValid = this.isGiftValid(true)
				if (isValid[0])
				{
					local text = "你可以选择给一个派系送礼物。这将消耗你库存中的贵重物品，并根据礼物的价值增加与该势力的关系。商队需要5000克朗来运输货物."
					text += "\n [i]将组建一个商队前往目的地。如果商队被劫掠，你就失去所有的投资。[/i]"
					text += "\n\n [i]与目标阵营获得相当于宝藏价值5%的关系提升。[/i]"
					text += "\n [i]贵重物品可以从营地和活动中获得，例如图章戒指。[/i]"
					
					this.m.Screens.push
					({
						ID = "Send_Gift",
						Title = "派系送礼",
						Text = text,
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = this.getGiftOptions()
					})
					return "Send_Gift"
				}
				else
				{
					local text = "你可以选择给一个派系送礼物。这将消耗你库存中的贵重物品，并根据礼物的价值增加与该势力的关系。商队需要5000克朗来运输货物\n\n"
					if (!isValid[1]) text += "送礼物至少需要5000克朗！\n"
					if (!isValid[2]) text += "你需要至少2个贵重物品在你的库存或仓库中来发送礼物！\n"
					if (!isValid[3]) text += "你无法通过道路联系到任何人，或者你已经是所有派系的朋友了！\n"
					this.m.Screens.push
					({
						ID = "Send_Gift_Failed",
						Title = "未满足要求",
						Text = text,
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [this.addGenericOption("好的.")]
					})
					return "Send_Gift_Failed";
				}
			}
		},
		{
			Text = function(){
				return "留置队友"
				},
			ID = "Store_Brother",
			isValid = function(_contract){
				if (!_contract.isMainBase()) return false
				local playerRoster = this.World.getPlayerRoster().getAll()
				return (playerRoster != null && playerRoster.len() > 1)
			},
			onChosen = function(){
				this.m.Screens.push
				({
					ID = "Store_Brother",
					Title = format("留置一名队友在%s里", this.getHome().getSizeName()),
					Text = "你想留下哪个队友？\n队友们在等你回来的时候只拿一半工资.",
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getStoreBrotherOptions()
				})
				return "Store_Brother";
			}
		},			
		{
			Text = function(){
				return "召回队友"
				},
			ID = "Retrieve_Brother",
			isValid = function(_contract){
				if (!_contract.isMainBase()) return false
				local playerRoster = _contract.getHome().getLocalRoster().getAll()
				return (playerRoster != null && playerRoster.len() > 0)
			},
			onChosen = function(){
				this.m.Screens.push
				({
					ID = "Retrieve_Brother",
					Title = "召回一名队友",
					Text = "你想召回哪名队友?",
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getRetrieveBrotherOptions()
				})
				return "Retrieve_Brother";
			}
		},			
		{
			Text = function(){
				return "建造村庄"
				},
			ID = "Hamlet",
			isValid = function(_contract){
				return (_contract.isMainBase() && _contract.getHome().isMaxLevel() && !_contract.getHome().getFlags().get("Child"))
			},
			onChosen = function(){
				this.setCost(20 * this.Stronghold.PriceMult);
				this.addOverviewScreen(
					"Build a Hamlet",
					format("你的大本营已经足够大了，很多普通人都会蜂拥而至。为这些人建造一个小村庄是明智的。这将花费%i克朗。", this.getCost())
				)
				this.addEnoughScreen(
					"建造村庄",
					"你建造了一个村庄。",
					this.onHamletBuild
				)
				return "Overview_Building"
			}
		},
		{
			Text = function(){
				return "改变外观"
				},
			ID = "Visual",
			isValid = function(_contract){
				//return _contract.isMainBase()
				return false
			},
			onChosen = function(){
				this.m.Screens.push
				({
					ID = "Change_Style",
					Title = "改变基地外观",
					Text = "你想要什么样子？",
					Image = "",
					List = [],
					ShowEmployer = true,
					Options = this.getBaseSyleOptions()
				})
				return "Change_Style";
			}
		},
		{
			Text = function(){
				return format("废弃你的%s", this.getHome().getSizeName())
				},
			ID = "Remove_Base",
			isValid = function(_contract){
				return !_contract.getHome().isUpgrading()
			},
			onChosen = function(){
				this.addOverviewScreen(
					"废弃基地",
					format("最后警告！你确定要废弃%s吗？", this.getHome().getSizeName())
				)
				if(this.World.Contracts.getActiveContract() != null)
				{
					this.m.Screens.push
					({
						ID = "Enough",
						Title = this.m.Title,
						Text = format("执行合同时，无法废弃%s!", this.getHome().getSizeName()),
						Image = "",
						List = [],
						ShowEmployer = true,
						Options = [
							this.addGenericOption("好的.")
						],
						function start()
						{
						}
					})
				}
				else 
				{
					this.addEnoughScreen(
						"Remove your base",
						format("你废弃了你的%s.", this.getHome().getSizeName()),
						this.onRemoveBase
					)
				}
				return "Overview_Building"
			}
		},
	]
}