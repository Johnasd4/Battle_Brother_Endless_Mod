local gt = this.getroottable();

gt.Stronghold.setupBuildingDefs <- function()
{
	gt.Stronghold.Building_options <-
	[
		{
			Name = "酒馆",
			ID = "building.tavern",
			Cost = this.Stronghold.BuildingPrices["Tavern"],
			Path = "tavern_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID))
			}
		},
		{
			Name = "狗舍",
			ID = "building.kennel",
			Cost = this.Stronghold.BuildingPrices["Kennel"],
			Path = "kennel_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID))
			}
		},
		{
			Name = "剥制师",
			ID = "building.taxidermist",
			SouthID = "building.taxidermist_oriental",
			Cost = this.Stronghold.BuildingPrices["Taxidermist"],
			Path = "taxidermist_building",
			SouthPath = "taxidermist_oriental_building",
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID) && !(_contract.getHome().hasBuilding(this.SouthID)))
			}
		},
		{
			Name = "神殿",
			ID = "building.temple",
			SouthID = "building.temple",
			Cost = this.Stronghold.BuildingPrices["Temple"],
			Path = "temple_building",
			SouthPath = "temple_oriental_building",
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID) && !(_contract.getHome().hasBuilding(this.SouthID)))
			}
		},
		{
			Name = "训练厅",
			ID = "building.training_hall",
			Cost = this.Stronghold.BuildingPrices["Training"],
			Path = "training_hall_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID))
			}
		},
		{
			Name = "炼金术士",
			ID = "building.alchemist",
			Cost = this.Stronghold.BuildingPrices["Alchemist"],
			Path = "alchemist_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID))
			}
		},
		{
			Name = "武器店",
			ID = "building.weaponsmith",
			SouthID = "building.weaponsmith_oriental",
			Cost = this.Stronghold.BuildingPrices["Weaponsmith"],
			Path = "weaponsmith_building",
			SouthPath = "weaponsmith_oriental_building",
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID) && !(_contract.getHome().hasBuilding(this.SouthID)))
			}
		},
		{
			Name = "盔甲店",
			ID = "building.armorsmith",
			SouthID = "building.armorsmith_oriental",
			Cost = this.Stronghold.BuildingPrices["Armorsmith"],
			Path = "armorsmith_building",
			SouthPath = "armorsmith_oriental_building",
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID) && !(_contract.getHome().hasBuilding(this.SouthID)))
			}
		},
		{
			Name = "弓弩店",
			ID = "building.fletcher",
			Cost = this.Stronghold.BuildingPrices["Fletcher"],
			Path = "fletcher_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID))
			}
		},
		{
			Name = "港口",
			ID = "building.port",
			Cost = this.Stronghold.BuildingPrices["Port"],
			Path = "port_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID) && _contract.getHome().isCoastal())
			}
		},
		{
			Name = "竞技场",
			ID = "building.arena",
			Cost = this.Stronghold.BuildingPrices["Arena"],
			Path = "arena_building",
			SouthPath = false,
			isValid = function(_contract){
				return (!_contract.getHome().hasBuilding(this.ID) && _contract.getHome().m.Size == 3)
			}
		},
	]
}