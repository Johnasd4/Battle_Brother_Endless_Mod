local gt = this.getroottable();

gt.Stronghold.setupLocationDefs <- function()
{
	gt.Stronghold.Location_options <-
	[
		{
			Name = "作坊",
			ID = "attached_location.workshop",
			ConstID = "Workshop",
			Cost = 0, //cost is set below this array
			Path = "workshop_location",
			Text = format("作坊的工人将为你制作工具。您可以每天收到%i个额外工具，您的仓库还能够再存储%i个。", 
				gt.Stronghold.Locations["Workshop"].DailyIncome, gt.Stronghold.Locations["Workshop"].MaxItemSlots),
			isValid = null //isValid is set below this array if null
		},
		{
			Name = "矿石冶炼厂",
			ID = "attached_location.ore_smelters",
			ConstID = "Ore_Smelter",
			Cost = 0,
			Path = "ore_smelters_location",
			Text = "矿石冶炼厂会使当地武器店拥有更多的装备。还可以使用稀有材料来重铸命名装备。\n把要重铸的命名装备放入基地仓库里，然后按住shift键并鼠标右键单击它。",
			isValid = null
		},
		{
			Name = "鼓风炉",
			ID = "attached_location.blast_furnace",
			ConstID = "Blast_Furnace",
			Cost = 0,
			Path = "blast_furnace_location",
			Text = format("鼓风炉使当地盔甲店拥有更多的装备。还能够更有效地修复你的盔甲，并给你%i的修理费折扣。",  
				((1 - gt.Stronghold.Locations["Blast_Furnace"].RepairMultiplier)*100).tointeger()),
			isValid = null
		},
		{
			Name = "石头岗楼",
			ID = "attached_location.stone_watchtower",
			ConstID = "Stone_Watchtower",
			Cost = 0,
			Path = "stone_watchtower_location",
			Text = "石头岗楼侦查基地附近游荡的部队。当你的队伍靠近基地时，会增加行动速度和视野。",
			isValid = null
		},
		{
			Name = "民兵营房",
			ID = "attached_location.militia_trainingcamp",
			ConstID = "Militia_Trainingcamp",
			Cost = 0,
			Path = "militia_trainingcamp_location",
			Text = format("民兵营房将训练留下来的队友。 每个营房每天产生%i经验，分给等级8以下的留置队友。\n此外，你的盟友雇佣兵也将在这里训练，增加雇佣兵队伍和商队的能力。\n如果你建造了村庄，也会增加%i个村庄雇佣地里人数。", 
					gt.Stronghold.Locations["Militia_Trainingcamp"].DailyIncome, gt.Stronghold.Locations["Militia_Trainingcamp"].RecruitIncrease),
			isValid = null
		},
		{
			Name = "麦田",
			ID = "attached_location.wheat_fields",
			ConstID = "Wheat_Fields",
			Cost = 0,
			Path = "wheat_fields_location",
			Text = "麦田为你基地附近的士兵提供食物。当你在基地周围时，将不消耗食物。",
			isValid = null
		},
		{
			Name = "药师小树林",
			ID = "attached_location.herbalists_grove",
			ConstID = "Herbalists_Grove",
			Cost = 0,
			Path = "herbalists_grove_location",
			Text = format("药师小树林的聪明女人知道如何用特殊而奇特的方法治疗伤口。在基地周围时，你队伍生命值恢复的更快。\n她们也会为你收集草药。您可以每天额外收到%i个药品，您的仓库还能够再存储%i个药品。", 
				gt.Stronghold.Locations["Herbalists_Grove"].DailyIncome, gt.Stronghold.Locations["Herbalists_Grove"].MaxItemSlots),
			isValid = null
		},
		{
			Name = "金矿",
			ID = "attached_location.gold_mine",
			ConstID = "Gold_Mine",
			Cost = 0,
			Path = "gold_mine_location",
			Text = format("雇佣矿工疯狂的进入挖掘。开采的黄金将被铸造成可消费的货币，每天生成%i个克朗。",
					gt.Stronghold.Locations["Gold_Mine"].DailyIncome),
			isValid = null
		}
	]

	foreach(location in gt.Stronghold.Location_options)
	{
		location.Cost = this.Stronghold.Locations[location.ConstID].Cost;
		if(location.isValid == null)
		{
			location.isValid = function(_contract)
			{
				return this.Stronghold.Locations[this.ConstID].MaxAmount > _contract.getHome().countAttachedLocations(this.ID)
			}.bindenv(location)
		}
	}
}