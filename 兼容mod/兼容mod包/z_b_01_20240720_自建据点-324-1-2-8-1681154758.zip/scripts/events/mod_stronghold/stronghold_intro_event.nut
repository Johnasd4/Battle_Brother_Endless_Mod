this.stronghold_intro_event <- this.inherit("scripts/events/event", {
	//calls success when caravan arrives at destination, works as an event
	m = {
	},
	function create()
	{
		this.m.ID = "event.stronghold_intro";
		this.m.Title = "大本营";
		this.m.IsSpecial = true;
		this.m.Cooldown = 1.0 * this.World.getTime().SecondsPerDay;
		local function coloredText(_text, _condition = true){
			if (_condition){
				return  "[color=" + this.Const.UI.Color.PositiveEventValue + "]" + _text + "[/color]"
			}
			return  "[color=" + this.Const.UI.Color.NegativeEventValue + "]" + _text + "[/color]"
		}
		
		local priceMult = this.Stronghold.PriceMult;
		local build_cost = this.Stronghold.BuyPrices[0] * priceMult;
		local levelOneName = this.Stronghold.BaseNames[0]

		local hasInventoryUpgrade = this.World.Retinue.getInventoryUpgrades() > 0
		local hasMoney = this.World.Assets.getMoney() >= build_cost
		local isTileOccupied = this.World.State.getPlayer().getTile().IsOccupied
		local hasContract = this.World.Contracts.getActiveContract() != null
		local isCoastal = this.Stronghold.isOnTile(this.World.State.getPlayer().getTile(), [this.Const.World.TerrainType.Ocean, this.Const.World.TerrainType.Shore])
		local hasRenown = this.World.Assets.getBusinessReputation() > 500;

		local isValid = hasRenown && hasInventoryUpgrade && hasMoney && !isTileOccupied && !hasContract

		local inventoryText = coloredText("\n-把你的驴子升级成大型载重货车.", hasInventoryUpgrade)
		local renownText = coloredText("\n-超过500的声望.", hasRenown)
		local moneyText = coloredText("\n-拥有10000克朗.", hasMoney)
		local tileText = coloredText("\n-身处空白地块.", !isTileOccupied)
		local contractText = coloredText("\n-没有正在执行的合同.", !hasContract)
		local coastalText = isCoastal ? coloredText("可以在这里建立一个港口.") : coloredText("不能在这里建港口，因为离海太远.", false);

		local requirementsText = "@@欢迎来到大本营。在这里你可以建立你的基地. 你将从一个小的" + levelOneName + "开始, 稍后可以升级以解锁更多功能."
		requirementsText += format("\n\n建造%s的要求: ", levelOneName)
		requirementsText += renownText + inventoryText + moneyText + tileText + contractText


		requirementsText += format("\n\n 建成%s后将解锁以下功能: \n%s", levelOneName, this.Stronghold.UnlockAdvantages[0])
		requirementsText += format("\n\n 此外, 你%s", coastalText)

		requirementsText += format("\n\n 建成了%s后, 可以点击要塞里的议事厅，打开管理菜单。可以通过点击要塞上名字来重新命名(游戏机制大地图不支持中文，建议用英文名称).", levelOneName)

		local A_options;
		if (isValid){
			requirementsText += coloredText(format("\n\n这里可以建造%s!", levelOneName)) + "  你要继续吗?"
		 	A_options = 
		 	[{
				Text = "是, 在这里建造"+ this.Stronghold.BaseNames[0],
				function getResult( _event )
				{
					return "Base_Option";
				}

			},
			{
				Text = "不",
				function getResult( _event )
				{
					_event.removeEvent()
					return 0;
				}

			}]
		}
		else{
			requirementsText += coloredText("\n\n当前还不能建造" + levelOneName + "!", false) + "  请满足所有要求后再来试试."
	 	 	A_options = 
	 	 	[{
 				Text = "好吧.",
 				function getResult( _event )
 				{
 					_event.removeEvent()
 					return 0;
 				}
	 		}]
		}
		this.m.Screens.push({
			ID = "A",
			Text = requirementsText,
			Image = "",
			List = [],
			Characters = [],
			Options = A_options,
			function start( _event )
			{
			}
		});

		this.m.Screens.push({
			ID = "Base_Option",
			Text = "你确定吗？期间会有敌人袭击，需要一个强大的队伍确保能击退攻击者.",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "是",
					function getResult( _event )
					{
						this.Stronghold.buildMainBase()
						_event.removeEvent()
						return 0
					}

				},
				{
					Text = "不",
					function getResult( _event )
					{
						_event.removeEvent()
						return 0;
					}

				}
			],
			function start( _event )
			{
			}
 
		});
	}
	
	function onPrepare()
	{
	}
	function onUpdateScore()
	{
	}

	function onPrepareVariables( _vars )
	{
	}

	function removeEvent()
	{
		local idx = 0
		foreach (event in this.World.Events.m.Events){
			if (event.getID() == this.getID()){
				this.World.Events.m.Events.remove(idx)
				return
			}
			idx++
		}
	}

});

