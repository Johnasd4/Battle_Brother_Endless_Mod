// See ui\screens\tooltip\modules\tooltip_module.js
TooltipModule.prototype.setupTileTooltip = function()
{
	var wnd = this.mParent; // $(window);

	var containerWidth = this.mContainer.outerWidth(true);
	var containerHeight = this.mContainer.outerHeight(true);

	var posLeft = this.mLastMouseX + (this.mCursorXOffset === 0 ? (this.mCursorWidth / 2) : (this.mCursorWidth - ((this.mCursorWidth / 2) - this.mCursorXOffset)) );
	var posTop = this.mLastMouseY + (this.mCursorYOffset === 0 ? (this.mCursorHeight / 2) : (this.mCursorHeight - ((this.mCursorHeight / 2) - this.mCursorYOffset)) );

	if (posLeft < 0)
	{
		posLeft = 10;
	}

	if (posLeft + containerWidth > wnd.width())
	{
		posLeft = wnd.width() - containerWidth - 10;
	}

	if ((posTop + containerHeight) > wnd.height())
	{
		posTop = this.mLastMouseY - (this.mCursorYOffset === 0 ? ((this.mCursorHeight / 2) + containerHeight) : (this.mCursorYOffset + containerHeight));
	}

	// mod_tactical_tooltip by MrBrut: Constrain the tooltip within visible screen.
	// https://www.nexusmods.com/battlebrothers/mods/266
	if (posTop < 0) {
		posTop = (wnd.height() - containerHeight) / 2;
		if (posTop < 0) {posTop = 10;}
	}
	// end of mod_tactical_tooltip.

	// show & position tooltip & animate
	this.mContainer.removeClass('display-none').addClass('display-block');
	this.mContainer.css({ left: posLeft, top: posTop });
	this.mContainer.velocity("finish", true).velocity({ opacity: 0.99 }, { duration: this.mFadeInTime }); // Anti Alias Fix
};
