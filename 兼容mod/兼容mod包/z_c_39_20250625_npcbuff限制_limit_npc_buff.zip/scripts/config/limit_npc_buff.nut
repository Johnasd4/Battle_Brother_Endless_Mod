local gt = this.getroottable();

//直接删除或注释整个大括号内容（如下）
	// {
	// 	//狂战士
	// 	Scripts = "scripts/skills/el_npc_buffs/el_berserker_npc_buff",
	// 	function EL_ifEligible(_EL_npc) {
	// 		if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
	// 		if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
	// 		if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
	// 		return true;
	// 	}
	// },

gt.Const.EL_NPC.EL_NPCBuff.Pool = [
	{
		//狂战士
		Scripts = "scripts/skills/el_npc_buffs/el_berserker_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//专注
		Scripts = "scripts/skills/el_npc_buffs/el_concentrate_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//致残
		Scripts = "scripts/skills/el_npc_buffs/el_cripple_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//激励
		Scripts = "scripts/skills/el_npc_buffs/el_encourage_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifMoraleStateIgnore(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//坚韧
		Scripts = "scripts/skills/el_npc_buffs/el_endurance_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//疲劳窃取
		Scripts = "scripts/skills/el_npc_buffs/el_energy_drain_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//能量护盾
		Scripts = "scripts/skills/el_npc_buffs/el_energy_shield_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//闪避
		Scripts = "scripts/skills/el_npc_buffs/el_evasion_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//成长
		Scripts = "scripts/skills/el_npc_buffs/el_growth_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//鹰眼
		Scripts = "scripts/skills/el_npc_buffs/el_hawk_eye_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(!this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifRanged(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//威慑
		Scripts = "scripts/skills/el_npc_buffs/el_intimidate_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifRanged(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//生命窃取
		Scripts = "scripts/skills/el_npc_buffs/el_life_drain_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//迅捷
		Scripts = "scripts/skills/el_npc_buffs/el_lightning_speed_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//多重攻击
		Scripts = "scripts/skills/el_npc_buffs/el_multiple_attacks_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifRanged(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//震荡
		Scripts = "scripts/skills/el_npc_buffs/el_oscillation_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return true; }
			if(!this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifRanged(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//淬毒
		Scripts = "scripts/skills/el_npc_buffs/el_poisoned_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//不死鸟
		Scripts = "scripts/skills/el_npc_buffs/el_phoenix_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//恢复
		Scripts = "scripts/skills/el_npc_buffs/el_recovery_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//复仇
		Scripts = "scripts/skills/el_npc_buffs/el_revenge_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//自爆
		Scripts = "scripts/skills/el_npc_buffs/el_self_destruct_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifRanged(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//印记
		Scripts = "scripts/skills/el_npc_buffs/el_stamp_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//巨力
		Scripts = "scripts/skills/el_npc_buffs/el_strength_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//重击
		Scripts = "scripts/skills/el_npc_buffs/el_stunning_strike_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//重装
		Scripts = "scripts/skills/el_npc_buffs/el_tank_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//硬化皮肤
		Scripts = "scripts/skills/el_npc_buffs/el_thick_skin_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifGhost(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//荆棘
		Scripts = "scripts/skills/el_npc_buffs/el_thron_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//老兵
		Scripts = "scripts/skills/el_npc_buffs/el_veteran_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//武器大师
		Scripts = "scripts/skills/el_npc_buffs/el_weapon_master_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	},
	{
		//凋零
		Scripts = "scripts/skills/el_npc_buffs/el_wither_npc_buff",
		function EL_ifEligible(_EL_npc) {
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifRanged(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifKraken(_EL_npc)) { return false; }
			if(this.Const.EL_NPC.EL_NPCBuff.EligibleFunction.EL_ifNoBuff(_EL_npc)) { return false; }
			return true;
		}
	}
]