﻿var wtTranslateLargeFishingVillage = TranslateLargeFishingVillage;
TranslateLargeFishingVillage = function (text)
{
text = wtTranslateLargeFishingVillage.call(this,text);
text = text.replace("zuo yun","左云");
text = text.replace("zuo quan","左权");
text = text.replace("zuo gong","左贡");
text = text.replace("zun yi","遵义");
text = text.replace("zun hua","遵化");
text = text.replace("zi xing","资兴");
text = text.replace("zhuo zi","卓资");
text = text.replace("zhuo zhou","涿州");
text = text.replace("zhuo ni","卓尼");
text = text.replace("zhuo lu","涿鹿");
text = text.replace("zhuang lang","庄浪");
text = text.replace("zhuang he","庄河");
text = text.replace("zhu zhou","株洲");
text = text.replace("zhu ji","诸暨");
text = text.replace("zhu hai","珠海");
text = text.replace("zhu bei","竹北");
text = text.replace("zhou zhi","周至");
text = text.replace("zhou shan","舟山");
text = text.replace("zhou qu","舟曲");
text = text.replace("zhong xi","中西");
text = text.replace("zhong fang","中方");
text = text.replace("zhong ba","仲巴");
text = text.replace("zhi jin","织金");
text = text.replace("zheng he","政和");
text = text.replace("zheng ding","正定");
text = text.replace("zheng an","正安");
text = text.replace("zhen yuan","镇远");
text = text.replace("zhen xiong","镇雄");
text = text.replace("zhen ning","镇宁");
text = text.replace("zhen lai","镇赉");
text = text.replace("zhen kang","镇康");
text = text.replace("zhen jiang","镇江");
text = text.replace("zhen feng","贞丰");
text = text.replace("zhao zhou","肇州");
text = text.replace("zhao yuan","肇源");
text = text.replace("zhao tong","昭通");
text = text.replace("zhao su","昭苏");
text = text.replace("zhao jue","昭觉");
text = text.replace("zhao dong","肇东");
text = text.replace("zhao an","诏安");
text = text.replace("zhang zhou","漳州");
text = text.replace("zhang ye","张掖");
text = text.replace("zhang wu","彰武");
text = text.replace("zhang ping","漳平");
text = text.replace("zhang jia kou","张家口");
text = text.replace("zhang jia jie","张家界");
text = text.replace("zhang jia chuan","张家川");
text = text.replace("zhang hua","彰化");
text = text.replace("zhang bei","张北");
text = text.replace("zhan yi","沾益");
text = text.replace("zhan jiang","湛江");
text = text.replace("zha nan","扎囊");
text = text.replace("zha da","札达");
text = text.replace("zha bei","闸北");
text = text.replace("zeng cheng","增城");
text = text.replace("ze zhou","泽州");
text = text.replace("ze pu","泽普");
text = text.replace("zao qiang","枣强");
text = text.replace("zan huang","赞皇");
text = text.replace("yun xiao","云霄");
text = text.replace("yun long","云龙");
text = text.replace("yun lin","云林");
text = text.replace("yun he","云和");
text = text.replace("yun cheng","运城");
text = text.replace("yue yang","岳阳");
text = text.replace("yue xi","越西");
text = text.replace("yue pu hu","岳普湖");
text = text.replace("yuan yang","元阳");
text = text.replace("yuan shi","元氏");
text = text.replace("yuan qu","垣曲");
text = text.replace("yuan ping","原平");
text = text.replace("yuan mou","元谋");
text = text.replace("yuan ling","沅陵");
text = text.replace("yuan lang","元朗");
text = text.replace("yuan jiang","沅江");
text = text.replace("yu zhong","榆中");
text = text.replace("yu yao","余姚");
text = text.replace("yu xi","玉溪");
text = text.replace("yu tian","玉田");
text = text.replace("yu shu","榆树");
text = text.replace("yu she","榆社");
text = text.replace("yu qing","余庆");
text = text.replace("yu ping","玉屏");
text = text.replace("yu min","裕民");
text = text.replace("yu men","玉门");
text = text.replace("yu jiang","余江");
text = text.replace("yu huan","玉环");
text = text.replace("you yu","右玉");
text = text.replace("you yi","友谊");
text = text.replace("you xi","尤溪");
text = text.replace("yong zhou","永州");
text = text.replace("yong xing","永兴");
text = text.replace("yong tai","永泰");
text = text.replace("yong shun","永顺");
text = text.replace("yong shou","永寿");
text = text.replace("yong sheng","永胜");
text = text.replace("yong shan","永善");
text = text.replace("yong ren","永仁");
text = text.replace("yong qing","永清");
text = text.replace("yong ping","永平");
text = text.replace("yong ning","永宁");
text = text.replace("yong nian","永年");
text = text.replace("yong kang","永康");
text = text.replace("yong jing","永靖");
text = text.replace("yong jia","永嘉");
text = text.replace("yong ji","永济");
text = text.replace("yong he","永和");
text = text.replace("yong deng","永登");
text = text.replace("yong de","永德");
text = text.replace("yong chun","永春");
text = text.replace("yong chang","永昌");
text = text.replace("yong an","永安");
text = text.replace("ying tan","鹰潭");
text = text.replace("ying kou","营口");
text = text.replace("ying jiang","盈江");
text = text.replace("ying ji sha","英吉沙");
text = text.replace("yin chuan","银川");
text = text.replace("yi zheng","仪征");
text = text.replace("yi zhang","宜章");
text = text.replace("yi yang","益阳");
text = text.replace("yi xing","宜兴");
text = text.replace("yi wu","义乌");
text = text.replace("yi ning","伊宁");
text = text.replace("yi men","易门");
text = text.replace("yi liang","宜良");
text = text.replace("yi lan","宜兰");
text = text.replace("yi jun","宜君");
text = text.replace("yi chun","伊春");
text = text.replace("yi cheng","翼城");
text = text.replace("yi an","依安");
text = text.replace("ye cheng","叶城");
text = text.replace("yao an","姚安");
text = text.replace("yang zhou","扬州");
text = text.replace("yang zhong","扬中");
text = text.replace("yang yuan","阳原");
text = text.replace("yang quan","阳泉");
text = text.replace("yang qu","阳曲");
text = text.replace("yang pu","杨浦");
text = text.replace("yang gao","阳高");
text = text.replace("yang cheng","阳城");
text = text.replace("yan yuan","盐源");
text = text.replace("yan shou","延寿");
text = text.replace("yan shi","焉耆");
text = text.replace("yan shan","盐山");
text = text.replace("yan ling","炎陵");
text = text.replace("yan jin","延津");
text = text.replace("yan ji","延吉");
text = text.replace("yan he","沿河");
text = text.replace("yan chi","盐池");
text = text.replace("yan cheng","盐城");
text = text.replace("ya jiang","雅江");
text = text.replace("ya dong","亚东");
text = text.replace("xun wu","寻乌");
text = text.replace("xun ke","逊克");
text = text.replace("xuan wei","宣威");
text = text.replace("xuan hua","宣化");
text = text.replace("xu zhou","徐州");
text = text.replace("xu wen","徐闻");
text = text.replace("xu shui","徐水");
text = text.replace("xu pu","溆浦");
text = text.replace("xu hui","徐汇");
text = text.replace("xu chi","盱眙");
text = text.replace("xiu yan","岫岩");
text = text.replace("xiu wu","修武");
text = text.replace("xiu wen","修文");
text = text.replace("xiu shui","修水");
text = text.replace("xing yi","兴义");
text = text.replace("xing tang","行唐");
text = text.replace("xing tai","邢台");
text = text.replace("xing ren","兴仁");
text = text.replace("xing long","兴隆");
text = text.replace("xing hua","兴化");
text = text.replace("xing he","兴和");
text = text.replace("xing guo","兴国");
text = text.replace("xing cheng","兴城");
text = text.replace("xing an meng","兴安盟");
text = text.replace("xin zhu","新竹");
text = text.replace("xin zhou","忻州");
text = text.replace("xin yuan","新源");
text = text.replace("xin yu","新余");
text = text.replace("xin ying","新营");
text = text.replace("xin yi","新沂");
text = text.replace("xin xiang","新乡");
text = text.replace("xin tian","新田");
text = text.replace("xin shao","新邵");
text = text.replace("xin ning","新宁");
text = text.replace("xin min","新民");
text = text.replace("xin long","新龙");
text = text.replace("xin le","新乐");
text = text.replace("xin jiang","新绛");
text = text.replace("xin jian","新建");
text = text.replace("xin ji","辛集");
text = text.replace("xin he","新河");
text = text.replace("xin feng","新丰");
text = text.replace("xin chang","新昌");
text = text.replace("xin bin","新宾");
text = text.replace("xie tong men","谢通门");
text = text.replace("xiang yun","祥云");
text = text.replace("xiang yuan","襄垣");
text = text.replace("xiang yin","湘阴");
text = text.replace("xiang xiang","湘乡");
text = text.replace("xiang shui","响水");
text = text.replace("xiang shan","象山");
text = text.replace("xiang he","香河");
text = text.replace("xiang fen","襄汾");
text = text.replace("xiang cheng","乡城");
text = text.replace("xian you","仙游");
text = text.replace("xian yang","咸阳");
text = text.replace("xian ji","仙居");
text = text.replace("xia men","厦门");
text = text.replace("xia he","夏河");
text = text.replace("xi yang","昔阳");
text = text.replace("xi shui","习水");
text = text.replace("xi qing","西青");
text = text.replace("xi ning","西宁");
text = text.replace("xi he","西和");
text = text.replace("xi gong","西贡");
text = text.replace("xi feng","西丰");
text = text.replace("xi de","喜德");
text = text.replace("xi chou","西畴");
text = text.replace("xi chang","西昌");
text = text.replace("xi an","西安");
text = text.replace("wu zhong","吴忠");
text = text.replace("wu zhai","五寨");
text = text.replace("wu yuan","五原");
text = text.replace("wu yi","武邑");
text = text.replace("wu xiang","武乡");
text = text.replace("wu xi","无锡");
text = text.replace("wu wei","无为");
text = text.replace("wu tai","五台");
text = text.replace("wu su","乌苏");
text = text.replace("wu shi","乌什");
text = text.replace("wu shen","乌审");
text = text.replace("wu shan","武山");
text = text.replace("wu qing","武清");
text = text.replace("wu qiao","吴桥");
text = text.replace("wu qiang","武强");
text = text.replace("wu qia","乌恰");
text = text.replace("wu ping","武平");
text = text.replace("wu jiang","吴江");
text = text.replace("wu jia qu","五家渠");
text = text.replace("wu ji","无极");
text = text.replace("wu han","武汉");
text = text.replace("wu hai","乌海");
text = text.replace("wu gong","武功");
text = text.replace("wu gang","武冈");
text = text.replace("wu ding","武定");
text = text.replace("wu chuan","武川");
text = text.replace("wu chang","五常");
text = text.replace("wu an","武安");
text = text.replace("weng yuan","翁源");
text = text.replace("weng an","瓮安");
text = text.replace("wen zhou","温州");
text = text.replace("wen xi","闻喜");
text = text.replace("wen su","温宿");
text = text.replace("wen shan","文山");
text = text.replace("wen quan","温泉");
text = text.replace("wen cheng","文成");
text = text.replace("wen an","文安");
text = text.replace("wei yuan","渭源");
text = text.replace("wei xin","威信");
text = text.replace("wei nan","渭南");
text = text.replace("wei li","尉犁");
text = text.replace("wei hui","卫辉");
text = text.replace("wang qing","汪清");
text = text.replace("wang mo","望谟");
text = text.replace("wang kui","望奎");
text = text.replace("wang du","望都");
text = text.replace("wang cheng","望城");
text = text.replace("wan zi","湾仔");
text = text.replace("wan shan","万山");
text = text.replace("wan rong","万荣");
text = text.replace("wan quan","万全");
text = text.replace("wa fang dian","瓦房店");
text = text.replace("tuo li","托里");
text = text.replace("tuo ke xun","托克逊");
text = text.replace("tun men","屯门");
text = text.replace("tun liu","屯留");
text = text.replace("tu quan","突泉");
text = text.replace("tu mu","图木");
text = text.replace("tu men","图们");
text = text.replace("tu lu fan","吐鲁番");
text = text.replace("tong zi","桐梓");
text = text.replace("tong zhou","通州");
text = text.replace("tong yu","通榆");
text = text.replace("tong xin","同心");
text = text.replace("tong xiang","桐乡");
text = text.replace("tong wei","通渭");
text = text.replace("tong shan","铜山");
text = text.replace("tong ren","同仁");
text = text.replace("tong lu","桐庐");
text = text.replace("tong ling","铜陵");
text = text.replace("tong liao","通辽");
text = text.replace("tong jiang","同江");
text = text.replace("tong hua","通化");
text = text.replace("tong he","通河");
text = text.replace("tong hai","通海");
text = text.replace("tong guan","潼关");
text = text.replace("tong chuan","铜川");
text = text.replace("tong cheng","桐城");
text = text.replace("tie ling","铁岭");
text = text.replace("tie li","铁力");
text = text.replace("tian zhu","天柱");
text = text.replace("tian zhen","天镇");
text = text.replace("tian tai","天台");
text = text.replace("tian shui","天水");
text = text.replace("tian jin","天津");
text = text.replace("tian chang","天长");
text = text.replace("teng chong","腾冲");
text = text.replace("te ke si","特克斯");
text = text.replace("tao yuan","桃源");
text = text.replace("tao jiang","桃江");
text = text.replace("tang yuan","汤原");
text = text.replace("tang shan","唐山");
text = text.replace("tang hai","唐海");
text = text.replace("tang gu","塘沽");
text = text.replace("tai zhou","泰州");
text = text.replace("tai zhong","台中");
text = text.replace("tai yuan","太原");
text = text.replace("tai xing","泰兴");
text = text.replace("tai shun","泰顺");
text = text.replace("tai shan","台山");
text = text.replace("tai ning","泰宁");
text = text.replace("tai nan","台南");
text = text.replace("tai lai","泰来");
text = text.replace("tai jiang","台江");
text = text.replace("tai gu","太谷");
text = text.replace("tai dong","台东");
text = text.replace("tai cang","太仓");
text = text.replace("tai bei","台北");
text = text.replace("tai bao","太保");
text = text.replace("tai bai","太白");
text = text.replace("tai an","台安");
text = text.replace("ta shi ku","塔什库");
text = text.replace("ta he","塔河");
text = text.replace("ta cheng","塔城");
text = text.replace("sun wu","孙吴");
text = text.replace("sui zhong","绥中");
text = text.replace("sui yang","绥阳");
text = text.replace("sui xi","遂溪");
text = text.replace("sui ning","绥宁");
text = text.replace("sui ling","绥棱");
text = text.replace("sui jiang","绥江");
text = text.replace("sui hua","绥化");
text = text.replace("sui chang","遂昌");
text = text.replace("sui bin","绥滨");
text = text.replace("su zhou","苏州");
text = text.replace("su qian","宿迁");
text = text.replace("su ning","肃宁");
text = text.replace("su nan","肃南");
text = text.replace("su bei","肃北");
text = text.replace("song yuan","松原");
text = text.replace("song yang","松阳");
text = text.replace("song xi","松溪");
text = text.replace("song tao","松桃");
text = text.replace("song pan","松潘");
text = text.replace("song ming","嵩明");
text = text.replace("song jiang","松江");
text = text.replace("si yang","泗阳");
text = text.replace("si ping","四平");
text = text.replace("si nan","思南");
text = text.replace("si mao","思茅");
text = text.replace("si hong","泗洪");
text = text.replace("shuo zhou","朔州");
text = text.replace("shun ping","顺平");
text = text.replace("shun chang","顺昌");
text = text.replace("shui fu","水富");
text = text.replace("shui cheng","水城");
text = text.replace("shuang pai","双牌");
text = text.replace("shuang liao","双辽");
text = text.replace("shuang feng","双峰");
text = text.replace("shuang cheng","双城");
text = text.replace("shuang bai","双柏");
text = text.replace("shu yang","沭阳");
text = text.replace("shu le","疏勒");
text = text.replace("shu lan","舒兰");
text = text.replace("shu fu","疏附");
text = text.replace("shou yang","寿阳");
text = text.replace("shi zong","师宗");
text = text.replace("shi xing","始兴");
text = text.replace("shi shi","石狮");
text = text.replace("shi qu","石渠");
text = text.replace("shi qian","石阡");
text = text.replace("shi ping","石屏");
text = text.replace("shi men","石门");
text = text.replace("shi jia zhuang","石家庄");
text = text.replace("shi he zi","石河子");
text = text.replace("shi dian","施甸");
text = text.replace("shi cheng","石城");
text = text.replace("shi bing","施秉");
text = text.replace("shen zhou","深州");
text = text.replace("shen zha","申扎");
text = text.replace("shen ze","深泽");
text = text.replace("shen yang","沈阳");
text = text.replace("shen chou","深圳");
text = text.replace("shen chi","神池");
text = text.replace("she yang","射阳");
text = text.replace("shao yang","邵阳");
text = text.replace("shao xing","绍兴");
text = text.replace("shao wu","邵武");
text = text.replace("shao shan","韶山");
text = text.replace("shao guan","韶关");
text = text.replace("shao dong","邵东");
text = text.replace("shang zhi","尚志");
text = text.replace("shang yu","上虞");
text = text.replace("shang yi","尚义");
text = text.replace("shang hang","上杭");
text = text.replace("shang hai","上海");
text = text.replace("shang du","商都");
text = text.replace("shan yin","山阴");
text = text.replace("shan tou","汕头");
text = text.replace("shan shan","鄯善");
text = text.replace("shan dan","山丹");
text = text.replace("sha ya","沙雅");
text = text.replace("sha wan","沙湾");
text = text.replace("sha tian","沙田");
text = text.replace("sha he","沙河");
text = text.replace("sha che","莎车");
text = text.replace("se da","色达");
text = text.replace("sang zhi","桑植");
text = text.replace("sang ri","桑日");
text = text.replace("san sui","三穗");
text = text.replace("san men","三门");
text = text.replace("san he","三河");
text = text.replace("san du","三都");
text = text.replace("sa jia","萨迦");
text = text.replace("sa ga","萨嘎");
text = text.replace("ruo qiang","若羌");
text = text.replace("rui li","瑞丽");
text = text.replace("rui jin","瑞金");
text = text.replace("rui cheng","芮城");
text = text.replace("rui an","瑞安");
text = text.replace("ru gao","如皋");
text = text.replace("ru dong","如东");
text = text.replace("ru cheng","汝城");
text = text.replace("rong jiang","榕江");
text = text.replace("rong cheng","容城");
text = text.replace("ri tu","日土");
text = text.replace("ri ka ze","日喀则");
text = text.replace("ren qiu","任丘");
text = text.replace("ren huai","仁怀");
text = text.replace("ren hua","仁化");
text = text.replace("ren bu","仁布");
text = text.replace("rao yang","饶阳");
text = text.replace("rao he","饶河");
text = text.replace("rang tang","壤塘");
text = text.replace("quan zhou","泉州");
text = text.replace("quan wan","荃湾");
text = text.replace("qu zhou","曲周");
text = text.replace("qu yang","曲阳");
text = text.replace("qu song","曲松");
text = text.replace("qu shui","曲水");
text = text.replace("qu jing","曲靖");
text = text.replace("qiu bei","丘北");
text = text.replace("qiong jie","琼结");
text = text.replace("qing zhen","清镇");
text = text.replace("qing yuan","清原");
text = text.replace("qing yang","庆阳");
text = text.replace("qing xu","清徐");
text = text.replace("qing tian","青田");
text = text.replace("qing shui","清水");
text = text.replace("qing pu","青浦");
text = text.replace("qing long","青龙");
text = text.replace("qing liu","清流");
text = text.replace("qing he","青河");
text = text.replace("qing gang","青冈");
text = text.replace("qing cheng","庆城");
text = text.replace("qing an","庆安");
text = text.replace("qin yuan","沁源");
text = text.replace("qin yang","沁阳");
text = text.replace("qin shui","沁水");
text = text.replace("qin huang dao","秦皇岛");
text = text.replace("qin an","秦安");
text = text.replace("qie mo","且末");
text = text.replace("qiao jia","巧家");
text = text.replace("qian yang","千阳");
text = text.replace("qian xi","黔西");
text = text.replace("qian an","迁安");
text = text.replace("qi yang","祁阳");
text = text.replace("qi tai","奇台");
text = text.replace("qi shan","岐山");
text = text.replace("qi lian","祁连");
text = text.replace("qi dong","启东");
text = text.replace("pu tuo","普陀");
text = text.replace("pu tian","莆田");
text = text.replace("pu lan dian","普兰店");
text = text.replace("pu lan","普兰");
text = text.replace("pu jiang","浦江");
text = text.replace("pu ge","普格");
text = text.replace("pu ding","普定");
text = text.replace("pu cheng","浦城");
text = text.replace("pu an","普安");
text = text.replace("ping yao","平遥");
text = text.replace("ping yang","平阳");
text = text.replace("ping xiang","平乡");
text = text.replace("ping tang","平塘");
text = text.replace("ping tan","平潭");
text = text.replace("ping shun","平顺");
text = text.replace("ping shan","平山");
text = text.replace("ping quan","平泉");
text = text.replace("ping luo","平罗");
text = text.replace("ping lu","平陆");
text = text.replace("ping liang","平凉");
text = text.replace("ping jiang","平江");
text = text.replace("ping hu","平湖");
text = text.replace("ping he","平和");
text = text.replace("ping dong","屏东");
text = text.replace("ping ding","平定");
text = text.replace("ping ba","平坝");
text = text.replace("ping an","平安");
text = text.replace("pian guan","偏关");
text = text.replace("pi zhou","邳州");
text = text.replace("pi shan","皮山");
text = text.replace("peng hu","澎湖");
text = text.replace("pan shi","磐石");
text = text.replace("pan shan","盘山");
text = text.replace("pan jin","盘锦");
text = text.replace("pan an","磐安");
text = text.replace("nong an","农安");
text = text.replace("ning yuan","宁远");
text = text.replace("ning xiang","宁乡");
text = text.replace("ning wu","宁武");
text = text.replace("ning nan","宁南");
text = text.replace("ning jin","宁晋");
text = text.replace("ning hua","宁化");
text = text.replace("ning he","宁河");
text = text.replace("ning hai","宁海");
text = text.replace("ning du","宁都");
text = text.replace("ning de","宁德");
text = text.replace("ning cheng","宁城");
text = text.replace("ning bo","宁波");
text = text.replace("ning an","宁安");
text = text.replace("nie rong","聂荣");
text = text.replace("nie la mu","聂拉木");
text = text.replace("ni mu","尼木");
text = text.replace("ni ma","尼玛");
text = text.replace("ni le ke","尼勒克");
text = text.replace("nen jiang","嫩江");
text = text.replace("nei qiu","内丘");
text = text.replace("ne he","讷河");
text = text.replace("nan xiong","南雄");
text = text.replace("nan tou","南投");
text = text.replace("nan tong","南通");
text = text.replace("nan ping","南平");
text = text.replace("nan pi","南皮");
text = text.replace("nan mu","南木");
text = text.replace("nan kang","南康");
text = text.replace("nan kai","南开");
text = text.replace("nan jing","南京");
text = text.replace("nan hui","南汇");
text = text.replace("nan hua","南华");
text = text.replace("nan he","南和");
text = text.replace("nan gong","南宫");
text = text.replace("nan chang","南昌");
text = text.replace("nan ao","南澳");
text = text.replace("nan an","南安");
text = text.replace("nai man","奈曼");
text = text.replace("nai dong","乃东");
text = text.replace("na yong","纳雍");
text = text.replace("na qu","那曲");
text = text.replace("mu ling","穆棱");
text = text.replace("mu lei","木垒");
text = text.replace("mu lan","木兰");
text = text.replace("mou ding","牟定");
text = text.replace("mo zhu","墨竹");
text = text.replace("mo yu","墨玉");
text = text.replace("mo tuo","墨脱");
text = text.replace("mo he","漠河");
text = text.replace("ming xi","明溪");
text = text.replace("ming shui","明水");
text = text.replace("ming guang","明光");
text = text.replace("min xing","闵行");
text = text.replace("min qing","闽清");
text = text.replace("min qin","民勤");
text = text.replace("min le","民乐");
text = text.replace("min hou","闽侯");
text = text.replace("min feng","民丰");
text = text.replace("miao li","苗栗");
text = text.replace("mian ning","冕宁");
text = text.replace("mi shan","密山");
text = text.replace("mi quan","米泉");
text = text.replace("mi luo","汨罗");
text = text.replace("mi lin","米林");
text = text.replace("mi le","弥勒");
text = text.replace("mi du","弥渡");
text = text.replace("meng zi","蒙自");
text = text.replace("meng zhou","孟州");
text = text.replace("meng hai","勐海");
text = text.replace("meng cun","孟村");
text = text.replace("mei tan","湄潭");
text = text.replace("mei gu","美姑");
text = text.replace("mao ming","茂名");
text = text.replace("mang kang","芒康");
text = text.replace("man cheng","满城");
text = text.replace("mai gai ti","麦盖提");
text = text.replace("ma qu","玛曲");
text = text.replace("ma na si","玛纳斯");
text = text.replace("ma long","马龙");
text = text.replace("ma jiang","麻江");
text = text.replace("ma guan","马关");
text = text.replace("ma gong","马公");
text = text.replace("lv chun","绿春");
text = text.replace("luo zha","洛扎");
text = text.replace("luo yuan","罗源");
text = text.replace("luo pu","洛浦");
text = text.replace("luo ping","罗平");
text = text.replace("luo long","洛隆");
text = text.replace("luo dian","罗甸");
text = text.replace("luo bei","萝北");
text = text.replace("lun tai","轮台");
text = text.replace("luan ping","滦平");
text = text.replace("luan nan","滦南");
text = text.replace("luan cheng","栾城");
text = text.replace("lu xi","泸溪");
text = text.replace("lu wan","卢湾");
text = text.replace("lu shui","泸水");
text = text.replace("lu quan","鹿泉");
text = text.replace("lu qu","碌曲");
text = text.replace("lu long","卢龙");
text = text.replace("lu liang","陆良");
text = text.replace("lu huo","炉霍");
text = text.replace("lu feng","禄丰");
text = text.replace("lu ding","泸定");
text = text.replace("lu dian","鲁甸");
text = text.replace("lu cheng","潞城");
text = text.replace("lou fan","娄烦");
text = text.replace("lou di","娄底");
text = text.replace("long zi","隆子");
text = text.replace("long you","龙游");
text = text.replace("long yao","隆尧");
text = text.replace("long yan","龙岩");
text = text.replace("long xi","陇西");
text = text.replace("long shan","龙山");
text = text.replace("long quan","龙泉");
text = text.replace("long nan","陇南");
text = text.replace("long ling","龙陵");
text = text.replace("long li","龙里");
text = text.replace("long jing","龙井");
text = text.replace("long jiang","龙江");
text = text.replace("long hui","隆回");
text = text.replace("long hua","隆化");
text = text.replace("long hai","龙海");
text = text.replace("long chuan","陇川");
text = text.replace("liu zhi","六枝");
text = text.replace("liu yang","浏阳");
text = text.replace("liu pan shui","六盘水");
text = text.replace("liu he","柳河");
text = text.replace("ling yuan","凌源");
text = text.replace("ling wu","灵武");
text = text.replace("ling tai","灵台");
text = text.replace("ling shou","灵寿");
text = text.replace("ling shi","灵石");
text = text.replace("ling qiu","灵丘");
text = text.replace("ling hai","凌海");
text = text.replace("ling chuan","陵川");
text = text.replace("lin zhou","林周");
text = text.replace("lin zhi","林芝");
text = text.replace("lin zhang","临漳");
text = text.replace("lin ze","临泽");
text = text.replace("lin you","麟游");
text = text.replace("lin yi","临猗");
text = text.replace("lin xiang","临湘");
text = text.replace("lin xia","临夏");
text = text.replace("lin xi","临西");
text = text.replace("lin wu","临武");
text = text.replace("lin tan","临潭");
text = text.replace("lin li","临澧");
text = text.replace("lin kou","林口");
text = text.replace("lin jiang","临江");
text = text.replace("lin hai","临海");
text = text.replace("lin fen","临汾");
text = text.replace("lin dian","林甸");
text = text.replace("lin dao","临洮");
text = text.replace("lin cheng","临城");
text = text.replace("lin cang","临沧");
text = text.replace("lin an","临安");
text = text.replace("liao zhong","辽中");
text = text.replace("liao yuan","辽源");
text = text.replace("liao yang","辽阳");
text = text.replace("liang he","梁河");
text = text.replace("liang dang","两当");
text = text.replace("liang cheng","凉城");
text = text.replace("lian yuan","涟源");
text = text.replace("lian shui","涟水");
text = text.replace("lian jiang","连江");
text = text.replace("li yang","溧阳");
text = text.replace("li tang","理塘");
text = text.replace("li shui","丽水");
text = text.replace("li shu","梨树");
text = text.replace("li quan","礼泉");
text = text.replace("li ping","黎平");
text = text.replace("li ling","醴陵");
text = text.replace("li jiang","丽江");
text = text.replace("li cheng","黎城");
text = text.replace("li bo","荔波");
text = text.replace("lei zhou","雷州");
text = text.replace("lei yang","耒阳");
text = text.replace("lei wu qi","类乌齐");
text = text.replace("lei shan","雷山");
text = text.replace("lei bo","雷波");
text = text.replace("le ting","乐亭");
text = text.replace("le qing","乐清");
text = text.replace("le du","乐都");
text = text.replace("le chang","乐昌");
text = text.replace("lang ka zi","浪卡子");
text = text.replace("lang fang","廊坊");
text = text.replace("lan zhou","兰州");
text = text.replace("lan xi","兰西");
text = text.replace("lan tian","蓝田");
text = text.replace("lan shan","蓝山");
text = text.replace("lai yuan","涞源");
text = text.replace("lai shui","涞水");
text = text.replace("la zi","拉孜");
text = text.replace("la sa","拉萨");
text = text.replace("kun shan","昆山");
text = text.replace("kun ming","昆明");
text = text.replace("kui tun","奎屯");
text = text.replace("kui qing","葵青");
text = text.replace("kuan dian","宽甸");
text = text.replace("kuan cheng","宽城");
text = text.replace("ku lun","库伦");
text = text.replace("ku er le","库尔勒");
text = text.replace("ku che","库车");
text = text.replace("ke shan","克山");
text = text.replace("ke ping","柯坪");
text = text.replace("ke lan","岢岚");
text = text.replace("ke dong","克东");
text = text.replace("kang ping","康平");
text = text.replace("kang ma","康马");
text = text.replace("kang le","康乐");
text = text.replace("kang ding","康定");
text = text.replace("kang bao","康保");
text = text.replace("kai yuan","开远");
text = text.replace("kai yang","开阳");
text = text.replace("kai ping","开平");
text = text.replace("kai lu","开鲁");
text = text.replace("kai li","凯里");
text = text.replace("kai hua","开化");
text = text.replace("ka shi","喀什");
text = text.replace("ju rong","句容");
text = text.replace("ju lu","巨鹿");
text = text.replace("jiu tai","九台");
text = text.replace("jiu quan","酒泉");
text = text.replace("jiu long","九龙");
text = text.replace("jing yuan","靖远");
text = text.replace("jing yu","靖宇");
text = text.replace("jing yang","泾阳");
text = text.replace("jing xing","井陉");
text = text.replace("jing tai","景泰");
text = text.replace("jing ning","静宁");
text = text.replace("jing le","静乐");
text = text.replace("jing jiang","靖江");
text = text.replace("jing hong","景洪");
text = text.replace("jing he","精河");
text = text.replace("jing hai","静海");
text = text.replace("jing chuan","泾川");
text = text.replace("jing an","静安");
text = text.replace("jin zhou","锦州");
text = text.replace("jin zhong","晋中");
text = text.replace("jin yun","缙云");
text = text.replace("jin yang","金阳");
text = text.replace("jin tan","金坛");
text = text.replace("jin ta","金塔");
text = text.replace("jin shan","金山");
text = text.replace("jin sha","金沙");
text = text.replace("jin ping","锦屏");
text = text.replace("jin ning","晋宁");
text = text.replace("jin nan","津南");
text = text.replace("jin men","金门");
text = text.replace("jin jiang","晋江");
text = text.replace("jin hua","金华");
text = text.replace("jin hu","金湖");
text = text.replace("jin chuan","金川");
text = text.replace("jin cheng","晋城");
text = text.replace("jin chang","金昌");
text = text.replace("jie xiu","介休");
text = text.replace("jie shou","界首");
text = text.replace("jiao zuo","焦作");
text = text.replace("jiao he","蛟河");
text = text.replace("jiang zi","江孜");
text = text.replace("jiang yuan","江源");
text = text.replace("jiang yong","江永");
text = text.replace("jiang yin","江阴");
text = text.replace("jiang yan","姜堰");
text = text.replace("jiang shan","江山");
text = text.replace("jiang men","江门");
text = text.replace("jiang le","将乐");
text = text.replace("jiang kou","江口");
text = text.replace("jiang du","江都");
text = text.replace("jiang da","江达");
text = text.replace("jiang chuan","江川");
text = text.replace("jian yang","建阳");
text = text.replace("jian shui","建水");
text = text.replace("jian ping","建平");
text = text.replace("jian ou","建瓯");
text = text.replace("jian ning","建宁");
text = text.replace("jian hu","建湖");
text = text.replace("jian he","剑河");
text = text.replace("jian de","建德");
text = text.replace("jian chuan","剑川");
text = text.replace("jian chang","建昌");
text = text.replace("jia yu guan","嘉峪关");
text = text.replace("jia yin","嘉荫");
text = text.replace("jia yi","嘉义");
text = text.replace("jia xing","嘉兴");
text = text.replace("jia shi","伽师");
text = text.replace("jia shan","嘉善");
text = text.replace("jia li","嘉黎");
text = text.replace("jia he","嘉禾");
text = text.replace("jia ding","嘉定");
text = text.replace("jia cha","加查");
text = text.replace("ji zhou","冀州");
text = text.replace("ji ze","鸡泽");
text = text.replace("ji xian","集贤");
text = text.replace("ji xi","鸡西");
text = text.replace("ji shou","吉首");
text = text.replace("ji shan","稷山");
text = text.replace("ji mu nai","吉木乃");
text = text.replace("ji mu","吉木");
text = text.replace("ji long","基隆");
text = text.replace("ji lin","吉林");
text = text.replace("ji dong","鸡东");
text = text.replace("ji an","集安");
text = text.replace("huo zhou","霍州");
text = text.replace("huo jia","获嘉");
text = text.replace("huo cheng","霍城");
text = text.replace("hun yuan","浑源");
text = text.replace("hui ze","会泽");
text = text.replace("hui tong","会同");
text = text.replace("hui shui","惠水");
text = text.replace("hui ning","会宁");
text = text.replace("hui nan","辉南");
text = text.replace("hui li","会理");
text = text.replace("hui dong","会东");
text = text.replace("hui chun","珲春");
text = text.replace("hui an","惠安");
text = text.replace("huang zhong","湟中");
text = text.replace("huang yuan","湟源");
text = text.replace("huang shi","黄石");
text = text.replace("huang shan","黄山");
text = text.replace("huang pu","黄浦");
text = text.replace("huang ping","黄平");
text = text.replace("huang hua","黄骅");
text = text.replace("huan ren","桓仁");
text = text.replace("huai ren","怀仁");
text = text.replace("huai lai","怀来");
text = text.replace("huai hua","怀化");
text = text.replace("huai bei","淮北");
text = text.replace("huai an","淮安");
text = text.replace("hua yuan","花垣");
text = text.replace("hua yin","华阴");
text = text.replace("hua ting","华亭");
text = text.replace("hua rong","华容");
text = text.replace("hua ping","华坪");
text = text.replace("hua ning","华宁");
text = text.replace("hua nan","桦南");
text = text.replace("hua lian","花莲");
text = text.replace("hua dian","桦甸");
text = text.replace("hua de","化德");
text = text.replace("hua chuan","桦川");
text = text.replace("hu zhou","湖州");
text = text.replace("hu tu bi","呼图壁");
text = text.replace("hu ma","呼玛");
text = text.replace("hu lin","虎林");
text = text.replace("hu kou","湖口");
text = text.replace("hu guan","壶关");
text = text.replace("hou ma","侯马");
text = text.replace("hong ze","洪泽");
text = text.replace("hong qiao","红桥");
text = text.replace("hong kou","虹口");
text = text.replace("hong jiang","洪江");
text = text.replace("hong he","红河");
text = text.replace("heng yang","衡阳");
text = text.replace("heng shui","衡水");
text = text.replace("heng shan","衡山");
text = text.replace("heng nan","衡南");
text = text.replace("heng dong","衡东");
text = text.replace("hei shan","黑山");
text = text.replace("hei he","黑河");
text = text.replace("he zuo","合作");
text = text.replace("he zheng","和政");
text = text.replace("he zhang","赫章");
text = text.replace("he yang","合阳");
text = text.replace("he xi","河西");
text = text.replace("he tian","和田");
text = text.replace("he shuo","和硕");
text = text.replace("he shun","和顺");
text = text.replace("he shui","合水");
text = text.replace("he shan","鹤山");
text = text.replace("he qu","河曲");
text = text.replace("he qing","鹤庆");
text = text.replace("he long","和龙");
text = text.replace("he lan","贺兰");
text = text.replace("he jing","和静");
text = text.replace("he jin","河津");
text = text.replace("he jian","河间");
text = text.replace("he gang","鹤岗");
text = text.replace("he fei","合肥");
text = text.replace("he dong","河东");
text = text.replace("he bu","和布");
text = text.replace("he bei","河北");
text = text.replace("hang zhou","杭州");
text = text.replace("hang jin","杭锦");
text = text.replace("han shou","汉寿");
text = text.replace("han gu","汉沽");
text = text.replace("han dan","邯郸");
text = text.replace("han cheng","韩城");
text = text.replace("hai yan","海晏");
text = text.replace("hai xing","海兴");
text = text.replace("hai ning","海宁");
text = text.replace("hai men","海门");
text = text.replace("hai lun","海伦");
text = text.replace("hai lin","海林");
text = text.replace("hai cheng","海城");
text = text.replace("hai an","海安");
text = text.replace("ha mi","哈密");
text = text.replace("ha ba","哈巴");
text = text.replace("gui yang","贵阳");
text = text.replace("gui xi","贵溪");
text = text.replace("gui dong","桂东");
text = text.replace("gui ding","贵定");
text = text.replace("guang zong","广宗");
text = text.replace("guang zhou","广州");
text = text.replace("guang ze","光泽");
text = text.replace("guang ping","广平");
text = text.replace("guang nan","广南");
text = text.replace("guang ling","广灵");
text = text.replace("guang he","广河");
text = text.replace("guan yun","灌云");
text = text.replace("guan tao","馆陶");
text = text.replace("guan tang","观塘");
text = text.replace("guan nan","灌南");
text = text.replace("gu zhang","古丈");
text = text.replace("gu yuan","固原");
text = text.replace("gu yang","固阳");
text = text.replace("gu lang","古浪");
text = text.replace("gu jiao","古交");
text = text.replace("gu cheng","故城");
text = text.replace("gu an","固安");
text = text.replace("gong liu","巩留");
text = text.replace("gong ga","贡嘎");
text = text.replace("gong bu","工布");
text = text.replace("gen he","根河");
text = text.replace("ge jiu","个旧");
text = text.replace("ge ji","革吉");
text = text.replace("gao you","高邮");
text = text.replace("gao yi","高邑");
text = text.replace("gao yang","高阳");
text = text.replace("gao xiong","高雄");
text = text.replace("gao tai","高台");
text = text.replace("gao ping","高平");
text = text.replace("gao ling","高陵");
text = text.replace("gao lan","皋兰");
text = text.replace("gao chun","高淳");
text = text.replace("gao cheng","藁城");
text = text.replace("gao bei dian","高碑店");
text = text.replace("gang cha","刚察");
text = text.replace("gang ba","岗巴");
text = text.replace("gan zi","甘孜");
text = text.replace("gan zhou","赣州");
text = text.replace("gan yu","赣榆");
text = text.replace("gan nan","甘南");
text = text.replace("gan luo","甘洛");
text = text.replace("gan gu","甘谷");
text = text.replace("gai zhou","盖州");
text = text.replace("gai ze","改则");
text = text.replace("ga er","噶尔");
text = text.replace("fu zhou","福州");
text = text.replace("fu yun","富蕴");
text = text.replace("fu yuan","抚远");
text = text.replace("fu yu","扶余");
text = text.replace("fu yang","阜阳");
text = text.replace("fu xin","阜新");
text = text.replace("fu song","抚松");
text = text.replace("fu shun","抚顺");
text = text.replace("fu shan","佛山");
text = text.replace("fu quan","福泉");
text = text.replace("fu qing","福清");
text = text.replace("fu ping","富平");
text = text.replace("fu ning","富宁");
text = text.replace("fu min","富民");
text = text.replace("fu kang","阜康");
text = text.replace("fu jin","富锦");
text = text.replace("fu hai","福海");
text = text.replace("fu gong","福贡");
text = text.replace("fu feng","扶风");
text = text.replace("fu ding","福鼎");
text = text.replace("fu cheng","阜城");
text = text.replace("fu an","福安");
text = text.replace("feng zhen","丰镇");
text = text.replace("feng yuan","丰原");
text = text.replace("feng xiang","凤翔");
text = text.replace("feng xian","奉贤");
text = text.replace("feng shan","凤山");
text = text.replace("feng qiu","封丘");
text = text.replace("feng qing","凤庆");
text = text.replace("feng ning","丰宁");
text = text.replace("feng huang","凤凰");
text = text.replace("feng hua","奉化");
text = text.replace("feng gang","凤冈");
text = text.replace("feng cheng","凤城");
text = text.replace("fen yi","分宜");
text = text.replace("fen xi","汾西");
text = text.replace("fei xiang","肥乡");
text = text.replace("fei xi","肥西");
text = text.replace("fei dong","肥东");
text = text.replace("fang zheng","方正");
text = text.replace("fan zhi","繁峙");
text = text.replace("fa ku","法库");
text = text.replace("er yuan","洱源");
text = text.replace("en ping","恩平");
text = text.replace("e min","额敏");
text = text.replace("duo lun","多伦");
text = text.replace("dun huang","敦煌");
text = text.replace("dun hua","敦化");
text = text.replace("du yun","都匀");
text = text.replace("du shan","独山");
text = text.replace("du chang","都昌");
text = text.replace("dou liu","斗六");
text = text.replace("dong yang","东阳");
text = text.replace("dong tou","洞头");
text = text.replace("dong tai","东台");
text = text.replace("dong ning","东宁");
text = text.replace("dong liao","东辽");
text = text.replace("dong li","东丽");
text = text.replace("dong kou","洞口");
text = text.replace("dong hai","东海");
text = text.replace("dong guang","东光");
text = text.replace("dong gang","东港");
text = text.replace("dong feng","东丰");
text = text.replace("dong an","东安");
text = text.replace("ding zhou","定州");
text = text.replace("ding xing","定兴");
text = text.replace("ding xiang","定襄");
text = text.replace("ding xi","定西");
text = text.replace("ding ri","定日");
text = text.replace("ding qing","丁青");
text = text.replace("ding jie","定结");
text = text.replace("die bu","迭部");
text = text.replace("diao bing shan","调兵山");
text = text.replace("deng ta","灯塔");
text = text.replace("deng kou","磴口");
text = text.replace("de rong","得荣");
text = text.replace("de qing","德清");
text = text.replace("de qin","德钦");
text = text.replace("de jiang","德江");
text = text.replace("de hui","德惠");
text = text.replace("de hua","德化");
text = text.replace("de ge","德格");
text = text.replace("de chang","德昌");
text = text.replace("de an","德安");
text = text.replace("dao zhen","道真");
text = text.replace("dao nan","洮南");
text = text.replace("dao fu","道孚");
text = text.replace("dao cheng","稻城");
text = text.replace("dang xiong","当雄");
text = text.replace("dang chang","宕昌");
text = text.replace("dan zhai","丹寨");
text = text.replace("dan yang","丹阳");
text = text.replace("dan dong","丹东");
text = text.replace("dan ba","丹巴");
text = text.replace("dai shan","岱山");
text = text.replace("da zi","达孜");
text = text.replace("da ye","大冶");
text = text.replace("da yao","大姚");
text = text.replace("da wa","大洼");
text = text.replace("da tong","大同");
text = text.replace("da tian","大田");
text = text.replace("da shi qiao","大石桥");
text = text.replace("da qing","大庆");
text = text.replace("da pu","大埔");
text = text.replace("da ning","大宁");
text = text.replace("da ming","大名");
text = text.replace("da lian","大连");
text = text.replace("da li","大理");
text = text.replace("da guan","大关");
text = text.replace("da gang","大港");
text = text.replace("da feng","大丰");
text = text.replace("da fang","大方");
text = text.replace("da cheng","大城");
text = text.replace("da chang","大厂");
text = text.replace("da an","大安");
text = text.replace("cuo qin","措勤");
text = text.replace("cuo na","错那");
text = text.replace("cuo mei","措美");
text = text.replace("cong jiang","从江");
text = text.replace("cong hua","从化");
text = text.replace("ci xi","慈溪");
text = text.replace("ci li","慈利");
text = text.replace("chun hua","淳化");
text = text.replace("chun an","淳安");
text = text.replace("chu zhou","滁州");
text = text.replace("chu xiong","楚雄");
text = text.replace("chong xin","崇信");
text = text.replace("chong ming","崇明");
text = text.replace("chong li","崇礼");
text = text.replace("chi shui","赤水");
text = text.replace("chi feng","赤峰");
text = text.replace("chi cheng","赤城");
text = text.replace("cheng zhou","嵊州");
text = text.replace("cheng si","嵊泗");
text = text.replace("cheng jiang","澄江");
text = text.replace("cheng gong","呈贡");
text = text.replace("cheng de","承德");
text = text.replace("cheng cheng","澄城");
text = text.replace("cheng bu miao zu","城步苗族");
text = text.replace("cheng an","成安");
text = text.replace("chen zhou","郴州");
text = text.replace("chen xi","辰溪");
text = text.replace("chao yang","朝阳");
text = text.replace("chao hu","巢湖");
text = text.replace("chang zi","长子");
text = text.replace("chang zhou","常州");
text = text.replace("chang zhi","长治");
text = text.replace("chang yuan","长垣");
text = text.replace("chang xing","长兴");
text = text.replace("chang wu","长武");
text = text.replace("chang tu","昌图");
text = text.replace("chang ting","长汀");
text = text.replace("chang tai","长泰");
text = text.replace("chang shun","长顺");
text = text.replace("chang shu","常熟");
text = text.replace("chang shan","常山");
text = text.replace("chang sha","长沙");
text = text.replace("chang ning","常宁");
text = text.replace("chang ling","长岭");
text = text.replace("chang li","昌黎");
text = text.replace("chang le","长乐");
text = text.replace("chang ji","昌吉");
text = text.replace("chang hai","长海");
text = text.replace("chang feng","长丰");
text = text.replace("chang du","昌都");
text = text.replace("chang de","常德");
text = text.replace("chang chun","长春");
text = text.replace("cha yu","察隅");
text = text.replace("cha ya","察雅");
text = text.replace("cha ling","茶陵");
text = text.replace("cha bu","察布");
text = text.replace("cen gong","岑巩");
text = text.replace("ce le","策勒");
text = text.replace("ce heng","册亨");
text = text.replace("cang zhou","沧州");
text = text.replace("cang nan","苍南");
text = text.replace("bu tuo","布拖");
text = text.replace("bu er jin","布尔津");
text = text.replace("bo ye","博野");
text = text.replace("bo tou","泊头");
text = text.replace("bo mi","波密");
text = text.replace("bo li","勃利");
text = text.replace("bo le","博乐");
text = text.replace("bo hu","博湖");
text = text.replace("bin hai","滨海");
text = text.replace("bin chuan","宾川");
text = text.replace("bian ba","边坝");
text = text.replace("bi ru","比如");
text = text.replace("bi jie","毕节");
text = text.replace("ben xi","本溪");
text = text.replace("bei piao","北票");
text = text.replace("bei ning","北宁");
text = text.replace("bei chen","北辰");
text = text.replace("bei an","北安");
text = text.replace("bao ying","宝应");
text = text.replace("bao tou","包头");
text = text.replace("bao shan","宝山");
text = text.replace("bao qing","宝清");
text = text.replace("bao jing","保靖");
text = text.replace("bao ji","宝鸡");
text = text.replace("bao ding","保定");
text = text.replace("bao di","宝坻");
text = text.replace("bao de","保德");
text = text.replace("ban qiao","板桥");
text = text.replace("ban ge","班戈");
text = text.replace("bai yu","白玉");
text = text.replace("bai yin","白银");
text = text.replace("bai xiang","柏乡");
text = text.replace("bai shui","白水");
text = text.replace("bai shan","白山");
text = text.replace("bai quan","拜泉");
text = text.replace("bai lang","白朗");
text = text.replace("bai cheng","白城");
text = text.replace("ba zhou","霸州");
text = text.replace("ba yan","巴彦");
text = text.replace("ba tang","巴塘");
text = text.replace("ba su","八宿");
text = text.replace("ba qing","巴青");
text = text.replace("ba chu","巴楚");
text = text.replace("ang ren","昂仁");
text = text.replace("an ze","安泽");
text = text.replace("an yuan","安远");
text = text.replace("an xin","安新");
text = text.replace("an xiang","安乡");
text = text.replace("an xi","安西");
text = text.replace("an tu","安图");
text = text.replace("an shun","安顺");
text = text.replace("an shan","鞍山");
text = text.replace("an ren","安仁");
text = text.replace("an qing","安庆");
text = text.replace("an ping","安平");
text = text.replace("an ning","安宁");
text = text.replace("an long","安龙");
text = text.replace("an ji","安吉");
text = text.replace("an hua","安化");
text = text.replace("an guo","安国");
text = text.replace("an duo","安多");
text = text.replace("an da","安达");
text = text.replace("a wa ti","阿瓦提");
text = text.replace("a tu shi","阿图什");
text = text.replace("a rong","阿荣");
text = text.replace("a la er","阿拉尔");
text = text.replace("a ke tao","阿克陶");
text = text.replace("a ke su","阿克苏");
text = text.replace("a he qi","阿合奇");
text = text.replace("a cheng","阿城");
text = text.replace("longcheng","龙城");
text = text.replace("wushuang","无双城");
text = text.replace(/Dahab/g,"都哈比");
text = text.replace(/Kabira/g,"卡比热");
text = text.replace(/Ras Sanan/g,"拉斯拉萨纳");
text = text.replace(/Tanwir/g,"坦维尔");
text = text.replace(/Azim Shab/g,"阿齐姆沙布");
text = text.replace(/Tarwa/g,"图拉瓦");
text = text.replace(/Hakim Al Ramal/g,"哈基姆·拉马尔");
text = text.replace(/Karrakan/g,"卡热卡");
text = text.replace(/Al-Hazred/g,"哈兹雷德");
text = text.replace(/Al-Hazif/g,"哈齐夫");
text = text.replace(/Kwadim/g,"夸迪姆");
text = text.replace(/Hikma/g,"希克曼");
text = text.replace(/El-Adele/g,"埃尔阿黛勒");
text = text.replace(/Al-Anwar/g,"安瓦尔");
return text;
};

var TranslateRelations = function (text)
{
text = text.replace("Grand City of","大都市");
text = text.replace("Free City of","自由城");
text = text.replace("Holy City of","圣城");
text = text.replace("City State of","城邦");
text = text.replace("City of","城邦");
text = text.replace("Realm of","王国");
text = text.replace("House","家族");
text = text.replace("Protectorate of","保护领地");
text = text.replace(/GongSunShi/g,"公孙氏");
text = text.replace(/LiuShi/g,"刘氏");
text = text.replace(/CaoShi/g,"曹氏");
text = text.replace(/SunShi/g,"孙氏");
text = text.replace(/YuanShi/g,"袁氏");
text = text.replace(/SiMaShi/g,"司马氏");
text = text.replace(/DongShi/g,"董氏");
text = text.replace(/MaShi/g,"马氏");
text = text.replace(/ZhangShi/g,"张氏");
text = text.replace(/KongShi/g,"孔氏");
text = text.replace(/Grimmund/g,"格里姆米德");
text = text.replace(/Weilburg/g,"维尔堡");
text = text.replace(/Armsberg/g,"阿姆斯伯格");
text = text.replace(/Gota/g,"高特");
text = text.replace(/Eisenstein/g,"艾森斯坦");
text = text.replace(/Grauwall/g,"格劳沃尔");
text = text.replace(/Rabenholt/g,"拉本霍尔特");
text = text.replace(/Sommerwein/g,"萨摩威宁");
text = text.replace(/Winterhall/g,"温特霍尔");
text = text.replace(/Ruhmolt/g,"若蒙特");
text = text.replace(/Adelreich/g,"阿德莱希");
text = text.replace(/Perowinger/g,"佩罗文杰");
text = text.replace(/Eiglof/g,"埃格洛夫");
text = text.replace(/Berengar/g,"贝伦加尔");
text = text.replace(/Gunbald/g,"冈博尔德");
text = text.replace(/Goswin/g,"戈斯温");
text = text.replace(/Adelheim/g,"阿德尔海姆");
text = text.replace(/Ammondt/g,"阿蒙特");
text = text.replace(/Bartholin/g,"巴托兰");
text = text.replace(/Eberlin/g,"埃伯林");
text = text.replace(/Folsach/g,"福尔萨克");
text = text.replace(/Hedin/g,"赫丁");
text = text.replace(/Horn/g,"赫若");
text = text.replace(/Niedergard/g,"尼德加德");
text = text.replace(/Rosenving/g,"罗森文");
text = text.replace(/Thurah/g,"图拉");
text = text.replace(/Kaltenborn/g,"卡尔滕伯恩");
text = text.replace(/Krieger/g,"克里格");
text = text.replace(/Steinwall/g,"斯泰因瓦尔");
text = text.replace(/Harkon/g,"哈肯");
text = text.replace(/Osten/g,"奥斯特");

text = text.replace("Hostile","敌对");
text = text.replace("Threatening","危险");
text = text.replace("Unfriendly","敌意");
text = text.replace("Cold","冷淡");
text = text.replace("Neutral","中立");
text = text.replace("Open","开放");
text = text.replace("Friendly","友好");
text = text.replace("Very Friendly","亲密");
text = text.replace("Allied","盟友");

text = text.replace(" von ","·");
//text = text.replace(" of ","·");
return text;
}
//text = text.replace(/家族\ (.*?)/, "$1 家族");
//text = text.replace(/大都市\ (.*?)/, "$1 大都市");
//text = text.replace(/自由城\ (.*?)/, "$1 自由城");
//text = text.replace(/圣城\ (.*?)/, "$1 圣城");
//text = text.replace(/城邦\ (.*?)/, "$1 城邦");
//text = text.replace(/城\ (.*?)/, "$1 城");
//text = text.replace(/王国\ (.*?)/, "$1 王国");

var twTranslateWorldRelationsScreen0 = TranslateWorldRelationsScreen0;
TranslateWorldRelationsScreen0 = function(text)
{
	text = TranslateRelations(text);
	text = TranslateLargeFishingVillage(text);
	text = twTranslateWorldRelationsScreen0.call(this,text);
	return text;
}

var twTranslateWorldRelationsScreen1 = TranslateWorldRelationsScreen1;
TranslateWorldRelationsScreen1 = function(text)
{
	text = twTranslateWorldRelationsScreen1.call(this,text);
	text = TranslateWorldRelationsScreen0(text);
	text = TranslateLargeFishingVillage(text);
	return text;
}

TranslateWorldTownScreenHarborDialogModule = function(text)
{
	text = text.replace("A harbor that allows you to book passage by ship to other parts of the continent", "一个港口，可以让你订船到大陆的其他地方");
	text = text.replace("A fast ship", "一艘快船");
	text = text.replace("A sturdy ship", "一艘坚固的船");
	text = text.replace("A cog", "一艘轮船");
	text = text.replace("A longship", "一艘长船");
	text = text.replace("A small ship", "一艘小船");
	text = text.replace("A trading ship", "一艘贸易船");
	text = text.replace("A knarr", "一艘客船");
	text = text.replace("A local fishing boat", "一艘当地的渔船");
	text = text.replace("A creaking old ship", "一艘吱吱作响的老船");
	text = text.replace("Summer Daze", "夏日眩晕");
	text = text.replace("Merry Mist", "欢乐薄雾");
	text = text.replace("Howl of the Sea", "大海嚎叫");
	text = text.replace("Coral Secret", "珊瑚秘密");
	text = text.replace("Sandy Bay", "桑迪湾");
	text = text.replace("Lady of the Sea", "海上淑女");
	text = text.replace("Solitaire", "寂寞");
	text = text.replace("Brunhild", "布伦希尔德");
	text = text.replace("Mathilda", "玛蒂尔达");
	text = text.replace("Comet", "彗星");
	text = text.replace("Tetrarch", "原型");
	text = text.replace("Lofjord", "洛峡湾");
	text = text.replace("Autumn Wind", "秋风");
	text = text.replace("Brakel", "巴卡");
	text = text.replace("Seven Stars", "七星");
	text = text.replace("Dark Omen", "黑暗启示");
	text = text.replace("Concord", "和谐");
	text = text.replace("Albatros", "信天翁");
	text = text.replace("Golden Horse", "金马");
	text = text.replace("Sea Nymph", "海仙女");
	text = text.replace("Twisted Fate", "扭曲命运");
	text = text.replace("King's Bounty", "国王恩赐");
	text = text.replace("Bald Monk", "修道士");
	text = text.replace("Golden Sun", "金色太阳");
	text = text.replace("Vanity", "自负");
	text = text.replace("Brazen", "无耻");
	text = text.replace("Tiger's Claw", "虎爪");
	text = text.replace("Sycamore", "梧桐");
	text = text.replace("Noble Runner", "高贵跑步者");
	text = text.replace("Bleak Moon", "阴冷月亮");
	text = text.replace("Clansman", "宗族");
	text = text.replace("Whale's Voyage", "鲸鱼之旅");
	text = text.replace("Quickmatch", "快速匹配");
	text = text.replace("Blackfly", "黑蝇");
	text = text.replace("Ejnar Erikson", "埃纳尔·埃里克森");
	text = text.replace("Lindwurm", "林德虫");
	text = text.replace("Supreme", "至高无上");
	text = text.replace("Griffon", "狮鹫");
	text = text.replace("Axford", "阿克斯福德");
	text = text.replace("Bertha", "伯莎");
	text = text.replace("Seagull", "海鸥");
	text = text.replace("Belzebub", "苍蝇怪");
	text = text.replace("Poundmaker", "庞德马克");
	text = text.replace(/by the name of \'(.*?)\'/, "($1号)");
	text = text.replace(/would take your company onboard and to (.*?)\./, "会带着你的人去$1。");
	text = text.replace(/happens to sail to (.*?) and would take your company onboard\./, "碰巧要航行去$1，顺便带上你的人。");
	text = text.replace(/is soon to depart and could be a way to safely and quickly make passage to (.*?)\./, "即将启程，可以安全快速地到达$1。");
	text = text.replace(/could provide a means to reach (.*?) a lot faster than going overland\./, "可以比陆路更快地到达$1。");
	text = text.replace(/could drop you off at (.*?) for a full purse of crowns\./, "可以让你在$1下船赚取满满一袋克朗。");
	text = text.replace("Harbor", "港口");
	text = text.replace("Sail to", "驶向");
	
	text = TranslateWorldRelationsScreen1(text);
	return text;
}

//下面一段汉化 城镇内名称
var wtWorldTownScreenMainDialogModule = WorldTownScreenMainDialogModule.prototype.loadFromData;
WorldTownScreenMainDialogModule.prototype.loadFromData = function (_data)
{
	wtWorldTownScreenMainDialogModule.call(this,_data);
	if("Title" in _data && _data["Title"] !== null)
    {
        this.mDialogContainer.findDialogTitle().html(TranslateLargeFishingVillage(_data["Title"]));
    }
}
//下面二段汉化 派系和关系
WorldRelationsScreen.prototype.updateDetailsPanel = function(_element)
{
    if(_element !== null && _element.length > 0)
    {
        var data = _element.data('entry');
        
        this.mDetailsPanel.BannerImage.attr('src', Path.GFX + data['ImagePath']);     
       
        // retarded JS calls load callback after a significant delay only - so we call this here manually to position/resize an image that is completely loaded already anyway
        this.mDetailsPanel.BannerImage.centerImageWithinParent(0, 0, 1.0); 
       
        this.mDetailsPanel.FactionName.html(TranslateWorldRelationsScreen0(data['Name']));
		this.mDetailsPanel.FactionMotto.html(TranslateWorldRelationsScreen1(data['Motto']));
/*        this.mDetailsPanel.FactionTypeImage.attr('src', Path.GFX + data['TypeImagePath']);*/
        this.mDetailsPanel.FactionDescriptionTextScrollContainer.html(TranslateWorldRelationsScreen1(data['Description']));

		this.mDetailsPanel.CharacterPanel.empty();
		for(var i=0; i < data['Characters'].length; ++i)
		{
			var character = $('<div class="character' + i + '"/>');
			//var characterImage = character.createImage(Path.PROCEDURAL + data['Characters'][i].ImagePath, null, null, '');

 			var characterImage = character.createImage(Path.PROCEDURAL + data['Characters'][i].ImagePath, function (_image)
 			{
 				_image.centerImageWithinParent(0, 0, 1.0);
 				//_image.removeClass('opacity-none');
 			}, null, ''/*'opacity-none'*/);

			characterImage.centerImageWithinParent(0, 0, 1.0);
			characterImage.bindTooltip({ contentType: 'ui-element', elementId: TooltipIdentifier.CharacterNameAndTitles, entityId: data['Characters'][i].ID });

			this.mDetailsPanel.CharacterPanel.append(character);
		}

        // bin tooltips
        //this.mDetailsPanel.FactionTypeImage.bindTooltip({ contentType: 'ui-element', elementId: TooltipIdentifier.CharacterBackgrounds.Generic, elementOwner: TooltipIdentifier.ElementOwner.HireScreen, entityId: data[WorldTownScreenIdentifier.HireRosterEntry.Id] });

        this.mDetailsPanel.Container.removeClass('display-none').addClass('display-block');
    }
    else
    {
        this.mDetailsPanel.Container.removeClass('display-block').addClass('display-none');
    }
};

WorldRelationsScreen.prototype.addListEntry = function (_data)
{
    var result = $('<div class="l-row"/>');
    this.mListScrollContainer.append(result);

    var entry = $('<div class="ui-control list-entry"/>');
    result.append(entry);
    entry.data('entry', _data);
    entry.click(this, function(_event)
	{
        var self = _event.data;
        self.selectListEntry($(this));
    });

    // left column
    var column = $('<div class="column is-left"/>');
    entry.append(column);

    var imageOffsetX = ('ImageOffsetX' in _data ? _data['ImageOffsetX'] : 0);
    var imageOffsetY = ('ImageOffsetY' in _data ? _data['ImageOffsetY'] : 0);
    column.createImage(Path.GFX + _data['ImagePath'], function (_image)
	{
        _image.centerImageWithinParent(imageOffsetX, imageOffsetY, 0.5);
        _image.removeClass('opacity-none');
    }, null, 'opacity-none');

    // right column
    column = $('<div class="column is-right"/>');
    entry.append(column);

    // top row
    var row = $('<div class="row is-top"/>');
    column.append(row);

    // bind tooltip
    //image.bindTooltip({ contentType: 'ui-element', elementId: TooltipIdentifier.CharacterBackgrounds.Generic, elementOwner: TooltipIdentifier.ElementOwner.HireScreen, entityId: _data[WorldTownScreenIdentifier.HireRosterEntry.Id] });

    var name = $('<div class="name title-font-normal font-bold font-color-brother-name">' + TranslateWorldRelationsScreen0(_data['Name']) + '</div>');
    row.append(name);

    // bottom row
    row = $('<div class="row is-bottom"/>');
    column.append(row);

    var assetsCenterContainer = $('<div class="l-assets-center-container"/>');
    row.append(assetsCenterContainer);

    // relation
    var assetsContainer = $('<div class="l-assets-container"/>');
    assetsCenterContainer.append(assetsContainer);

    var progressbarContainer = $('<div class="stats-progressbar-container ui-control-stats-progressbar-container-relations"></div>');
    assetsContainer.append(progressbarContainer);

    progressbarContainer.bindTooltip({ contentType: 'ui-element', elementId: TooltipIdentifier.RelationsScreen.Relations, entityId: _data.ID });

    var progressbar = $('<div class="stats-progressbar ui-control-stats-progressbar relations"></div>');
    var newWidth = (_data.RelationNum / 100.0) * 100;
    progressbar.css('width', newWidth + '%');
    progressbarContainer.append(progressbar);

    var progressbarLabel = $('<div class="stats-progressbar-label text-font-small font-color-progressbar-label">' + TranslateWorldRelationsScreen0(_data['Relation']) + '</div>');
    progressbarContainer.append(progressbarLabel);
};

//下面三段 汉化港口
WorldTownScreenTravelDialogModule.prototype.addListEntry = function (_data)
{
    var result = $('<div class="l-row"/>');
    this.mListScrollContainer.append(result);

    var entry = $('<div class="ui-control list-entry"/>');
    result.append(entry);
    entry.data('entry', _data);
    entry.click(this, function(_event)
	{
        var self = _event.data;
        self.selectListEntry($(this));
    });

    // left column
    var column = $('<div class="column is-left"/>');
    entry.append(column);

    var imageOffsetX = ('ImageOffsetX' in _data ? _data['ImageOffsetX'] : 0);
    var imageOffsetY = ('ImageOffsetY' in _data ? _data['ImageOffsetY'] : 0);
    column.createImage(Path.GFX + _data['ListImagePath'], function (_image)
	{
        _image.centerImageWithinParent(imageOffsetX, imageOffsetY, 0.64);
        _image.removeClass('opacity-none');
    }, null, 'opacity-none');

    // right column
    column = $('<div class="column is-right"/>');

    if(_data['FactionImagePath'] !== null)
    {
    	column.createImage(Path.GFX + _data['FactionImagePath'], function (_image)
    	{
    		_image.centerImageWithinParent(imageOffsetX, imageOffsetY, 0.64);
    		_image.removeClass('opacity-none');
    	}, null, 'opacity-none  is-banner');
    }
    entry.append(column);

    // top row
    var row = $('<div class="row is-top"/>');
    column.append(row);

//     var image = $('<img/>');
//     image.attr('src', Path.GFX + _data['BackgroundImagePath']);
//     row.append(image);

    // bind tooltip
   // image.bindTooltip({ contentType: 'ui-element', elementId: TooltipIdentifier.CharacterBackgrounds.Generic, elementOwner: TooltipIdentifier.ElementOwner.HireScreen, entityId: _data[WorldTownScreenIdentifier.travelToEntry.Id] });

    var name = $('<div class="name title-font-normal font-bold font-color-brother-name">' + TranslateWorldTownScreenHarborDialogModule(_data['ListName']) + '</div>');
    row.append(name);

    // bottom row
    row = $('<div class="row is-bottom"/>');
    column.append(row);

    var assetsCenterContainer = $('<div class="l-assets-center-container"/>');
    row.append(assetsCenterContainer);

    // initial money
    var assetsContainer = $('<div class="l-assets-container"/>');
    assetsCenterContainer.append(assetsContainer);
    var image = $('<img/>');
    image.attr('src', Path.GFX + Asset.ICON_ASSET_MONEY);
    assetsContainer.append(image);
    //image.bindTooltip({ contentType: 'ui-element', elementId: TooltipIdentifier.Assets.Fee });
    var text = $('<div class="label is-initial-cost text-font-normal font-color-subtitle">' + Helper.numberWithCommas(_data['Cost']) + '</div>');
    assetsContainer.append(text);
};


WorldTownScreenTravelDialogModule.prototype.updateDetailsPanel = function(_element)
{
    if(_element !== null && _element.length > 0)
    {
        var currentMoney = this.mAssets.getValues().Money;
        var data = _element.data('entry');
        var initialMoneyCost = (data !== null && 'Cost' in data ? data['Cost'] : 0);
        
        this.mDetailsPanel.DestinationImage.attr('src', Path.GFX + data['ImagePath']);     
       
        // retarded JS calls load callback after a significant delay only - so we call this here manually to position/resize an image that is completely loaded already anyway
        this.mDetailsPanel.DestinationImage.centerImageWithinParent(0, 0, 1.0); 
       
// 		var parsedDescriptionText = XBBCODE.process({
// 			text: data['BackgroundText'],
// 			removeMisalignedTags: false,
// 			addInLineBreaks: true
// 		});

        this.mDetailsPanel.DestinationName.html(TranslateWorldTownScreenHarborDialogModule(data['Name']));
        this.mDetailsPanel.DestinationBackgroundTextScrollContainer.html(TranslateWorldTownScreenHarborDialogModule(data['BackgroundText']));
        this.mDetailsPanel.MoneyCostText.html(Helper.numberWithCommas(data['Cost']));

        // special cases for not enough resources
        if((currentMoney - initialMoneyCost) < 0)
        {
            this.mDetailsPanel.MoneyCostText.removeClass('font-color-description').addClass('font-color-assets-negative-value');
            this.mDetailsPanel.TravelButton.enableButton(false);
        }
        else
        {
            this.mDetailsPanel.TravelButton.enableButton(true);
            this.mDetailsPanel.MoneyCostText.removeClass('font-color-assets-negative-value').addClass('font-color-description');
        }

        this.mDetailsPanel.Container.removeClass('display-none').addClass('display-block');
    }
    else
    {
        this.mDetailsPanel.Container.removeClass('display-block').addClass('display-none');
    }
};

WorldTownScreenTravelDialogModule.prototype.loadFromData = function (_data)
{
    if(_data === undefined || _data === null)
    {
        return;
    }

	if('Title' in _data && _data.Title !== null)
	{
		 this.mDialogContainer.findDialogTitle().html(TranslateWorldTownScreenHarborDialogModule(_data.Title));
	}

	if('SubTitle' in _data && _data.SubTitle !== null)
	{
		 this.mDialogContainer.findDialogSubTitle().html(TranslateWorldTownScreenHarborDialogModule(_data.SubTitle));
	}

	if('HeaderImage' in _data && _data.HeaderImage !== null)
	{
		 this.mDialogContainer.findDialogHeaderImage().attr('src', Path.GFX + _data.HeaderImage);
	}

	this.mRoster = _data.Roster;

    this.mListScrollContainer.empty();

    for(var i = 0; i < _data.Roster.length; ++i)
    {
		var entry = _data.Roster[i];
        this.addListEntry(entry);
    }

    this.selectListEntry(this.mListContainer.findListEntryByIndex(0), true);
};
