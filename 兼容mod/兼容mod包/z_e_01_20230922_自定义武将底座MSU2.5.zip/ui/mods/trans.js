var wtTranslateButton = TranslateButton;
TranslateButton = function (text)
{
	
	text = text.replace("Custom Socket By Bigmap", "定制角色底座");
	text = text.replace("bust_base_player", "玩家");
	text = text.replace("bust_base_militia", "民兵");
	text = text.replace("bust_base_military", "军队");
	text = text.replace("bust_base_bandits", "强盗");
	text = text.replace("bust_base_undead", "亡灵");
	text = text.replace("bust_base_orcs", "兽人");
	text = text.replace("bust_base_goblins", "哥布林");
	text = text.replace("bust_base_wildmen_01", "野人");
	text = text.replace("bust_base_beasts", "野兽");
	text = text.replace("bust_base_assassin", "刺客(限传奇)");
	text = text.replace("bust_base_beasthunters", "野兽杀手(限传奇)");
	text = text.replace("bust_base_crusader", "十字军(限传奇)");
	text = text.replace("bust_base_troupe", "剧团(限传奇)");
	text = text.replace("bust_miniboss_lone_wolf", "独狼");
	text = text.replace("bust_miniboss_gladiators", "角斗士");
	text = text.replace("bust_miniboss_indebted", "负债者");
	text = text.replace("bust_miniboss_greenskins", "绿皮");
	text = text.replace("bust_miniboss_crusader", "十字军(限传奇)");
	text = text.replace("bust_miniboss_assassin", "刺客(限传奇)");
	text = text.replace("bust_miniboss_trader", "商队(限传奇)");
	text = text.replace("bust_miniboss_undead", "亡灵(限传奇)");
	text = text.replace("bust_miniboss", "Boss");
	text = text.replace("bust_base_rand", "随机");
	text = wtTranslateButton.call(this,text);

	return text;
}