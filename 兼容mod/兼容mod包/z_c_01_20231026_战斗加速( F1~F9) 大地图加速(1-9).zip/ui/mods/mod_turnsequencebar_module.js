"use strict";
{
    var onConnection = TacticalScreenTurnSequenceBarModule.prototype.onConnection;
    TacticalScreenTurnSequenceBarModule.prototype.onConnection = function(_handle)
    {
        this.mFadeInDuration                   = 75;  // Default 150
        this.mFadeOutDuration                  = 125; // Default 250
        this.mFadeOutDurationIfHiddenToPlayer  = 30;  // Default 60
        this.mSlideInDuration                  = 50;  // Default 100
        this.mSlideOutDuration                 = 130; // Default 260
        this.mSlideOutDurationIfHiddenToPlayer = 30;  // Default 30
        
        this.mResizeFirstSlotTime         = 120; // Default 180
        this.mResizeFirstSlotImageTime    = 120; // Default 180
        this.mProgressbarMovementDuration = 400; // Default 600
        this.mStatsPanelFadeInTime        = 100; // Default 150
        this.mStatsPanelFadeOutTime       = 200; // Default 250

        onConnection.bind(this)(_handle);
    };
}