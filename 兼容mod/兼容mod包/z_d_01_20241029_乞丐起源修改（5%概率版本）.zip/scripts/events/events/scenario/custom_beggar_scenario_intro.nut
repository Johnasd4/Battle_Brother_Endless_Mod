//mod custom beggar origin. NgGH707's troll work

this.custom_beggar_scenario_intro <- this.inherit("scripts/events/event", {
	m = {
		Money = 2,
		MaxRoster = 27,
		HiringRate = 100,
		WageRate = 100,
		XpRate = 100,
		SellingRate = 100,
		BuyingRate = 100,
		BonusLoot = 0,
		BonusChampion = 0,
		BonusSpeed = 105,
		Player = null,
		AllowToHireNoble = false,
		UndeadType = 0,
		BackgroundType = 0,
		IsAddingFavourPerk = false,
		AttributesAfterVeteran = 0,
		IsRandomTalent = true,
		PlayerTalents = [0, 0, 0, 0, 0, 0, 0, 0],
		Dub = null,
		MaxPerValue = 10100,
	},
	function create()
	{
		this.m.ID = "event.custom_beggar_scenario_intro";
		this.m.IsSpecial = true;
		
//First page of settings
		this.m.Screens.push({
			ID = "General Settings Page 1",
			Text = "@@[img]gfx/ui/events/event_15.png[/img]{欢迎！ 你正在为‘乞丐起源’[color=#bcad8c]通用定制[/color]。 在本页面中，您可以自由调整以下任何选项。你甚至可以用乞丐技能生成随机背景。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "定制你的乞丐",
					function getResult( _event )
					{
						return "Player Character Selection";
					}
				},
				{
					Text = "允许雇佣高贵背景： [color=" + this.Const.UI.Color.NegativeValue + "]禁止[/color]",
					function getResult( _event )
					{
						if (_event.m.AllowToHireNoble)
						{
							_event.m.AllowToHireNoble = false;
						}
						else 
						{
						    _event.m.AllowToHireNoble = true;
						}

						return "General Settings Page 1";
					}
				},
				{
					Text = "经验获得系数",
					function getResult( _event )
					{
						return "Cheat XP";
					}
				},
				{
					Text = "开局资金",
					function getResult( _event )
					{
						return "Cheat Money";
					}
				},
				{
					Text = "下一页",
					function getResult( _event )
					{
						return "General Settings Page 2";
					}
				},
				{
					Text = "全部完成",
					function getResult( _event )
					{
						_event.onApplyingAllSetting();
						return "A";
					}
				}
			],
			function start( _event )
			{
				_event.m.Title = "通用设置, 第1/3页";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.Player != null)
				{
					this.Characters.push(_event.m.Player.getImagePath());
				}
				else if (_event.m.Dub != null) 
				{
				    this.Characters.push(_event.m.Dub.getImagePath());
				}
					
				local _text;
				local _icon; 
				switch (_event.m.BackgroundType) 
				{
			    case 1:
			        _icon = "ui/icons/unknown_traits.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        break;

			    case 2:
			        _icon = "ui/backgrounds/warlock_01.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        break;

			    case 3:
			        _icon = "ui/backgrounds/background_vampire.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        break;

			    case 4:
			        _icon = "ui/backgrounds/berserker_01.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        break;

			    case 5:
			        _icon = "ui/backgrounds/donkey.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color] 背景";
			        break;
			
			    default:
			        _icon = "ui/backgrounds/background_18.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]乞丐[/color] 背景";
				}

				this.List.push({
					id = 1,
					icon = _icon,
					text = _text
				});

				if (_event.m.AllowToHireNoble)
				{
					this.Options[1].Text = "允许雇佣高贵背景： [color=" + this.Const.UI.Color.PositiveValue + "]允许[/color]"
					this.List.push({
						id = 1,
						icon = "ui/icons/special.png",
						text = "可以雇佣 [color=" + this.Const.UI.Color.NegativeValue + "]高贵[/color] 背景"
					});
				}

				local positive = this.Const.UI.Color.PositiveValue;
				local negative = this.Const.UI.Color.NegativeValue;
				
				this.List.extend([
					{
						id = 4,
						icon = "ui/icons/asset_money.png",
						text = "开始资金: [color=" + (_event.m.Money > 1000 ? positive : negative) + "]" + _event.m.Money + "[/color] 克朗"
					},
					{
						id = 5,
						icon = "ui/icons/xp_received.png",
						text = "经验获得系数: [color=" + (_event.m.XpRate <= 100 ? positive : negative) + "]" + _event.m.XpRate + "%[/color]"
					},
					{
						id = 2,
						icon = "ui/icons/asset_brothers.png",
						text = "最大名册人数: [color=" + (_event.m.MaxRoster > 12 ? positive : negative) + "]" + _event.m.MaxRoster + "[/color]"
					},
					{
						id = 6,
						icon = "ui/icons/money2.png",
						text = "雇佣费用系数: [color=" + (_event.m.HiringRate <= 100 ? positive : negative) + "]" + _event.m.HiringRate + "%[/color]"
					},
					{
						id = 6,
						icon = "ui/icons/asset_daily_money.png",
						text = "日薪系数: [color=" + (_event.m.WageRate <= 100 ? positive : negative) + "]" + _event.m.WageRate + "%[/color]"
					},
					{
						id = 7,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "出售价格系数: [color=" + (_event.m.SellingRate >= 100 ? positive : negative) + "]" + _event.m.SellingRate + "%[/color]"
					},
					{
						id = 8,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "购买价格系数: [color=" + (_event.m.BuyingRate <= 100 ? positive : negative) + "]" + _event.m.BuyingRate + "%[/color]"
					},
					{
						id = 9,
						icon = "ui/icons/bag.png",
						text = "获得额外战利品的几率: [color=" + positive + "]" + _event.m.BonusLoot + "%[/color]"
					},
					{
						id = 10,
						icon = "ui/icons/miniboss.png",
						text = "额外生成冠军的几率: [color=" + positive + "]" + _event.m.BonusChampion + "%[/color]"
					},
					{
						id = 11,
						icon = "ui/icons/tracking_disabled.png",
						text = "世界地图移动速度: [color=" + (_event.m.BonusSpeed >= 105 ? positive : negative) + "]" + (_event.m.BonusSpeed - 5) + "%[/color]"
					}
				]);
			}
		});
		
//Second page of settings
		this.m.Screens.push({
			ID = "General Settings Page 2",
			Text = "@@[img]gfx/ui/events/event_15.png[/img]{欢迎！ 你正在为‘乞丐起源’[color=#bcad8c]通用定制[/color]。 在本页面中，您可以自由调整以下任何选项。你甚至可以用乞丐技能生成随机背景。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "最大名册人数",
					function getResult( _event )
					{
						return "Choose Roster Number";
					}
				},
				{
					Text = "获得额外战利品的几率",
					function getResult( _event )
					{
						return "Cheat Loot";
					}
				},
				{
					Text = "额外生成冠军的几率",
					function getResult( _event )
					{
						return "Cheat Champion";
					}
				},
				{
					Text = "世界地图移动速度",
					function getResult( _event )
					{
						return "Cheat Speed";
					}
				},
				{
					Text = "下一页",
					function getResult( _event )
					{
						return "General Settings Page 3";
					}
				},
				{
					Text = "上一页",
					function getResult( _event )
					{
						return "General Settings Page 1";
					}
				}
			],
			function start( _event )
			{
				_event.m.Title = "通用设置, 第2/3页";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.Player != null)
				{
					this.Characters.push(_event.m.Player.getImagePath());
				}
				else if (_event.m.Dub != null) 
				{
				    this.Characters.push(_event.m.Dub.getImagePath());
				}
					
				local _text;
				local _icon; 
				switch (_event.m.BackgroundType) 
				{
			    case 1:
			        _icon = "ui/icons/unknown_traits.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        break;

			    case 2:
			        _icon = "ui/backgrounds/warlock_01.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        break;

			    case 3:
			        _icon = "ui/backgrounds/background_vampire.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        break;

			    case 4:
			        _icon = "ui/backgrounds/berserker_01.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        break;

			    case 5:
			        _icon = "ui/backgrounds/donkey.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color] 背景";
			        break;
			
			    default:
			        _icon = "ui/backgrounds/background_18.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]奇怪[/color] 背景";
				}

				this.List.push({
					id = 1,
					icon = _icon,
					text = _text
				});

				if (_event.m.AllowToHireNoble)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/special.png",
						text = "可以雇佣 [color=" + this.Const.UI.Color.NegativeValue + "]高贵[/color] 背景"
					});
				}
				
				local positive = this.Const.UI.Color.PositiveValue;
				local negative = this.Const.UI.Color.NegativeValue;
				
				this.List.extend([
					{
						id = 4,
						icon = "ui/icons/asset_money.png",
						text = "开始资金: [color=" + (_event.m.Money > 1000 ? positive : negative) + "]" + _event.m.Money + "[/color] 克朗"
					},
					{
						id = 5,
						icon = "ui/icons/xp_received.png",
						text = "经验获得系数: [color=" + (_event.m.XpRate <= 100 ? positive : negative) + "]" + _event.m.XpRate + "%[/color]"
					},
					{
						id = 2,
						icon = "ui/icons/asset_brothers.png",
						text = "最大名册人数: [color=" + (_event.m.MaxRoster > 12 ? positive : negative) + "]" + _event.m.MaxRoster + "[/color]"
					},
					{
						id = 6,
						icon = "ui/icons/money2.png",
						text = "雇佣费用系数: [color=" + (_event.m.HiringRate <= 100 ? positive : negative) + "]" + _event.m.HiringRate + "%[/color]"
					},
					{
						id = 6,
						icon = "ui/icons/asset_daily_money.png",
						text = "日薪系数: [color=" + (_event.m.WageRate <= 100 ? positive : negative) + "]" + _event.m.WageRate + "%[/color]"
					},
					{
						id = 7,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "出售价格系数: [color=" + (_event.m.SellingRate >= 100 ? positive : negative) + "]" + _event.m.SellingRate + "%[/color]"
					},
					{
						id = 8,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "购买价格系数: [color=" + (_event.m.BuyingRate <= 100 ? positive : negative) + "]" + _event.m.BuyingRate + "%[/color]"
					},
					{
						id = 9,
						icon = "ui/icons/bag.png",
						text = "获得额外战利品的几率: [color=" + positive + "]" + _event.m.BonusLoot + "%[/color]"
					},
					{
						id = 10,
						icon = "ui/icons/miniboss.png",
						text = "额外生成冠军的几率: [color=" + positive + "]" + _event.m.BonusChampion + "%[/color]"
					},
					{
						id = 11,
						icon = "ui/icons/tracking_disabled.png",
						text = "世界地图移动速度: [color=" + (_event.m.BonusSpeed >= 105 ? positive : negative) + "]" + (_event.m.BonusSpeed - 5) + "%[/color]"
					}
				]);
			}
		});
		
//Third page of settings
		this.m.Screens.push({
			ID = "General Settings Page 3",
			Text = "@@[img]gfx/ui/events/event_15.png[/img]{欢迎！ 你正在为‘乞丐起源’[color=#bcad8c]通用定制[/color]。 在本页面中，您可以自由调整以下任何选项。你甚至可以用乞丐技能生成随机背景。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "雇佣费用系数",
					function getResult( _event )
					{
						return "Cheat Hiring Cost";
					}
				},
				{
					Text = "日薪系数"
					function getResult( _event )
					{
						return "Cheat Wage Cost";
					}
				},
				{
					Text = "出售价格系数",
					function getResult( _event )
					{
						return "Cheat Selling";
					}
				},
				{
					Text = "购买价格系数",
					function getResult( _event )
					{
						return "Cheat Buying";
					}
				},
				{
					Text = "上一页",
					function getResult( _event )
					{
						return "General Settings Page 2";
					}
				},
				{
					Text = "第一页",
					function getResult( _event )
					{
						return "General Settings Page 1";
					}
				}
			],
			function start( _event )
			{
				_event.m.Title = "通用设置, 第3/3页";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.Player != null)
				{
					this.Characters.push(_event.m.Player.getImagePath());
				}
				else if (_event.m.Dub != null) 
				{
				    this.Characters.push(_event.m.Dub.getImagePath());
				}
				
				local _text;
				local _icon; 
				switch (_event.m.BackgroundType) 
				{
			    case 1:
			        _icon = "ui/icons/unknown_traits.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        break;

			    case 2:
			        _icon = "ui/backgrounds/warlock_01.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        break;

			    case 3:
			        _icon = "ui/backgrounds/background_vampire.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        break;

			    case 4:
			        _icon = "ui/backgrounds/berserker_01.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        break;

			    case 5:
			        _icon = "ui/backgrounds/donkey.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color] 背景";
			        break;
			
			    default:
			        _icon = "ui/backgrounds/background_18.png";
			        _text = "正在使用 [color=" + this.Const.UI.Color.PositiveValue + "]乞丐[/color] 背景";
				}

				this.List.push({
					id = 1,
					icon = _icon,
					text = _text
				});

				if (_event.m.AllowToHireNoble)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/special.png",
						text = "可以雇佣 [color=" + this.Const.UI.Color.NegativeValue + "]高贵[/color] 背景"
					});
				}
				
				local positive = this.Const.UI.Color.PositiveValue;
				local negative = this.Const.UI.Color.NegativeValue;
				
				this.List.extend([
					{
						id = 4,
						icon = "ui/icons/asset_money.png",
						text = "开始资金: [color=" + (_event.m.Money > 1000 ? positive : negative) + "]" + _event.m.Money + "[/color] 克朗"
					},
					{
						id = 5,
						icon = "ui/icons/xp_received.png",
						text = "经验获得系数: [color=" + (_event.m.XpRate <= 100 ? positive : negative) + "]" + _event.m.XpRate + "%[/color]"
					},
					{
						id = 2,
						icon = "ui/icons/asset_brothers.png",
						text = "最大名册人数: [color=" + (_event.m.MaxRoster > 12 ? positive : negative) + "]" + _event.m.MaxRoster + "[/color]"
					},
					{
						id = 6,
						icon = "ui/icons/money2.png",
						text = "雇佣费用系数: [color=" + (_event.m.HiringRate <= 100 ? positive : negative) + "]" + _event.m.HiringRate + "%[/color]"
					},
					{
						id = 6,
						icon = "ui/icons/asset_daily_money.png",
						text = "日薪系数: [color=" + (_event.m.WageRate <= 100 ? positive : negative) + "]" + _event.m.WageRate + "%[/color]"
					},
					{
						id = 7,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "出售价格系数: [color=" + (_event.m.SellingRate >= 100 ? positive : negative) + "]" + _event.m.SellingRate + "%[/color]"
					},
					{
						id = 8,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "购买价格系数: [color=" + (_event.m.BuyingRate <= 100 ? positive : negative) + "]" + _event.m.BuyingRate + "%[/color]"
					},
					{
						id = 9,
						icon = "ui/icons/bag.png",
						text = "获得额外战利品的几率: [color=" + positive + "]" + _event.m.BonusLoot + "%[/color]"
					},
					{
						id = 10,
						icon = "ui/icons/miniboss.png",
						text = "额外生成冠军的几率: [color=" + positive + "]" + _event.m.BonusChampion + "%[/color]"
					},
					{
						id = 11,
						icon = "ui/icons/tracking_disabled.png",
						text = "世界地图移动速度: [color=" + (_event.m.BonusSpeed >= 105 ? positive : negative) + "]" + (_event.m.BonusSpeed - 5) + "%[/color]"
					}
				]);
			}
		});
		
//Option for Settings UI events
//Page 1
		//1-3 How much crowns you want to start with
		this.m.Screens.push({
			ID = "Cheat Money",
			Text = "@@[img]gfx/ui/events/event_04.png[/img]{此设置允许您自定义 [color=#bcad8c]开始资金[/color]。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10000 克朗",
					function getResult( _event )
					{
						_event.m.Money += 10000;
						
						return "Cheat Money";
					}
				},
				{
					Text = "-10000 克朗",
					function getResult( _event )
					{
						_event.m.Money = this.Math.max(0, _event.m.Money - 10000);
						
						return "Cheat Money";
					}
				},
				{
					Text = "+1000 克朗",
					function getResult( _event )
					{
						_event.m.Money += 1000;
						
						return "Cheat Money";
					}
				},
				{
					Text = "-1000 克朗",
					function getResult( _event )
					{
						_event.m.Money = this.Math.max(0, _event.m.Money - 1000);
						
						return "Cheat Money";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 1";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制开始资金";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.Money <= 1000)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_money.png",
						text = "以 [color=" + this.Const.UI.Color.NegativeValue + "]" + _event.m.Money + "[/color] 克朗资金开局"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_money.png",
						text = "以 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.Money + "[/color] 克朗资金开局"
					});
				}
			}
		});
		
		//1-4 Change XPMult stat
		this.m.Screens.push({
			ID = "Cheat XP",
			Text = "@@[img]gfx/ui/events/event_16.png[/img]{此设置允许您自定义 [color=#bcad8c]经验获得系数[/color]。这会影响到你名册上的所有队友。 }",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.XpRate = this.Math.min(_event.m.MaxPerValue, _event.m.XpRate + 10);
						
						return "Cheat XP";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.XpRate = this.Math.max(0, _event.m.XpRate - 10);
						
						return "Cheat XP";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.XpRate = this.Math.min(_event.m.MaxPerValue, _event.m.XpRate + 1);
						
						return "Cheat XP";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.XpRate = this.Math.max(0, _event.m.XpRate - 1);
						
						return "Cheat XP";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 1";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制经验获得系数";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.XpRate > 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/xp_received.png",
						text = "增加获得 [color=" + this.Const.UI.Color.PositiveValue + "]" + (_event.m.XpRate - 100) + "%[/color] 经验"
					});
				}
				else if (_event.m.XpRate == 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/xp_received.png",
						text = "[color=" + this.Const.UI.Color.NegativeValue + "]无法获得任何经验[/color]"
					});
				}
				else if (_event.m.XpRate == 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/xp_received.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]默认设置[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/xp_received.png",
						text = "减少获得 [color=" + this.Const.UI.Color.NegativeValue + "]" + (100 - _event.m.XpRate) + "%[/color] 经验"
					});
				}
			}
		});

	//Page 2
		//2-1 Choose your maximum roster
		this.m.Screens.push({
			ID = "Choose Roster Number",
			Text = "@@[img]gfx/ui/events/event_26.png[/img]{此设置允许您自定义 [color=#bcad8c]最大名册人数[/color].}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "设置为最大人数",
					function getResult( _event )
					{
						_event.m.MaxRoster = 27;
						
						return "Choose Roster Number";
					}
				},
				{
					Text = "也许再加一个。",
					function getResult( _event )
					{
						_event.m.MaxRoster = this.Math.min(27, _event.m.MaxRoster + 1);
						
						return "Choose Roster Number";
					}
				},
				{
					Text = "也许再减一个。",
					function getResult( _event )
					{
						_event.m.MaxRoster = this.Math.max(1, _event.m.MaxRoster - 1);
						
						return "Choose Roster Number";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 2";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制最大名册人数";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.MaxRoster >= 12)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_brothers.png",
						text = "最大名册人数 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.MaxRoster + "[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_brothers.png",
						text = "最大名册人数 [color=" + this.Const.UI.Color.NegativeValue + "]" + _event.m.MaxRoster + "[/color]"
					});
				}
			}
		});

		//2-2 give chance to gain bonus loot from beast type monster
		this.m.Screens.push({
			ID = "Cheat Loot",
			Text = "@@[img]gfx/ui/events/event_122.png[/img]{此设置允许您自定义 [color=#bcad8c]获得额外战利品的几率[/color].}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.BonusLoot = this.Math.min(100, _event.m.BonusLoot + 10);
						
						return "Cheat Loot";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.BonusLoot = this.Math.max(0, _event.m.BonusLoot - 10);
						
						return "Cheat Loot";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.BonusLoot = this.Math.min(100, _event.m.BonusLoot + 1);
						
						return "Cheat Loot";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.BonusLoot = this.Math.max(0, _event.m.BonusLoot - 1);
						
						return "Cheat Loot";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 2";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制获得额外战利品的几率";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.BonusLoot > 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/bag.png",
						text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.BonusLoot + "%[/color] 几率获得野兽战利品"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/bag.png",
						text = "有 [color=" + this.Const.UI.Color.NegativeValue + "]" + _event.m.BonusLoot + "%[/color] 几率获得野兽战利品"
					});
				}
			}
		});
		
		//2-3 give increase/decrease chance to encounter champion
		this.m.Screens.push({
			ID = "Cheat Champion",
			Text = "@@[img]gfx/ui/events/event_139.png[/img]{此设置允许您自定义 [color=#bcad8c]额外生成冠军的几率[/color]。冠军通常在1骷髅合同或早期游戏中有负几率，因此与合同中产生的冠军敌人相遇的几率明显低于自然产生的游荡/营地。但如果你将奖励几率提高到200%，所有人都可以成为冠军敌人，这将保证他们会成为冠军。\n\n注意：100%的人会让所有游荡/营地都有冠军。小心选择，否则你可能会面对一整群只有冠军的敌人。小心哥布林。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%"
					function getResult( _event )
					{
						_event.m.BonusChampion = this.Math.min(200, _event.m.BonusChampion + 10);
						
						return "Cheat Champion";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.BonusChampion = this.Math.max(0, _event.m.BonusChampion - 10);
						
						return "Cheat Champion";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.BonusChampion = this.Math.min(200, _event.m.BonusChampion + 1);
						
						return "Cheat Champion";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.BonusChampion = this.Math.max(0, _event.m.BonusChampion - 1);
						
						return "Cheat Champion";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 2";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制额外生成冠军的几率";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.BonusChampion == 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/miniboss.png",
						text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.BonusChampion + "%[/color] 额外几率生成冠军敌人"
					});
				}
				else if (_event.m.BonusChampion == 200)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/miniboss.png",
						text = "[color=" + this.Const.UI.Color.NegativeValue + "]保证在任何地方都能遇到冠军敌人[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/miniboss.png",
						text = "有 [color=" + this.Const.UI.Color.NegativeValue + "]" + _event.m.BonusChampion + "%[/color] 额外几率生成冠军敌人"
					});
				}
			}
		});
		
		//2-4 Change world map movement speed
		this.m.Screens.push({
			ID = "Cheat Speed",
			Text = "@@[img]gfx/ui/events/event_158.png[/img]{此设置允许您自定义 [color=#bcad8c]世界地图移动速度[/color]。由于性能问题，我不得不将这个数字限制在最多200%的加成速度，否则游戏会崩溃。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.BonusSpeed = this.Math.min(305, _event.m.BonusSpeed + 10);
						
						return "Cheat Speed";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.BonusSpeed = this.Math.max(15, _event.m.BonusSpeed - 10);
						
						return "Cheat Speed";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.BonusSpeed = this.Math.min(305, _event.m.BonusSpeed + 1)
						
						return "Cheat Speed";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.BonusSpeed = this.Math.max(15, _event.m.BonusSpeed - 1);
						
						return "Cheat Speed";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 2";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制世界地图移动速度";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.BonusSpeed > 105)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/tracking_disabled.png",
						text = "队伍移动速度加快 [color=" + this.Const.UI.Color.PositiveValue + "]" + (_event.m.BonusSpeed - 105) + "%[/color]"
					});
				}
				else if (_event.m.BonusSpeed == 105)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/tracking_disabled.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]默认设置[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/tracking_disabled.png",
						text = "队伍移动速度减慢 [color=" + this.Const.UI.Color.NegativeValue + "]" + (105 - _event.m.BonusSpeed) + "%[/color]"
					});
				}
			}
		});
		
//Page 3
		//3-1 HiringCostMult stat
		this.m.Screens.push({
			ID = "Cheat Hiring Cost",
			Text = "@@[img]gfx/ui/events/event_62.png[/img]{此设置允许您自定义 [color=#bcad8c]雇佣费用系数[/color]。它会影响雇用新人的总成本。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.HiringRate = this.Math.min(_event.m.MaxPerValue, _event.m.HiringRate + 10);
						
						return "Cheat Hiring Cost";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.HiringRate = this.Math.max(0, _event.m.HiringRate - 10);
						
						return "Cheat Hiring Cost";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.HiringRate = this.Math.min(_event.m.MaxPerValue, _event.m.HiringRate + 1);
						
						return "Cheat Hiring Cost";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.HiringRate = this.Math.max(0, _event.m.HiringRate - 1);
						
						return "Cheat Hiring Cost";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 3";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制雇佣费用系数";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.HiringRate > 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/money2.png",
						text = "雇佣费用增加 [color=" + this.Const.UI.Color.NegativeValue + "]" + (_event.m.HiringRate - 100) + "%[/color]"
					});
				}
				else if (_event.m.HiringRate == 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/money2.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]免费雇佣[/color]"
					});
				}
				else if (_event.m.HiringRate == 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/money2.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]默认设置[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/money2.png",
						text = "雇佣费用减少 [color=" + this.Const.UI.Color.PositiveValue + "]" + (100 - _event.m.HiringRate) + "%[/color]"
					});
				}
			}
		});

		//3-2 DailyWageMult stats
		this.m.Screens.push({
			ID = "Cheat Wage Cost",
			Text = "@@[img]gfx/ui/events/event_62.png[/img]{此设置允许您自定义 [color=#bcad8c]日薪系数[/color]。它可以增加或减少名册人员的工资。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.WageRate = this.Math.min(_event.m.MaxPerValue, _event.m.WageRate + 10);
						
						return "Cheat Wage Cost";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.WageRate = this.Math.max(0, _event.m.WageRate - 10);
						
						return "Cheat Wage Cost";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.WageRate = this.Math.min(_event.m.MaxPerValue, _event.m.WageRate + 1);
						
						return "Cheat Wage Cost";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.WageRate = this.Math.max(0, _event.m.WageRate - 1);
						
						return "Cheat Wage Cost";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 3";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制日薪系数";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.WageRate > 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_daily_money.png",
						text = "支付工资增加 [color=" + this.Const.UI.Color.NegativeValue + "]" + (_event.m.WageRate - 100) + "%[/color]"
					});
				}
				else if (_event.m.WageRate == 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_daily_money.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]无需支付工资[/color]"
					});
				}
				else if (_event.m.WageRate == 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_daily_money.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]默认设置[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_daily_money.png",
						text = "支付工资减少 [color=" + this.Const.UI.Color.PositiveValue + "]" + (100 - _event.m.WageRate) + "%[/color]"
					});
				}
			}
		});
		
		//3-3 Change to SellPriceMult stat
		this.m.Screens.push({
			ID = "Cheat Selling",
			Text = "@@[img]gfx/ui/events/event_63.png[/img]{此设置允许您自定义 [color=#bcad8c]出售价格系数[/color].}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.SellingRate = this.Math.min(_event.m.MaxPerValue, _event.m.SellingRate + 10);
						
						return "Cheat Selling";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.SellingRate = this.Math.max(0, _event.m.SellingRate - 10);
						
						return "Cheat Selling";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.SellingRate = this.Math.min(_event.m.MaxPerValue, _event.m.SellingRate + 1);
						
						return "Cheat Selling";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.SellingRate = this.Math.max(0, _event.m.SellingRate - 1);
						
						return "Cheat Selling";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 3";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "Customize Selling Price Multiplier";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.SellingRate > 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "出售物品价格增加 [color=" + this.Const.UI.Color.PositiveValue + "]" + (_event.m.SellingRate - 100) + "%[/color]"
					});
				}
				else if (_event.m.SellingRate == 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "[color=" + this.Const.UI.Color.NegativeValue + "]免费出售商品[/color]"
					});
				}
				else if (_event.m.SellingRate == 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]默认设置[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "出售物品价格减少 [color=" + this.Const.UI.Color.NegativeValue + "]" + (100 - _event.m.SellingRate) + "%[/color]"
					});
				}
			}
		});
		
		//3-4 Change BuyPriceMult stat
		this.m.Screens.push({
			ID = "Cheat Buying",
			Text = "@@[img]gfx/ui/events/event_63.png[/img]{此设置允许您自定义 [color=#bcad8c]购买价格系数[/color].}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "+10%",
					function getResult( _event )
					{
						_event.m.BuyingRate = this.Math.min(_event.m.MaxPerValue, _event.m.BuyingRate + 10);
						
						return "Cheat Buying";
					}
				},
				{
					Text = "-10%",
					function getResult( _event )
					{
						_event.m.BuyingRate = this.Math.max(0, _event.m.BuyingRate - 10);
						
						return "Cheat Buying";
					}
				},
				{
					Text = "+1%",
					function getResult( _event )
					{
						_event.m.BuyingRate = this.Math.min(_event.m.MaxPerValue, _event.m.BuyingRate + 1);
						
						return "Cheat Buying";
					}
				},
				{
					Text = "-1%",
					function getResult( _event )
					{
						_event.m.BuyingRate = this.Math.max(0, _event.m.BuyingRate - 1);
						
						return "Cheat Buying";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "General Settings Page 3";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "定制购买价格系数";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
				
				if (_event.m.BuyingRate > 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "购买物品价格增加 [color=" + this.Const.UI.Color.NegativeValue + "]" + (_event.m.BuyingRate - 100) + "%[/color]"
					});
				}
				else if (_event.m.BuyingRate == 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]商店物品免费拿[/color]"
					});
				}
				else if (_event.m.BuyingRate == 100)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "[color=" + this.Const.UI.Color.PositiveValue + "]默认设置[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/asset_moral_reputation.png",
						text = "购买物品价格减少 [color=" + this.Const.UI.Color.PositiveValue + "]" + (100 - _event.m.BuyingRate) + "%[/color]"
					});
				}
			}
		});
		
//Add Player Character Brothers
		//Main Screen
		this.m.Screens.push({
			ID = "Player Character Selection",
			Text = "@@[img]gfx/ui/events/event_70.png[/img]{又见面啦！这是 [color=#bcad8c]乞丐生成页面[/color]。 可以创建并重掷你想要的乞丐。无论他/她是否是乞丐都在这里生成所有角色，都将有‘盗取属性’和‘盗取特技’的能力。\n\n注意：你不能把驴子或吸血鬼变成僵尸或骷髅。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "定制乞丐生成";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";

				local t = "创建你的乞丐";
				
				if (_event.m.Player != null)
				{
					t = "再次重掷";
				}
				
				this.Options.push({
					Text = t,
					function getResult( _event )
					{
						local roster = this.World.getTemporaryRoster();
						roster.clear();

						local stash = this.World.Assets.getStash();
						stash.removeByID("accessory.berserker_mushrooms");
						stash.removeByID("accessory.berserker_mushrooms");
						stash.removeByID("supplies.roots_and_berries");

						_event.m.Player = roster.create("scripts/entity/tactical/player");
						_event.m.Player.setStartValuesEx(_event.getBackground(_event.m.BackgroundType));
						_event.createPlayerCharacter();
						return "Player Character Selection";
					}
				});

				local t;
				local _text;
				local _icon;
				local _t_1;
				local _text_1;
				local _icon_1;
				switch (_event.m.BackgroundType) 
				{
			    case 1:
			        t = "Switch to only [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        _icon = "ui/icons/unknown_traits.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        break;

			    case 2:
			        t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        _icon = "ui/backgrounds/warlock_01.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        break;

			    case 3:
			        t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        _icon = "ui/backgrounds/background_vampire.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        break;

			    case 4:
			    	t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color]";
			        _icon = "ui/backgrounds/berserker_01.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        break;

			    case 5:
			    	t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]乞丐[/color] 背景";
			        _icon = "ui/backgrounds/donkey.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color]";
			        break;
			
			    default:
			        t = "切换到 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        _icon = "ui/backgrounds/background_18.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]乞丐[/color] 背景";
				}

				switch (_event.m.UndeadType)
				{
			    case 1:
			        _t_1 = "转变为: [color=" + this.Const.UI.Color.PositiveValue + "]僵尸[/color]";
			        _icon_1 = "ui/perks/favoured_zombie_01.png";
			        _text_1 = "转变乞丐为 [color=" + this.Const.UI.Color.PositiveValue + "]僵尸[/color]";
			        break;

			    case 2:
			        _t_1 = "转变为: [color=" + this.Const.UI.Color.PositiveValue + "]骷髅[/color]";
			        _icon_1 = "ui/perks/favoured_skeleton_01.png";
			        _text_1 = "转变乞丐为 [color=" + this.Const.UI.Color.PositiveValue + "]骷髅[/color]";
			        break;

			    default:
			        _t_1 = "转变为亡灵: [color=" + this.Const.UI.Color.NegativeValue + "]否[/color]";
				}

				this.Options.extend([
					{
					    Text = t,
						function getResult( _event )
						{
							_event.m.BackgroundType += 1;

							if (_event.m.BackgroundType >= _event.getBackgroundTypeCount())
							{
								_event.m.BackgroundType = 0;
							}

							return "Player Character Selection";
						}
					},
					{
						Text = "定制天赋",
						function getResult( _event )
						{
							return "Customize Talents Page 1";
						}
					},
					{
						Text = "更多选项",
						function getResult( _event )
						{
							return "Player Character Selection More";
						}
					},
					{
						Text = "返回",
						function getResult( _event )
						{
							return "General Settings Page 1";
						}
					},
				]);
				
				if (_event.m.Player != null)
				{
//					local _text = _event.m.Player.getBackground().isFemaleBackground() ? "她很完美" : "他很完美";
					local _text = _event.m.Player.getBackground().isBackgroundType(this.Const.BackgroundType.Female) ? "她很完美" : "他很完美";
					this.Options.push({
						Text = _text,
						function getResult( _event )
						{
							return "General Settings Page 1";
						}
					});
					
					this.Characters.push(_event.m.Player.getImagePath());
					this.List.extend(this.Const.Beggar.getTooltipsFromBeggar(_event.m.Player));
				}
				else
				{	
					this.List.push({
						id = 1,
						icon = _icon,
						text = _text
					});

					if (_event.m.UndeadType != 0)
					{
						this.List.push({
							id = 1,
							icon = _icon_1,
							text = _text_1
						});
					}

					if (_event.m.IsAddingFavourPerk)
					{
						this.List.push({
							id = 1,
							icon = "ui/icons/perks.png",
							text = "角色将永远拥有所有偏爱敌人的特技"
						});
					}

					if (_event.m.AttributesAfterVeteran > 0)
					{
						this.List.push({
							id = 1,
							icon = "ui/icons/leveled_up.png",
							text = "在退伍等级(11级)后，还有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.AttributesAfterVeteran + "[/color] 级可正常获得属性点"
						});
					}

					if (!_event.m.IsRandomTalent)
					{
						for ( local i = 0; i < _event.m.PlayerTalents.len(); i = ++i )	
						{
							if (_event.m.PlayerTalents[i] != 0)
							{
								this.List.push({
									id = i + 3,
									icon = this.Const.Beggar.AttributesIcon[i],
									text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.PlayerTalents[i] + "[/color] 星级天赋"
								});
							}
						}
					}
					else
					{
						this.List.push({
							id = 3,
							icon = "ui/icons/perks.png",
							text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 天赋"
						});
					}
				}
			}
		});

		this.m.Screens.push({
			ID = "Player Character Selection More",
			Text = "@@[img]gfx/ui/events/event_70.png[/img]{又见面啦！这是 [color=#bcad8c]乞丐生成页面[/color]。 可以创建并重掷你想要的乞丐。无论他/她是否是乞丐都在这里生成所有角色，都将有‘盗取属性’和‘盗取特技’的能力。\n\n注意：你不能把驴子或吸血鬼变成僵尸或骷髅。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "定制乞丐生成";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";

				local t = "创建你的乞丐";
				
				if (_event.m.Player != null)
				{
					t = "再次重掷";
				}
				
				this.Options.push({
					Text = t,
					function getResult( _event )
					{
						local roster = this.World.getTemporaryRoster();
						roster.clear();

						local stash = this.World.Assets.getStash();
						stash.removeByID("accessory.berserker_mushrooms");
						stash.removeByID("accessory.berserker_mushrooms");
						stash.removeByID("supplies.roots_and_berries");

						_event.m.Player = roster.create("scripts/entity/tactical/player");
						_event.m.Player.setStartValuesEx(_event.getBackground(_event.m.BackgroundType));
						_event.createPlayerCharacter();
						return "Player Character Selection More";
					}
				});

				local t;
				local _text;
				local _icon;
				local _t_1;
				local _text_1;
				local _icon_1;
				switch (_event.m.BackgroundType)
				{
			    case 1:
			        t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        _icon = "ui/icons/unknown_traits.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        break;

			    case 2:
			        t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        _icon = "ui/backgrounds/warlock_01.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]术士[/color] 背景";
			        break;

			    case 3:
			        t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        _icon = "ui/backgrounds/background_vampire.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]吸血鬼[/color] 背景";
			        break;

			    case 4:
			    	t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color]";
			        _icon = "ui/backgrounds/berserker_01.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]狂战士[/color] 背景";
			        break;

			    case 5:
			    	t = "切换到仅限 [color=" + this.Const.UI.Color.PositiveValue + "]乞丐[/color] 背景";
			        _icon = "ui/backgrounds/donkey.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]驴子[/color]";
			        break;
			
			    default:
			        t = "切换到 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 背景";
			        _icon = "ui/backgrounds/background_18.png";
			        _text = "你选择了 [color=" + this.Const.UI.Color.PositiveValue + "]乞丐[/color] 背景";
				}

				switch (_event.m.UndeadType)
				{
			    case 1:
			        _t_1 = "转变为: [color=" + this.Const.UI.Color.PositiveValue + "]僵尸[/color]";
			        _icon_1 = "ui/perks/favoured_zombie_01.png";
			        _text_1 = "转变乞丐为 [color=" + this.Const.UI.Color.PositiveValue + "]僵尸[/color]";
			        break;

			    case 2:
			        _t_1 = "转变为: [color=" + this.Const.UI.Color.PositiveValue + "]骷髅[/color]";
			        _icon_1 = "ui/perks/favoured_skeleton_01.png";
			        _text_1 = "转变乞丐为 [color=" + this.Const.UI.Color.PositiveValue + "]骷髅[/color]";
			        break;

			    default:
			        _t_1 = "转变为亡灵: [color=" + this.Const.UI.Color.NegativeValue + "]否[/color]";
				}

				local t_f = _event.m.IsAddingFavourPerk ? "[color=" + this.Const.UI.Color.PositiveValue + "]是[/color]" : "[color=" + this.Const.UI.Color.NegativeValue + "]否[/color]";
				
				this.Options.extend([
					{
					    Text = _t_1,
						function getResult( _event )
						{
							_event.m.UndeadType += 1;

							if (_event.m.UndeadType >= 3)
							{
								_event.m.UndeadType = 0;
							}

							return "Player Character Selection More";
						}
					},
					{
						Text = "添加所有偏爱敌人特技： " + t_f,
						function getResult( _event )
						{
							_event.m.IsAddingFavourPerk = !_event.m.IsAddingFavourPerk;

							return "Player Character Selection More";
						}
					},
					{
						Text = "退伍级别(11级)后多少级可以获得正常属性",
						function getResult( _event )
						{
							return "Cheat Veteran Stats";
						}
					},
					{
						Text = "返回",
						function getResult( _event )
						{
							return "Player Character Selection";
						}
					},
				]);
				
				if (_event.m.Player != null)
				{
//					local _text = _event.m.Player.getBackground().isFemaleBackground() ? "她很完美" : "他很完美";
					local _text = _event.m.Player.getBackground().isBackgroundType(this.Const.BackgroundType.Female) ? "她很完美" : "他很完美";
					this.Options.push({
						Text = _text,
						function getResult( _event )
						{
							return "General Settings Page 1";
						}
					});
					
					this.Characters.push(_event.m.Player.getImagePath());
					this.List.extend(this.Const.Beggar.getTooltipsFromBeggar(_event.m.Player));
				}
				else
				{	
					this.List.push({
						id = 1,
						icon = _icon,
						text = _text
					});

					if (_event.m.UndeadType != 0)
					{
						this.List.push({
							id = 1,
							icon = _icon_1,
							text = _text_1
						});
					}

					if (_event.m.IsAddingFavourPerk)
					{
						this.List.push({
							id = 1,
							icon = "ui/icons/perks.png",
							text = "角色将始终拥有所有偏爱敌人特技"
						});
					}

					if (_event.m.AttributesAfterVeteran > 0)
					{
						this.List.push({
							id = 1,
							icon = "ui/icons/leveled_up.png",
							text = "在退伍等级(11级)后，还有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.AttributesAfterVeteran + "[/color] 级可正常获得属性点。"
						});
					}

					if (!_event.m.IsRandomTalent)
					{
						for ( local i = 0; i < _event.m.PlayerTalents.len(); i = ++i )	
						{
							if (_event.m.PlayerTalents[i] != 0)
							{
								this.List.push({
									id = i + 3,
									icon = this.Const.Beggar.AttributesIcon[i],
									text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.PlayerTalents[i] + "[/color] 星级天赋"
								});
							}
						}
					}
					else
					{
						this.List.push({
							id = 3,
							icon = "ui/icons/perks.png",
							text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]随机[/color] 星级天赋"
						});
					}
				}
			}
		});

		this.m.Screens.push({
			ID = "Cheat Veteran Stats",
			Text = "@@[img]gfx/ui/events/event_136.png[/img]{此设置允许您自定义 [color=#bcad8c]退伍等级(正常11级)[/color]。 通常情况下，人物在11级升级后只能获得 [color=#bcad8c]+1[/color] 点，无论你的天赋或属性如何，有了这些设置，你可以决定退伍等级(11级以上)之后有多少等级仍然可以获得正常的升级属性点，而不是强制 [color=#bcad8c]+1[/color] 点。非常诱人的选择，对吧？}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "重设",
					function getResult( _event )
					{
						_event.m.AttributesAfterVeteran = 0;
						
						return "Cheat Veteran Stats";
					}
				},
				{
					Text = "+10 等级",
					function getResult( _event )
					{
						_event.m.AttributesAfterVeteran += 10;
						
						return "Cheat Veteran Stats";
					}
				},
				{
					Text = "-10 等级",
					function getResult( _event )
					{
						_event.m.AttributesAfterVeteran = this.Math.max(0, _event.m.AttributesAfterVeteran - 10);
						
						return "Cheat Veteran Stats";
					}
				},
				{
					Text = "+1 等级",
					function getResult( _event )
					{
						_event.m.AttributesAfterVeteran += 1;
						
						return "Cheat Veteran Stats";
					}
				},
				{
					Text = "-1 等级",
					function getResult( _event )
					{
						_event.m.AttributesAfterVeteran = this.Math.max(0, _event.m.AttributesAfterVeteran - 1);
						
						return "Cheat Veteran Stats";
					}
				},
				{
					Text = "返回",
					function getResult( _event )
					{
						return "Player Character Selection More";
					}
				},
			],
			function start( _event )
			{
				_event.m.Title = "退伍等级后正常属性";
				
				if (_event.m.AttributesAfterVeteran <= 0)
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/leveled_up.png",
						text = "退伍等级后正常属性: [color=" + this.Const.UI.Color.NegativeValue + "]禁止[/color]"
					});
				}
				else
				{
					this.List.push({
						id = 1,
						icon = "ui/icons/leveled_up.png",
						text = "在退伍等级(11级)后，还有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.AttributesAfterVeteran + "[/color] 级可正常获得属性点。"
					});
				}
			}
		});
		
		//Customize Talents
		this.m.Screens.push({
			ID = "Customize Talents Page 1",
			Text = "@@[img]gfx/ui/events/event_15.png[/img]{这个设置允许决定[color=#bcad8c]乞丐[/color]在创建或重掷后将拥有哪些天赋。你可以根据需要添加多少天赋，一个有天赋的角色有各种各样的天赋。毕竟这是你的选择。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "随机(标准)",
					function getResult( _event )
					{
						_event.m.IsRandomTalent = true;
						
						return "Player Character Selection";
					}
				}
			],
			function start( _event )
			{
				_event.m.IsRandomTalent = false;
				_event.m.Title = "定制你角色的天赋, 第1/2页";
				
				for ( local i = 0; i < _event.m.PlayerTalents.len(); i = ++i )
				{
					if (_event.m.PlayerTalents[i] != 0)
					{
						this.List.push({
							id = i + 3,
							icon = this.Const.Beggar.AttributesIcon[i],
							text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.PlayerTalents[i] + "[/color] 星级天赋"
						});
					}
				}
				
				this.Options.extend([
					{
						Text = "生命值 " + (_event.m.PlayerTalents[0] != 0 ? "(" + _event.m.PlayerTalents[0] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[0] = _event.m.PlayerTalents[0] + 1 == 4 ? 0 : _event.m.PlayerTalents[0] + 1;
							
							return "Customize Talents Page 1";
						}
					},
					{
						Text = "决心值 " + (_event.m.PlayerTalents[1] != 0 ? "(" + _event.m.PlayerTalents[1] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[1] = _event.m.PlayerTalents[1] + 1 == 4 ? 0 : _event.m.PlayerTalents[1] + 1;
							return "Customize Talents Page 1";
						}
					},
					{
						Text = "疲劳值 " + (_event.m.PlayerTalents[2] != 0 ? "(" + _event.m.PlayerTalents[2] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[2] = _event.m.PlayerTalents[2] + 1 == 4 ? 0 : _event.m.PlayerTalents[2] + 1;
							return "Customize Talents Page 1";
						}
					},
					{
						Text = "主动值 " + (_event.m.PlayerTalents[3] != 0 ? "(" + _event.m.PlayerTalents[3] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[3] = _event.m.PlayerTalents[3] + 1 == 4 ? 0 : _event.m.PlayerTalents[3] + 1;
							return "Customize Talents Page 1";
						}
					},
					{
						Text = "下一页",
						function getResult( _event )
						{
							return "Customize Talents Page 2";
						}
					}
				]);
			}
		});
		
		this.m.Screens.push({
			ID = "Customize Talents Page 2",
			Text = "@@[img]gfx/ui/events/event_15.png[/img]{这个设置允许决定[color=#bcad8c]乞丐[/color]在创建或重掷后将拥有哪些天赋。你可以根据需要添加多少天赋，一个有天赋的角色有各种各样的天赋。毕竟这是你的选择。}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "定制你角色的天赋, 第2/2页";
				
				for ( local i = 0; i < _event.m.PlayerTalents.len(); i = ++i )	
				{
					if (_event.m.PlayerTalents[i] != 0)
					{
						this.List.push({
							id = i + 3,
							icon = this.Const.Beggar.AttributesIcon[i],
							text = "有 [color=" + this.Const.UI.Color.PositiveValue + "]" + _event.m.PlayerTalents[i] + "[/color] 星级天赋"
						});
					}
				}
				
				this.Options.extend([
					{
						Text = "近战技能 " + (_event.m.PlayerTalents[4] != 0 ? "(" + _event.m.PlayerTalents[4] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[4] = _event.m.PlayerTalents[4] + 1 == 4 ? 0 : _event.m.PlayerTalents[4] + 1;
							return "Customize Talents Page 2";
						}
					},
					{
						Text = "远程技能 " + (_event.m.PlayerTalents[5] != 0 ? "(" + _event.m.PlayerTalents[5] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[5] = _event.m.PlayerTalents[5] + 1 == 4 ? 0 : _event.m.PlayerTalents[5] + 1;
							return "Customize Talents Page 2";
						}
					},
					{
						Text = "近战防御 " + (_event.m.PlayerTalents[6] != 0 ? "(" + _event.m.PlayerTalents[6] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[6] = _event.m.PlayerTalents[6] + 1 == 4 ? 0 : _event.m.PlayerTalents[6] + 1;
							return "Customize Talents Page 2";
						}
					},
					{
						Text = "远程防御 " + (_event.m.PlayerTalents[7] != 0 ? "(" + _event.m.PlayerTalents[7] + ")" : ""),
						function getResult( _event )
						{
							_event.m.PlayerTalents[7] = _event.m.PlayerTalents[7] + 1 == 4 ? 0 : _event.m.PlayerTalents[7] + 1;
							return "Customize Talents Page 2";
						}
					},
					{
						Text = "完成",
						function getResult( _event )
						{
							local i = 0;
							
							foreach (t in _event.m.PlayerTalents)
							{
								if (t == 0)
								{
									i += 1;
								}
							}
							
							if (i == 8)
							{
								_event.m.IsRandomTalent = true;
							}
							
							return "Player Character Selection";
						}
					},
					{
						Text = "上一页",
						function getResult( _event )
						{
							return "Customize Talents Page 1";
						}
					}
				]);
			}
		});

		this.m.Screens.push({
			ID = "A",
			Text = "@@[img]gfx/ui/events/event_51.png[/img]两个克朗。整整一周，你只有两个克朗。\n\n当你漫步在狭窄的街道上，走向过夜小巷时，你看到广场上很多人。事情有点不对劲，你可以从他们走路的方式看出来。他们走路有什么不同吗？\n\n突然的骚动打断了你的思想。\n\n两个男人站在你通常睡觉的地方。其中一位身材矮小，年轻，穿着红色面料。贵族的儿子。一个披着斗篷的人把他逼到墙角靠着石墙。小家伙说话了，声音惊恐地颤抖着，几乎消失在黑暗中。%SPEECH_ON%等着，我的父亲会知道你所做的一切！%SPEECH_OFF%第二个人迅速做出反应。年轻人大声喊叫，但一只手捂住了他的嘴，尖叫声被打断了。他倒在地上，在墙上留下了一个深红色的污点。",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "可怕的景象",
					function getResult( _event )
					{
						return "B";
					}

				}
			],
			function start( _event )
			{
				_event.m.Title = "传奇乞丐";
			}

		});
		this.m.Screens.push({
			ID = "B",
			Text = "@@[img]gfx/ui/events/event_50.png[/img]当那个男人的头猛地回头时，你吓得哭喊了出来。眼神相遇，刹那间，他爬上一堵墙，消失在屋顶之间。你朝贵族走去。他的脸很熟悉。他对你的困境漠不关心对一个出身高贵的人来说太正常了。\n\n死人是可怜的，贵族的尸体会给你带来危险。当你准备离开时，金光闪闪东西吸引了你的眼球。一个几乎装满克朗的袋子，在你敏锐的目光中确认了它的价值。\n\n你不应该。你应该。\n\n它很重。成百上千的克朗很重，包裹太大了，兜帽或破布都遮不住。当你寻找一个暂时的藏身点时，一股微弱的闪光渗入小巷。麻烦来了,一个士兵朝你喊道 %SPEECH_ON%这是怎么回事？你有什么...%SPEECH_OFF%仆人的目光落在死去的贵族身上。%SPEECH_ON%你谋杀他！%SPEECH_OFF%",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "该跑了！",
					function getResult( _event )
					{
						return "C";
					}

				}
			],
			function start( _event )
			{
				_event.m.Title = "传奇乞丐";
			}

		});
		this.m.Screens.push({
			ID = "C",
			Title = "乞丐",
			Text = "@@[img]gfx/ui/events/event_04.png[/img]震惊对一个人的速度几乎没有帮助，士兵的愤怒减缓了他的剑的拔出。你匆忙跳上并越过一个腐烂的屋顶，跳到另一条街上。附近有一个喇叭。\n\n你的安全是短暂的，你的头脑被越来越多的盔甲声淹没了。唯一的出路是逃出城去。\n\n随着肾上腺素的消退，你开始意识到这场考验的真正影响。完全相信你的罪过，(贵族家族)的复仇之重将及时降临到你身上。你的黄金可以为你购买武器和使用它们的武器，但可以购买多久？\n\n你凝视着手中闪烁的财富。值得吗？你的掠夺物一下子就让你信服了。有了新开始的梦想，你将继续前行。",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "现在不能回去了",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				_event.m.Title = "传奇乞丐";
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}
	
	function onApplyingAllSetting()
	{
		local playerState = this.World.State.getPlayer();
		local origin = this.World.Assets.getOrigin();

		if (this.m.Player != null)
		{
			this.World.getPlayerRoster().add(this.m.Player);
		
			if (this.m.Dub != null)
			{
				this.World.getPlayerRoster().remove(this.m.Dub);
				this.m.Dub = null;
			}
		}

		if (this.m.AllowToHireNoble)
		{
			this.World.Flags.add("CanHireNoble");
		}
		this.logInfo("Mod Custom Beggar - allowing to hire noble:" + this.World.Flags.has("CanHireNoble"));
		
		this.World.Assets.setMoney(this.m.Money);
		this.logInfo("Mod Custom Beggar - set starting money to " + this.World.Assets.m.Money);

		this.World.Assets.m.XPMult = this.m.XpRate * 0.01;
		this.logInfo("Mod Custom Beggar - set XP multiplier to " + this.World.Assets.m.XPMult);

		this.World.Assets.m.BrothersMax = this.m.MaxRoster;
		this.logInfo("Mod Custom Beggar - set maximum roster size " + this.World.Assets.m.BrothersMax);
		
		this.World.Assets.m.DailyWageMult = this.m.WageRate * 0.01;
		this.logInfo("Mod Custom Beggar - set daily wage multiplier to " + this.World.Assets.m.DailyWageMult);

		this.World.Assets.m.HiringCostMult = this.m.HiringRate * 0.01;
		this.logInfo("Mod Custom Beggar - set hiring cost multiplier to " + this.World.Assets.m.HiringCostMult);
		
		this.World.Assets.m.SellPriceMult = this.m.SellingRate * 0.01;
		this.logInfo("Mod Custom Beggar - set sell price multiplier to " + this.World.Assets.m.SellPriceMult);
		
		this.World.Assets.m.BuyPriceMult = this.m.BuyingRate * 0.01;
		this.logInfo("Mod Custom Beggar - set buy price multiplier to " + this.World.Assets.m.BuyPriceMult);
		
		this.World.Assets.m.ExtraLootChance = this.m.BonusLoot;
		this.logInfo("Mod Custom Beggar - set bonus loot chance to " + this.World.Assets.m.ExtraLootChance);
		
		this.World.Assets.m.ChampionChanceAdditional = this.m.BonusChampion;
		this.logInfo("Mod Custom Beggar - set bonus champion chance to " + this.World.Assets.m.ChampionChanceAdditional);
		
		if (this.World.State.getPlayer() != null)
		{
			this.World.State.getPlayer().m.BaseMovementSpeed = this.m.BonusSpeed;
			this.logInfo("Mod Custom Beggar - set world map movement speed to " + this.World.State.getPlayer().m.BaseMovementSpeed);
		}

		if (this.m.BackgroundType == 2)
		{
			this.World.Flags.set("IsLegendsNecro", true);
		}

		this.World.Flags.add("RosterSize", this.m.MaxRoster);
		this.World.Flags.add("HiringCost", this.m.HiringRate * 0.01);
		this.World.Flags.add("WageCost", this.m.WageRate * 0.01);
		this.World.Flags.add("XP", this.m.XpRate * 0.01);
		this.World.Flags.add("Selling", this.m.SellingRate * 0.01);
		this.World.Flags.add("Buying", this.m.BuyingRate * 0.01);
		this.World.Flags.add("Looting", this.m.BonusLoot);
		this.World.Flags.add("ChampionChance", this.m.BonusChampion);
		this.World.Flags.add("WorldMapSpeed", this.m.BonusSpeed);
	}
	
	function createPlayerCharacter()
	{
		local _player = this.m.Player;
		_player.m.MoodChanges = [];
		_player.worsenMood(1.5, "Saw something awful");
		_player.getSkills().removeByID("trait.survivor");
		_player.getSkills().removeByID("trait.greedy");
		_player.getSkills().removeByID("trait.loyal");
		_player.getSkills().removeByID("trait.disloyal");
		_player.getSkills().add(this.new("scripts/skills/special/beggar_racial"));
		_player.getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		_player.getFlags().set("IsPlayerCharacter", true);
		_player.m.HireTime = this.Time.getVirtualTimeF();
		_player.m.Talents = [];
		_player.getTalents().resize(this.Const.Attributes.COUNT, 0);
		this.fillPlayerTalents();
		_player.setVeteranPerks(2);
		_player.m.Attributes = [];
		_player.fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1 + this.m.AttributesAfterVeteran);

		if (_player.getSkills().hasSkill("background.legend_commander_necro"))
		{
			_player.getSkills().add(this.new("scripts/skills/traits/cultist_fanatic_trait"));
			_player.getSkills().add(this.new("scripts/skills/perks/perk_legend_roster_1"));
			_player.getSkills().add(this.new("scripts/skills/perks/perk_legend_brink_of_death"));
			_player.getSkills().add(this.new("scripts/skills/perks/perk_legend_siphon"));
		}

		if (!_player.getSkills().hasSkill("background.legend_necrosavant") && !_player.getSkills().hasSkill("background.legend_donkey"))
		{
			if (this.m.UndeadType == 2)
			{
				_player.getFlags().add("PlayerSkeleton");
				_player.getFlags().add("undead");
				_player.getFlags().add("skeleton");
				local skill = this.new("scripts/skills/traits/legend_fleshless_trait");
				_player.m.Skills.add(skill);
				_player.m.Skills.add(this.new("scripts/skills/racial/skeleton_racial"));

			}
			else if (this.m.UndeadType == 1)
			{
				_player.getFlags().add("PlayerZombie");
				_player.getFlags().add("undead");
				_player.getFlags().add("zombie_minion");
				local skill = this.new("scripts/skills/traits/legend_rotten_flesh_trait");
				_player.m.Skills.add(skill);
				skill.onApplyAppearance();
				_player.setDirty(true);
				_player.m.Skills.add(this.new("scripts/skills/perks/perk_legend_zombie_bite"));
				_player.m.Skills.add(this.new("scripts/skills/perks/perk_nine_lives"));
			}
		}

		if (this.m.IsAddingFavourPerk)
		{
			local background = _player.getBackground();

			foreach ( _tr in this.Const.Perks.EnemyTrees.Tree )
			{
				background.addPerkGroup(_tr.Tree);
			}
		}
	}
	
	function fillPlayerTalents()
	{
		local _player = this.m.Player;
		
		if (this.m.IsRandomTalent)
		{
			this.m.PlayerTalents.resize(this.Const.Attributes.COUNT, 0);
			local a = this.Math.rand(0, 7);
			local b = this.Math.rand(0, 7);
			local c = this.Math.rand(0, 7);

			while (a == b)
			{
				b = this.Math.rand(0, 7); 
			}
			
			while (a == c || c == b)
			{
				c = this.Math.rand(0, 7);
			}
			
			this.m.PlayerTalents[a] = this.Math.rand(1, 3);
			this.m.PlayerTalents[b] = this.Math.rand(1, 3);
			this.m.PlayerTalents[c] = this.Math.rand(1, 3);
			_player.m.Talents = [];
			_player.m.Talents.extend(this.m.PlayerTalents);
			this.m.PlayerTalents = [];
			this.m.PlayerTalents.resize(this.Const.Attributes.COUNT, 0);
			return;
		}
		
		_player.m.Talents = [];
		_player.m.Talents.extend(this.m.PlayerTalents);
		
	}

	function getBackground( _index )
	{
		local background;

		switch (_index) 
		{
	    case 1:
	        background = this.Const.CharacterBackgroundsRandom;
	        break;

	    case 2:
	        background = ["legend_necro_commander_background"];
	        break;

	    case 3:
	        background = ["legend_necrosavant_background"];
	        break;

	    case 4:
	    	background = ["legend_berserker_commander_background"];
	        break;

	    case 5:
	    	background = ["legend_donkey"];
	        break;
	
	    default:
	        background = ["legend_beggar_commander_op_background"];
		}

		return background;
	}

	function getBackgroundTypeCount()
	{
		return 6;
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		local brothers = this.World.getPlayerRoster().getAll();
		this.m.Dub = brothers[0];
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"home",
			this.World.Flags.get("HomeVillage")
		]);
	}
	
	function onDetermineStartScreen()
	{
		return "General Settings Page 1";
	}

	function onClear()
	{
		this.m.Money = 2;
		this.m.MaxRoster = 27;
		this.m.WageRate = 100;
		this.m.HiringRate = 100;
		this.m.XpRate = 100;
		this.m.SellingRate = 100;
		this.m.BuyingRate = 100;
		this.m.BonusLoot = 0;
		this.m.BonusChampion = 0;
		this.m.BonusSpeed = 105;
		this.m.Player = null;
		this.m.AllowToHireNoble = false;
		this.m.UndeadType = 0;
		this.m.BackgroundType = 0;
		this.m.IsAddingFavourPerk = false;
		this.m.AttributesAfterVeteran = 0;
		this.m.IsRandomTalent = true;
		this.m.PlayerTalents.resize(this.Const.Attributes.COUNT, 0);
		this.World.getTemporaryRoster().clear();
	}

});

