this.beggar_racial <- this.inherit("scripts/skills/skill", {
	m = {
		Change = false,
		IsActivated = false,
	},
	function create()
	{
		this.m.ID = "effects.beggar_racial";
		this.m.Name = "Beggar Ability";
		this.m.Description = "";
		this.m.Type = this.Const.SkillType.Racial;
		this.m.Order = this.Const.SkillOrder.VeryLast;
		this.m.IsActive = false;
		this.m.IsStacking = false;
		this.m.IsHidden = true;
	}

	function onAdded()
	{
		local actor = this.getContainer().getActor();

		if (this.getContainer().hasSkill("background.legend_commander_beggar_op"))
		{
			this.removeSelf();
		}

		this.m.IsActivated = true;
	}

	function onNewDay()
	{
		if (this.m.Change)
		{
			return;
		}

		if (this.getContainer().hasSkill("background.legend_commander_beggar_op"))
		{
			this.m.IsActivated = false;
			return;
		}

		local actor = this.getContainer().getActor();
		local background = actor.getBackground();
		background.m.ID = "background.legend_commander_beggar_op";
		this.m.Change = true;
		this.m.IsActivated = true;
	}

	function onTargetKilled( _targetEntity, _skill )
	{
		local actor = this.getContainer().getActor();

		if (!this.m.IsActivated)
		{
			return;
		}

		if (this.Math.rand(1, 100) > 5)
		{
			return;
		}

		actor.getBaseProperties().Hitpoints += actor.getBaseProperties().Hitpoints < _targetEntity.getBaseProperties().Hitpoints ? 1 : 0;
		actor.getBaseProperties().Bravery += actor.getBaseProperties().Bravery < _targetEntity.getBaseProperties().Bravery ? 1 : 0;
		actor.getBaseProperties().Stamina += actor.getBaseProperties().Stamina < _targetEntity.getBaseProperties().Stamina ? 1 : 0;
		actor.getBaseProperties().MeleeSkill += actor.getBaseProperties().MeleeSkill < _targetEntity.getBaseProperties().MeleeSkill ? 1 : 0;
		actor.getBaseProperties().RangedSkill += actor.getBaseProperties().RangedSkill < _targetEntity.getBaseProperties().RangedSkill ? 1 : 0;
		actor.getBaseProperties().MeleeDefense += actor.getBaseProperties().MeleeDefense < _targetEntity.getBaseProperties().MeleeDefense ? 1 : 0;
		actor.getBaseProperties().RangedDefense += actor.getBaseProperties().RangedDefense < _targetEntity.getBaseProperties().RangedDefense ? 1 : 0;
		actor.getBaseProperties().Initiative += actor.getBaseProperties().Initiative < _targetEntity.getBaseProperties().Initiative ? 1 : 0;
		local target_skills = _targetEntity.getSkills().query(this.Const.SkillType.Perk);
		local allperks = [];

		for( local i = 0; i != target_skills.len(); i = i )
		{
			local perk = target_skills[i];

			if (!actor.getSkills().hasSkill(perk.getID()))
			{
				allperks.push(perk);
			}

			i = ++i;
		}

		if (allperks.len() == 0)
		{
			return;
		}

		local perk = allperks[this.Math.rand(0, allperks.len() - 1)];
		local name = "";
		local isAllied = actor.isAlliedWith(_targetEntity);
/*
		foreach( i, v in this.getroottable().Const.Perks.PerkDefObjects )
		{
			if (perk.getID() == v.ID)
			{
				name = v.Script;
				this.Tactical.EventLog.log("A被陷害的乞丐从 "+ (isAllied ? "盟友" : "敌人")+" 那里学会了 " + perk.getName()+"！" );
				break;
			}
		}

		if (name == "")
		{
			return;
		}
			this.Tactical.EventLog.log("B被陷害的乞丐从 "+ (isAllied ? "盟友" : "敌人")+" 那里学会了 " + perk.getName()+"！" );
		actor.getSkills().add(this.new(name));
*/
			foreach( i, v in this.Const.Perks.PerkDefObjects )
			{
				if (perk.getID() == v.ID)
				{
					if (v.Script != "")
					{
						this.Tactical.EventLog.log("被陷害的乞丐从 " + _targetEntity.getName() + " 那里学会了 [color=" + this.Const.UI.Color.NegativeValue + "]" + perk.getName() + "[/color] !" );
						actor.getSkills().add(this.new(v.Script));
						actor.getBackground().addPerk(i, this.Math.rand(0,6));
						break;
					}
				}
			}
	}

});

