//All magic abilities description database

local gt = this.getroottable();

if (!("Beggar" in gt.Const))
{
	gt.Const.Beggar <- {};
}

gt.Const.Beggar.AttributesIcon <- [
	"ui/icons/health.png",
	"ui/icons/bravery.png",
	"ui/icons/fatigue.png",
	"ui/icons/initiative.png",
	"ui/icons/melee_skill.png",
	"ui/icons/ranged_skill.png",
	"ui/icons/melee_defense.png",
	"ui/icons/ranged_defense.png"
];

gt.Const.Beggar.getTooltipsFromBeggar <- function( _bro )
{
	local ret = [];
	local job = _bro.getBackground();
	local skills = _bro.getSkills();
	local stats = _bro.getBaseProperties();
	local talents = _bro.getTalents();

	local background = [
		{
			id = 1,
			icon = "ui/icons/dub.png",
			text = "[color=" + this.Const.UI.Color.DamageValue + "]-------- 背景 --------[/color]"
		},
		{
			id = 2,
			icon = job.m.Icon,
			text = job.m.Name
		}
	];
	
	local attributes = [
		{
			id = 3,
			icon = "ui/icons/dub.png",
			text = "[color=" + this.Const.UI.Color.DamageValue + "]-------- 属性 --------[/color]"
		},
		{
			id = 4,
			icon = "ui/icons/health.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.Hitpoints + "[/color]" + (talents[0] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[0] + "[/color] 星天赋)" : "")
		},
		{
			id = 5,
			icon = "ui/icons/bravery.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.Bravery + "[/color]" + (talents[1] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[1] + "[/color] 星天赋)" : "")
		},
		{
			id = 6,
			icon = "ui/icons/fatigue.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.Stamina + "[/color]" + (talents[2] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[2] + "[/color] 星天赋)" : "")
		},
		{
			id = 7,
			icon = "ui/icons/initiative.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.Initiative + "[/color]" + (talents[3] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[3] + "[/color] 星天赋)" : "")
		},
		{
			id = 8,
			icon = "ui/icons/melee_skill.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.MeleeSkill + "[/color]" + (talents[4] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[4] + "[/color] 星天赋)" : "")
		},
		{
			id = 9,
			icon = "ui/icons/ranged_skill.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.RangedSkill + "[/color]" + (talents[5] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[5] + "[/color] 星天赋)" : "")
		},
		{
			id = 10,
			icon = "ui/icons/melee_defense.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.MeleeDefense + "[/color]" + (talents[6] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[6] + "[/color] 星天赋)" : "")
		},
		{
			id = 11,
			icon = "ui/icons/ranged_defense.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + stats.RangedDefense + "[/color]" + (talents[7] != 0 ? " ([color=" + this.Const.UI.Color.NegativeValue + "]" + talents[7] + "[/color] 星天赋)" : "")
		}
	];
	
	local traits = [
		{
			id = 13,
			icon = "ui/icons/dub.png",
			text = "[color=" + this.Const.UI.Color.DamageValue + "]-------- 特性 --------[/color]"
		}
	];
	
	local e = skills.getAllSkillsOfType(this.Const.SkillType.Trait);
	
	if (e.len() != 0)
	{
		for ( local i = 0; i < e.len(); i = ++i )
		{
			traits.extend([
				{
					id = 14 + i,
					icon = e[i].m.Icon,
					text = "[color=" + this.Const.UI.Color.PositiveValue + "]" + e[i].m.Name + "[/color]"
				},
				{
					id = 14 + i,
					text = e[i].getDescription()
				}
			]);
		}
	}
	
	ret.extend(background);
	ret.extend(attributes);
	ret.extend(traits);
	
	return ret;
};




