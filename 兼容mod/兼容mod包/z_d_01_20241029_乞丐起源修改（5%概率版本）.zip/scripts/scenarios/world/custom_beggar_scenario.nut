this.custom_beggar_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {
		OnInitOrigin = false,
		CanHire = false
	},
	function create()
	{
		this.m.ID = "scenario.custom_legends_beggar";
		this.m.Name = "乞丐挑战(定制)";
		this.m.Description = "[p=c][img]gfx/ui/events/event_70.png[/img][/p][p]A lowly unskilled beggar, you witnessed something in an alley and now a noble house wants you dead. This is a challenge run with a very weak starting character. Can you awaken the true power of your avatar? \n\n[color=#bcad8c]Knows Too Much:[/color] All noble houses hate you.\n[color=#bcad8c]Learning in battles[/color]:  The beggar can gain stats and perks by defeating enemies.\n[color=#bcad8c]Begin alone Avatar[/color]: If the beggar dies, the campaign ends.\n[color=#bcad8c]上帝意志：[/color]定制你自己的乞丐开局。[/p]";
		this.m.Difficulty = 3;
		this.m.Order = 50;
	}

	function isAllowToHireNoble()
	{
		return this.World.Flags.has("CanHireNoble");
	}

	function isValid()
	{
		return this.Const.DLC.Wildmen;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 1; i = i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.worsenMood(1.5, "Saw something awful");
			bro.m.HireTime = this.Time.getVirtualTimeF();

			while (names.find(bro.getNameOnly()) != null)
			{
				bro.setName(this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
			}

			names.push(bro.getNameOnly());
			i = ++i;
			i = i;
		}

		local bros = roster.getAll();
		local r;

		bros[0].setStartValuesEx([
			"legend_beggar_commander_op_background"
		], true, -1, true, 2);

		bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].getFlags().set("IsPlayerCharacter", true);
		this.World.Assets.m.BusinessReputation = -200;
		this.World.Assets.getStash().resize(this.World.Assets.getStash().getCapacity() + 9);
		this.World.Assets.m.Money = this.World.Assets.m.Money / 2 + 2;
		this.World.Assets.m.ArmorParts = 0;
		this.World.Assets.m.Medicine = 0;
		this.World.Assets.m.Ammo = 0;
	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isMilitary() && !randomVillage.isIsolatedFromRoads() && randomVillage.getSize() == 1)
			{
				break;
			}

			i = ++i;
			i = i;
		}

		local randomVillageTile = randomVillage.getTile();
		this.World.Flags.set("HomeVillage", randomVillage.getName());
		local navSettings = this.World.getNavigator().createSettings();
		navSettings.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;
		local f = randomVillage.getFactionOfType(this.Const.FactionType.NobleHouse);
		f.addPlayerRelation(-200.0, "You know too much");

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 4), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 4));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 4), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 4));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) <= 1)
				{
				}
				else if (tile.Type != this.Const.World.TerrainType.Plains && tile.Type != this.Const.World.TerrainType.Steppe && tile.Type != this.Const.World.TerrainType.Tundra && tile.Type != this.Const.World.TerrainType.Snow)
				{
				}
				else
				{
					local path = this.World.getNavigator().findPath(tile, randomVillageTile, navSettings, 0);

					if (!path.isEmpty())
					{
						randomVillageTile = tile;
						break;
					}
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(111);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		randomVillage.getFactionOfType(this.Const.FactionType.Settlement).addPlayerRelation(40.0, "Considered local heroes for keeping the village safe");
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/retirement_01.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.custom_beggar_scenario_intro");
		}, null);
	}

	function onInit()
	{
		this.starting_scenario.onInit();
		this.World.Assets.m.BrothersMax = 12;
		this.World.Assets.m.BrothersMaxInCombat = 27;
		this.World.Assets.m.BrothersScaleMax = 27;
		this.m.OnInitOrigin = true;

		this.logInfo("Mod Custom Beggar - Allowing To Hire Noble: " + this.isAllowToHireNoble());

		if (this.World.Flags.has("RosterSize"))
		{
			this.World.Assets.m.BrothersMax = this.World.Flags.get("RosterSize");
		}
		this.logInfo("Mod Custom Beggar - Maximum Roster Size = " + this.World.Assets.m.BrothersMax);


		if (this.World.Flags.has("XP"))
		{
			this.World.Assets.m.XPMult = this.World.Flags.get("XP");
		}
		this.logInfo("Mod Custom Beggar - XP Multiplier = " + this.World.Assets.m.XPMult);


		if (this.World.Flags.has("WageCost"))
		{
			this.World.Assets.m.DailyWageMult = this.World.Flags.get("WageCost");
		}
		this.logInfo("Mod Custom Beggar - Daily Wage Multiplier = " + this.World.Assets.m.DailyWageMult);


		if (this.World.Flags.has("HiringCost"))
		{
			this.World.Assets.m.HiringCostMult = this.World.Flags.get("HiringCost");
		}
		this.logInfo("Mod Custom Beggar - Hiring Cost Multiplier = " + this.World.Assets.m.HiringCostMult);


		if (this.World.Flags.has("Selling"))
		{
			this.World.Assets.m.SellPriceMult = this.World.Flags.get("Selling");
		}
		this.logInfo("Mod Custom Beggar - Sell Price Multiplier = " + this.World.Assets.m.SellPriceMult);


		if (this.World.Flags.has("Buying"))
		{
			this.World.Assets.m.BuyPriceMult = this.World.Flags.get("Buying");
		}
		this.logInfo("Mod Custom Beggar - Buy Price Multiplier = " + this.World.Assets.m.BuyPriceMult);


		if (this.World.Flags.has("Looting"))
		{
			this.World.Assets.m.ExtraLootChance = this.World.Flags.get("Looting");
		}
		this.logInfo("Mod Custom Beggar - Bonus Loot Chance = " + this.World.Assets.m.ExtraLootChance);


		if (this.World.Flags.has("ChampionChance"))
		{
			this.World.Assets.m.ChampionChanceAdditional = this.World.Flags.get("ChampionChance");
		}
		this.logInfo("Mod Custom Beggar - Bonus Champion Chance = " + this.World.Assets.m.ChampionChanceAdditional);


		if (this.World.Flags.has("WorldMapSpeed"))
		{
			if (this.World.State.getPlayer() != null)
			{
				this.World.State.getPlayer().m.BaseMovementSpeed = this.World.Flags.get("WorldMapSpeed");
			}
		}
//		this.logInfo("Mod Custom Beggar - World Map Movement Speed = " + this.World.State.getPlayer().m.BaseMovementSpeed);
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

	function onHiredByScenario( bro )
	{
//add by bigmap
		if (!this.isAllowToHireNoble() && !bro.getBackground().isBackgroundType(this.Const.BackgroundType.Lowborn))
		{
			bro.getSkills().add(this.new("scripts/skills/injury/sickness_injury"));
			bro.worsenMood(1.0, "Fell sick after joining you");
//			this.logDebug(bro.getBackground().m.Name + " ----------no IsLowborn");
		}
		else
		{
//			this.logDebug(bro.getBackground().m.Name + " ----------IsLowborn");
		}
	}

	function onUpdateHiringRoster( _roster )
	{
		if (this.isAllowToHireNoble())
		{
			return;
		}

		local garbage = [];
		local bros = _roster.getAll();

		foreach( i, bro in bros )
		{
//add by bigmap
			if (!bro.getBackground().isBackgroundType(this.Const.BackgroundType.Lowborn))
			{
//				this.logDebug(bro.getBackground().m.Name + " ----------no IsLowborn");
				garbage.push(bro);
			}
			else
			{
//				this.logDebug(bro.getBackground().m.Name + " ----------IsLowborn");
			}
		}

		foreach( g in garbage )
		{
			_roster.remove(g);
		}
	}

});

