﻿var wtTranslateCharacterScreenPerksModule1 = TranslateCharacterScreenPerksModule1;
TranslateCharacterScreenPerksModule1 = function (text)
{
	text = text.replace(/Direct your attention to guiding an apprentice into the mercenary world, increasing the company roster size by (.*?)/, "将你的注意力集中在引导学徒进入雇佣兵世界上，将战队名册等级增加1，重复不累计。");
	text = text.replace(/Spend time training bodyguards to work together, increasing the company roster size by (.*?)/, "花时间训练保镖一起工作，将战队名册等级增加1，重复不累计。");
	text = text.replace(/Set up team planning, with task lists and prioritisation\. Increases the company roster size by (.*?)/, "制定团队计划，列出任务清单和优先顺序。将战队名册等级增加1，重复不累计。");
	text = text.replace(/Create a squad regime, with weekly schedules and drills\. Increases the company roster size by (.*?)/, "建立班制，每周安排训练。将战队名册等级增加1，重复不累计。");
	text = text.replace(/Oversee the section\'s financial administration processes, managing pay disputes, disbursements, withholdings and loans\.  Increases the company roster size by (.*?)/, "监督部门的财务管理流程，管理薪酬争议、支出、预扣和贷款。将战队名册等级增加1，重复不累计。");
	text = text.replace(/Manage the company logistics. Supply rationing, camp structure and waste disposal\. Increases the company roster size by (.*?)/, "管理队伍物流。供应配给、营地结构和废物处理。将战队名册等级增加1，重复不累计。");
	text = text.replace(/Increases the company roster size by (.*?)/, "将战队名册等级增加1，重复不累计。");
	text = text.replace("Implement platoon organisation techniques. Balancing interteam dynamics, clarifying role responsibilities, creating conflict resolution processes and creating strategic plans.", "实施排组织技术。平衡团队间的动态，明确角色职责，创建冲突解决流程并制定战略计划。");
	text = wtTranslateCharacterScreenPerksModule1.call(this,text);
	return text;
};
